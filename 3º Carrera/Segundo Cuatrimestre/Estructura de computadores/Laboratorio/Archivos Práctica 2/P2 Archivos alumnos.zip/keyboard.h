#ifndef KEYBOARD_H_
#define KEYBOARD_H_

int kb_scan(void);

#endif
