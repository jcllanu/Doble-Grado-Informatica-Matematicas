package practica_4;


import java.util.concurrent.locks.*;

public class Multibuffersync {
	static final int M = 4;
	static final int N = 4;
	static final int K = 4;

	public static void main(String[] args) {
		Productor2 p[] = new Productor2[N];
		Consumidor2 c[] = new Consumidor2[M];
		//MonitorBuffer2 buf = new MonitorBuffer2(K);
		MonitorBuffer3 buf = new MonitorBuffer3(K);
		for (int i = 0; i < N; i++) {
			p[i] = new Productor2(i, buf);
			p[i].start();    
		}
		for (int i = 0; i < M; i++) {
			c[i] = new Consumidor2(i, buf);
			c[i].start();	    
		}
		for (int i = 0; i < N; i++) {
			try {
				p[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
		for (int i = 0; i < M; i++) {
			try {
				c[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
	}
	
	static class Productor2 extends Thread implements Almacen2  {
		int id;
		MonitorBuffer2 buf;
		MonitorBuffer3 buf3;
		public Productor2 (int id, MonitorBuffer2 buf) {
			this.id = id;
			this.buf = buf;
			
		}
		public Productor2 (int id, MonitorBuffer3 buf3) {
			this.id = id;
			this.buf3 = buf3;
			
		}
		public void run() {
			for (int i = 1; i < 5; i++) {
				Producto2[] p=new Producto2[i];
				for(int j=0; j<i; j++) {
					p[j] = new Producto2(id, i, j);
				}
				almacenar(p);
				try {
					sleep(1);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		@Override
		public void almacenar(Producto2[] producto) {
			if(buf!=null) {
				buf.almacenar(producto);
			}else {
				buf3.almacenar(producto);
			}
		}
		@Override
		public Producto2[] extraer(int k) {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	static class Consumidor2 extends Thread implements Almacen2  {
		int id;
		MonitorBuffer2 buf;
		MonitorBuffer3 buf3;
		public Consumidor2 (int id, MonitorBuffer2 buf) {
			this.id = id;
			this.buf = buf;

		}
		public Consumidor2 (int id, MonitorBuffer3 buf3) {
			this.id = id;
			this.buf3 = buf3;

		}
		public void run() {
			for (int i = 5; i > 0; i--) {
				Producto2[] p = extraer(i);
				
			}
		}
		@Override
		public void almacenar(Producto2[] producto) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public Producto2[] extraer(int k) {
			if(buf!=null) {
				return buf.extraer(k);
			}else {
				return buf3.extraer(k);
			}
			
		}
	}

}

class Producto2 {
	int n = 0, k = 0, j=0;
	public Producto2(int i, int k, int j) {
		this.n = i;
		this.k = k;
		this.j = j;
	}
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
	public String toString() {
		return "(" + n + "," + k + "," + j + ")";
	}
}


class MonitorBuffer2 {
	private int ini = 0, fin = 0, count=0;
	private Producto2[] buf;
	private int K;
	
	public MonitorBuffer2(int K) {
		buf = new Producto2[K];
		this.K = K;
	}
	
	synchronized void almacenar(Producto2[] p) {
		int i=0;
		while(i<p.length){
			while(count==K) {try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			while(count<K && i<p.length) {
				System.out.println("Almacenamos el producto: " + p[i].toString());
				buf[fin]=p[i];
				fin = (fin + 1) % K;
				count++;
				i++;
			}
			notifyAll();
		}
	}
	
	synchronized Producto2[] extraer(int k) {
		Producto2[] p= new Producto2[k];
		int i=0;
		while(i<k){
			while(count==0) {try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			while(count>0 && i<k) {
				p[i] = buf[ini];
				buf[ini] = null;
				ini = (ini + 1) % K;
				count--;
				System.out.println("Consumimos el producto: " + p[i].toString());
				i++;
				
			}
			notifyAll();
		}
		return p;
	}
}


class MonitorBuffer3 {
	private int ini = 0, fin = 0, count=0;
	private Producto2[] buf;
	private int K;
	private final Lock l=new ReentrantLock();
	private final Condition empty=l.newCondition();
	private final Condition full=l.newCondition();
	
	
	
	public MonitorBuffer3(int K) {
		buf = new Producto2[K];
		this.K = K;
	}
	
	 void almacenar(Producto2[] p) {
		 l.lock();
		int i=0;
		while(i<p.length){
			while(count==K) {try {
				empty.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			while(count<K && i<p.length) {
				System.out.println("Almacenamos el producto: " + p[i].toString());
				buf[fin]=p[i];
				fin = (fin + 1) % K;
				count++;
				i++;
			}
			full.signal();
		}
		l.unlock();
	}
	
	 Producto2[] extraer(int k) {
		 l.lock();
		Producto2[] p= new Producto2[k];
		int i=0;
		while(i<k){
			while(count==0) {try {
				full.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			while(count>0 && i<k) {
				p[i] = buf[ini];
				buf[ini] = null;
				ini = (ini + 1) % K;
				count--;
				System.out.println("Consumimos el producto: " + p[i].toString());
				i++;
				
			}
			empty.signal();
		}
		l.unlock();
		return p;
	}
}