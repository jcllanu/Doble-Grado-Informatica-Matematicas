package practica_4;

public class prod_consum {
	static final int M = 4;
	static final int N = 4;
	static final int K = 4;

	public static void main(String[] args) {
		Productor p[] = new Productor[N];
		Consumidor c[] = new Consumidor[M];
		MonitorBuffer buf = new MonitorBuffer(K);
		for (int i = 0; i < N; i++) {
			p[i] = new Productor(i, buf);
			p[i].start();    
		}
		for (int i = 0; i < M; i++) {
			c[i] = new Consumidor(i, buf);
			c[i].start();	    
		}
		for (int i = 0; i < N; i++) {
			try {
				p[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
		for (int i = 0; i < M; i++) {
			try {
				c[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
	}
	
	static class Productor extends Thread implements Almacen  {
		int id;
		MonitorBuffer buf;
		public Productor (int id, MonitorBuffer buf) {
			this.id = id;
			this.buf = buf;
			
		}
		public void run() {
			for (int i = 0; i < 10; i++) {
				Producto p = new Producto(id, i);
				almacenar(p);
				
			}
		}
		@Override
		public void almacenar(Producto producto) {
			buf.almacenar(producto);
		}
		@Override
		public Producto extraer() {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	static class Consumidor extends Thread implements Almacen  {
		int id;
		MonitorBuffer buf;

		public Consumidor (int id, MonitorBuffer buf) {
			this.id = id;
			this.buf = buf;

		}
		public void run() {
			for (int i = 0; i < 10; i++) {
				Producto p = extraer();
				
			}
		}
		@Override
		public void almacenar(Producto producto) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public Producto extraer() {
			return buf.extraer();
		}
	}

}

class Producto {
	int n = 0, k = 0;
	public Producto(int i, int k) {
		this.n = i;
		this.k = k;
	}
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
	public String toString() {
		return "(" + n + "," + k + ")";
	}
}


class MonitorBuffer {
	private int ini = 0, fin = 0, count=0;
	private Producto[] buf;
	private int K;
	
	public MonitorBuffer(int K) {
		buf = new Producto[K];
		this.K = K;
	}
	
	synchronized void almacenar(Producto p) {
		while(count==K) {try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
		System.out.println("Almacenamos el producto: " + p.toString());
		buf[fin]=p;
		fin = (fin + 1) % K;
		count++;
		notifyAll();
	}
	
	synchronized Producto extraer() {
		while(count==0) {try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
		
		Producto p = buf[ini];
		buf[ini] = null;
		ini = (ini + 1) % K;
		count--;
		System.out.println("Consumimos el producto: " + p.toString());
		notifyAll();
		return p;
	}
}
