package practica_4;

public class incr_decr {

	static final int M = 600;
	static final int N = 600;

	public static void main(String[] args) {
		
		Monitor m =new Monitor();
		HiloIncrementador hi = new HiloIncrementador(m);
		HiloDecrementador hd = new HiloDecrementador(m);
		hi.start();
		hd.start();
		try {
			hi.join();
			hd.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("El valor final es: " +  m.getNum());
	}
	
	static class HiloIncrementador extends Thread  {
		Monitor m;
		public HiloIncrementador (Monitor m) {
			this.m = m;
		}
		
		public void run() {
			for(int i = 0; i < N; i++) {
				m.incrementar();
			}
		}
	}
	
	static class HiloDecrementador extends Thread  {
		Monitor m;
		public HiloDecrementador (Monitor m) {
			this.m = m;
		}
		
		public void run() {
			for(int i = 0; i < N; i++) {
				m.decrementar();
			}
		}
	}
}

class Monitor {
	private int n=0;
	synchronized void  incrementar() {
		n++;
	}
	synchronized void  decrementar() {
		n--;
	}
	synchronized int  getNum() {
		return n;
	}
}

