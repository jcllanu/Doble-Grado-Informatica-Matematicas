package parte2;

import java.io.*;
import java.net.*;

public class Emisor extends Thread {
	
	private String nombre_fichero;
	ServerSocket sc;
	String nombre_cliente;
	
	protected Emisor(ServerSocket sc, String nombre_fichero, String nombre_cliente) {
		this.sc = sc;
		this.nombre_fichero = nombre_fichero;
		this.nombre_cliente = nombre_cliente;
	}
	
	public void run() {
		try {
			Socket socket = sc.accept();
			Fichero f = new Fichero(System.getProperty("user.dir") + "/" + nombre_cliente + "/ficheros/" + nombre_fichero,nombre_fichero,nombre_cliente);
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			out.writeObject(f);
			out.flush();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
