package parte2;

// OK

public class MensajeNoHayFichero extends Mensaje {

	private static final long serialVersionUID = 1L;
	private String error;
	public MensajeNoHayFichero(String origen, String destino, String error) {
		super(MensajeType.NO_HAY_FICHERO, origen, destino);
		this.error=error;
	}
	public String getError() {
		return error;
	}
	
}
