package parte2;

public class MensajeAnnadirFicheroUsuario extends Mensaje {
	
	private static final long serialVersionUID = 1L;
	
	private String fichero;
	
	public MensajeAnnadirFicheroUsuario(String origen, String destino, String fichero) {
		super(MensajeType.ANNADIR_FICHERO_USUARIO, origen, destino);
		this.fichero = fichero;
	}
	
	public String getFichero(){
		return this.fichero;
	}

}
