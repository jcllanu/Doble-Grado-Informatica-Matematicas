package parte2;

// OK

public class MensajePedirFichero extends Mensaje {

	private static final long serialVersionUID = 1L;

	private String nombre_fichero;
	private String nombre_propietario;
	
	public MensajePedirFichero(String origen, String destino, String nombre_fichero, String nombre_propietario) {
		super(MensajeType.PEDIR_FICHERO, origen, destino);
		this.nombre_fichero = nombre_fichero;
		this.nombre_propietario = nombre_propietario;
	}

	public String getNombreFichero() {
		return this.nombre_fichero;
	}
	public String getNombrePropietario() {
		return this.nombre_propietario;
	}

}
