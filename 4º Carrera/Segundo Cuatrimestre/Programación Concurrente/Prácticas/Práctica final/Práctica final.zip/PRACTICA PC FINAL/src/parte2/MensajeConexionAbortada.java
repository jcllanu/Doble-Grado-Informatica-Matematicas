package parte2;

public class MensajeConexionAbortada extends Mensaje {

	private static final long serialVersionUID = 1L;
	private String error;
	public MensajeConexionAbortada(String origen, String destino, String error) {
		super(MensajeType.ABORTAR_CONEXION, origen, destino);
		this.error=error;
	}
	public String getError() {
		return error;
	}
	
}