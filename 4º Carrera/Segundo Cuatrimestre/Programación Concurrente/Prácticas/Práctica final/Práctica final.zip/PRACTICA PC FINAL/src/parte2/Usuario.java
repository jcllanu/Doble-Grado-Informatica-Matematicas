package parte2;

import java.util.*;

// INFORMACI�N DE LOS USUARIOS

public class Usuario {
	
	private String nombre_usuario;
	private String direccion_IP;
	private ArrayList<String> ficheros;
	
	public Usuario(String nombre_usuario, String direccion_IP, ArrayList<String> ficheros) {
		super();
		this.nombre_usuario = nombre_usuario;
		this.direccion_IP = direccion_IP;
		this.ficheros = ficheros;
	}

	public String getNombreUsuario() {
		return this.nombre_usuario;
	}
	
	public String getIP() {
		return this.direccion_IP;
	}
	
	public ArrayList<String> getFicheros() {
		return ficheros;
	}

}
