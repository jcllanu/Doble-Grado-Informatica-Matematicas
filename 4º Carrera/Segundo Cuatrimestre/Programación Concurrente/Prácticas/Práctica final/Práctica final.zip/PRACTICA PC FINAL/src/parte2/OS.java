package parte2;

import java.io.*;
import java.net.ServerSocket;
import java.util.*;
import java.util.concurrent.*;

// OYENTE SERVIDOR

public class OS extends Thread {
	
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private ClienteExec cliente;
	Semaphore sem_espera;
	LockBakery lock;
	ServerSocket sc;
	private int nuevo_puerto;
	
	protected OS(Semaphore sem_espera, LockBakery lock, ClienteExec cliente) throws IOException {
		this.cliente = cliente;
		this.sem_espera = sem_espera;
		this.lock = lock;
		this.out = cliente.getOutputStream();
		this.in = cliente.getInputStream();
	
	}
	
	public void run() {
		try {
			boolean cerrar_conexion = false;
			while (!cerrar_conexion) {
				Mensaje m  = (Mensaje) in.readObject();
				switch(m.getTipo()) {
				  	case CONFIRMACION_CONEXION:
				  		System.out.println("Conexi�n confirmada.");
				  		nuevo_puerto = ((MensajeConfirmacionConexion) m).getPuerto();
				  		sc = new ServerSocket(nuevo_puerto);
				  		sem_espera.release();
						break;
				  	case CONFIRMACION_LISTA_USUARIOS:
				  		//Mostrar la lista de los usuarios conectados por pantalla
				  		MensajeConfirmacionListaUsuarios m1 = (MensajeConfirmacionListaUsuarios) m;
				  		lock.takeLock(2);
						System.out.println("Usuarios conectados: ");
				  		ArrayList<String> usuarios = m1.getListaUsuarios();
				  		ArrayList<ArrayList<String>> ficheros = m1.getListaFicheros();
				  		for(int i = 0; i < usuarios.size(); i++) {
				  			System.out.println("Usuario: " + usuarios.get(i));
				  			System.out.print("\tFicheros: ");
				  			for(int j = 0;  j < ficheros.get(i).size(); j++) {
				  				System.out.print(ficheros.get(i).get(j));
				  				if(j != ficheros.get(i).size() - 1) {
				  					System.out.print(", ");
				  				}else {
				  					System.out.println("");
				  				}
				  			}
				  		}
				  		System.out.println("");
				  		lock.releaseLock(2);
				  		sem_espera.release();
				  		break;
				  	case EMITIR_FICHERO:
				  		//Crea un nuevo proceso Emisor y le dice al Servidor que esta preparado
				  		MensajeEmitirFichero m2 = (MensajeEmitirFichero) m;
				  		out.writeObject(new MensajePreparadoCS(cliente.getNombre(), m.getOrigen(), cliente.getIPlocal(), nuevo_puerto));
				  		(new Emisor(sc, m2.getNombreFichero(), cliente.getNombre())).start();
				  		break;
				  	case PREPARADO_SC:
				  		//Crea un proceso Receptor para descargar el archivo solicitado
				  		MensajePreparadoSC m3 = (MensajePreparadoSC) m;
				  		(new Receptor(m3.getPuerto(), m3.getIP(), lock, cliente.getNombre(), cliente.getOutputStream())).start();
				  		break;
				  	case CONFIRMACION_CERRAR_CONEXION:
				  		MensajeConfirmacionCerrarConexion mccc = (MensajeConfirmacionCerrarConexion) m;
				  		File file = new File(System.getProperty("user.dir") + "/" + cliente.getNombre() + "/ficheros.txt");
						file.delete();
						if (file.createNewFile()) {
							BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
							for(int i = 0; i < mccc.getFicheros().size(); i++) {
								if (i != mccc.getFicheros().size() - 1) {
									writer.append(mccc.getFicheros().get(i)+"\n");
								}
								else {
									writer.append(mccc.getFicheros().get(i));
								}
							}
							writer.close();
						}
						else {
							System.out.println("No se ha podido crear el archivo.");
						}
				  		System.out.println("Conexi�n cerrada.");
				  		sc.close();
				  		cerrar_conexion = true;
				  		break;
				  	case NO_HAY_FICHERO:
				  		lock.takeLock(2);
				  		System.err.println("(!) Descarga fallida. "+((MensajeNoHayFichero) m).getError());
				  		lock.releaseLock(2);
				  		break;
				  	case ABORTAR_CONEXION:
				  		cliente.abortarConexion();
				  		lock.takeLock(2);
				  		System.err.println("Conexi�n abortada. "+((MensajeConexionAbortada) m).getError());
				  		lock.releaseLock(2);
				  		sem_espera.release();
				  		cerrar_conexion = true;
				  		break;
				  		
				  		
				  	default:
				  		break;
			    }
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}

}
