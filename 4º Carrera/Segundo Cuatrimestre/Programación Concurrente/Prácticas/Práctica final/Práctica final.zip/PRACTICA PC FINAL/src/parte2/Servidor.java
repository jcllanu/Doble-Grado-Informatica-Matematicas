package parte2;

import java.io.*;

// SERVIDOR
//JUAN CARLOS LLAMAS N��EZ Y ENRIQUE REY GISBERT
public class Servidor {

	public static void main(String[] args) {
		try {
			ServidorExec s = new ServidorExec();
			s.exec();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}