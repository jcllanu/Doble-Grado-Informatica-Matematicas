package parte2;

import java.util.*;

public class MensajeConexion extends Mensaje {

	private static final long serialVersionUID = 1L;
	
	private ArrayList<String> ficheros;
	private String userIP;
	
	public MensajeConexion(String origen, String destino, String userIP, ArrayList<String> ficheros) {
		super(MensajeType.CONEXION, origen, destino);
		this.userIP = userIP;
		this.ficheros = ficheros;
	}
	
	public String getUserIP() {
		return this.userIP;
	}
	
	public ArrayList<String> getFicheros(){
		return this.ficheros;
	}

}
