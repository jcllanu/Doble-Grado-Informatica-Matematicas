package parte2;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

// EJECUCI�N DEL SERVIDOR

public class ServidorExec {
	
	private ServerSocket servidor;
    private Socket socket;
    private final static int puerto = 999;
    private Monitor monitor;
    private Lock lock = new ReentrantLock(true);
    private volatile int nuevoPuerto = 1000;
    
    private HashMap<String, Usuario> usuarios;
    private HashMap<String, ObjectOutputStream> fouts;
    private HashMap<String, ObjectInputStream> fins;
    
    protected ServidorExec() throws IOException {
    	monitor = new Monitor();
		servidor = new ServerSocket(puerto);
		usuarios= new HashMap<String, Usuario>();
		fouts= new HashMap<String, ObjectOutputStream>();
		fins= new HashMap<String, ObjectInputStream>();
    }
    
	protected void exec() throws IOException {  	
		System.out.println("Servidor iniciado.");
		while (true) {
			socket = servidor.accept();
			(new OC(socket, monitor,this)).start();
    	}
    	
	}

	public HashMap<String, Usuario> getUsuarios() {
		return usuarios;
	}

	public HashMap<String, ObjectOutputStream> getFouts() {
		return fouts;
	}

	public HashMap<String, ObjectInputStream> getFins() {
		return fins;
	}
	
	public Lock getLockPuerto() {
		return this.lock;
	}
	
	public int getNuevoPuerto() {
		return this.nuevoPuerto;
	}
	
	public void setNuevoPuerto(int nuevo) {
		this.nuevoPuerto = nuevo;
	}
	
}
