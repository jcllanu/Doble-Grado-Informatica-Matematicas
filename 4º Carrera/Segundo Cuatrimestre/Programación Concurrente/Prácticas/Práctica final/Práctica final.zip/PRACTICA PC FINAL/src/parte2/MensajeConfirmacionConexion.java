package parte2;

// OK

public class MensajeConfirmacionConexion extends Mensaje {

	private static final long serialVersionUID = 1L;
	private int puerto;

	public MensajeConfirmacionConexion(String origen, String destino, int puerto) {
		super(MensajeType.CONFIRMACION_CONEXION, origen, destino);
		this.puerto = puerto;
	}

	public int getPuerto() {
		return puerto;
	}

}
