package parte2;

import java.io.*;

// CLIENTE
//JUAN CARLOS LLAMAS N��EZ Y ENRIQUE REY GISBERT
public class Cliente {
	public static void main(String[] args) {
		try {
			ClienteExec c = new ClienteExec();
			c.exec();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}
	}

}
