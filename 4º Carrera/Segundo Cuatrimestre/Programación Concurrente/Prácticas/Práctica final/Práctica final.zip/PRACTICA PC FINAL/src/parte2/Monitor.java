package parte2;

import java.util.concurrent.locks.*;

// MONITOR QUE CONTROLA EL ACCESO A LOS DATOS DE LOS USUARIOS Y DE LOS FLUJOS DE ENTRADA Y SALIDA
// ES UN LECTORES / ESCRITORES SOBRE LAS TABLAS DE DATOS

public class Monitor {
	
    
    private int nr = 0, nw = 0;
    private final Lock lock = new ReentrantLock(true);
    private final Condition r = lock.newCondition(), w = lock.newCondition();
    
    
    protected void request_read() throws InterruptedException {
    	lock.lock();
    	while(nw > 0) r.wait();
    	nr++;
    	lock.unlock();
    }
    
    protected void request_write() throws InterruptedException {
    	lock.lock();
    	while(nr > 0 || nw > 0) w.wait();
    	nw++;
    	lock.unlock();
    }
    
    protected void release_read() throws InterruptedException {
    	lock.lock();
    	nr--;
    	if(nr == 0) w.signal();
    	lock.unlock();
    }
    
    protected void release_write() throws InterruptedException {
    	lock.lock();
    	nw--;
    	w.signal();
		r.signalAll();
		lock.unlock();
    }

}
