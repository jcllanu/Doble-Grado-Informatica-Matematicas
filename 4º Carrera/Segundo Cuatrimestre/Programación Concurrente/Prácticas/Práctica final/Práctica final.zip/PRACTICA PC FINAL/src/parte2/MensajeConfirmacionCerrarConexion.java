package parte2;

import java.util.ArrayList;

// OK

public class MensajeConfirmacionCerrarConexion extends Mensaje {

	private static final long serialVersionUID = 1L;
	
	private ArrayList<String> ficheros;

	public MensajeConfirmacionCerrarConexion(String origen, String destino, ArrayList<String> ficheros) {
		super(MensajeType.CONFIRMACION_CERRAR_CONEXION, origen, destino);
		this.ficheros = ficheros;
	}
	
	public ArrayList<String> getFicheros() {
		return this.ficheros;
	}

}
