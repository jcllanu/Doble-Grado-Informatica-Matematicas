package parte2;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

// OYENTE CLIENTE

public class OC extends Thread {
	
	private Socket socket = null;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private Monitor monitor;
	ServidorExec servidor;
	
	protected OC(Socket s, Monitor monitor, ServidorExec servidor) throws IOException {
		this.socket = s;
		this.monitor = monitor;	
		this.servidor=servidor;
	}
	
	public void run() {
		try {
			this.out = new ObjectOutputStream(this.socket.getOutputStream());
			this.in = new ObjectInputStream(this.socket.getInputStream());
			boolean cerrar_conexion = false;
			while (!cerrar_conexion) {
				Mensaje m = (Mensaje) in.readObject();
				switch (m.getTipo()) {
			   		case CONEXION:
			   			MensajeConexion mc = (MensajeConexion) m;
			   			
			   			boolean ok=false;
			   			File f = null;
						f = new File(System.getProperty("user.dir") + "/servidor/usuarios.txt");
						FileReader fr = new FileReader (f);
					    BufferedReader br = new BufferedReader(fr);
					    String linea;
					    while((linea=br.readLine())!=null) {
					    	if(linea.equals(mc.getOrigen())) {
					    		ok=true;
					    	}
					    }
					    br.close();
					    
					    if(ok) {
				   			Usuario newUser = new Usuario(mc.getOrigen(), mc.getUserIP(),  mc.getFicheros());
				   			boolean err=false;
				   			//A�ADIR USUARIO
				   			monitor.request_write();
				   			if(servidor.getUsuarios().containsKey(newUser.getNombreUsuario())) {
				   				err=true;
				   			}else {
				   			servidor.getUsuarios().put(newUser.getNombreUsuario(), newUser);
				   			servidor.getFouts().put(newUser.getNombreUsuario(), out);
				   			servidor.getFins().put(newUser.getNombreUsuario(), in);
				   			}
				   			monitor.release_write();
				   			if(err) {
				   				out.writeObject(new MensajeConexionAbortada("Servidor", m.getOrigen(), "Este usuario ya ha iniciado sesi�n en otro dispositivo."));
								out.flush();
					   			System.out.println("El usuario " + newUser.getNombreUsuario()+" ha intentado conectarse desde otro dispositivo.");
					   			cerrar_conexion = true;
				   			}else {
				   				servidor.getLockPuerto().lock();
				   				int nuevoPuerto = servidor.getNuevoPuerto();
				   				servidor.setNuevoPuerto(nuevoPuerto+1);
				   				servidor.getLockPuerto().unlock();
				   				out.writeObject(new MensajeConfirmacionConexion("Servidor", m.getOrigen(), nuevoPuerto));
								out.flush();
					   			System.out.println("Conectado el usuario: " + newUser.getNombreUsuario());
				   			}
					    }else {
					    	out.writeObject(new MensajeConexionAbortada("Servidor", m.getOrigen(), "Este usuario no est� registrado."));
							out.flush();
				   			System.out.println("El usuario " + mc.getOrigen()+" ha intentado conectarse y no est� registrado.");
				   			cerrar_conexion = true;
					    }
						break;
			   		case LISTA_USUARIOS:
			   			
			   			//CREAR LISTA DE USUARIOS Y FICHEROS
			   			monitor.request_read();
			   			ArrayList<String> usuarios = new ArrayList<String>();
			   			ArrayList<ArrayList<String>> ficheros_usuarios = new ArrayList<ArrayList<String>>();
			   			for (Usuario valor : servidor.getUsuarios().values()) {
			   				usuarios.add(valor.getNombreUsuario());
			   				ArrayList<String> lista_ficheros = new ArrayList<String>();
			   				for(String fichero : valor.getFicheros()) {
			   					lista_ficheros.add(fichero);
			   				}
			   				ficheros_usuarios.add(lista_ficheros);	
			   			}
			   			monitor.release_read();
			   			
			   			out.writeObject(new MensajeConfirmacionListaUsuarios("Servidor", m.getOrigen(), usuarios, ficheros_usuarios));
			   			out.flush();
				  		break;
			   		case CERRAR_CONEXION:
			   			MensajeCerrarConexion mcc = (MensajeCerrarConexion) m;
			   			String userName=mcc.getOrigen();
			   		
			   			//ELIMINAR USUARIO
			   			monitor.request_write();
			   			ArrayList<String> ficheros = servidor.getUsuarios().get(userName).getFicheros();
			   			servidor.getUsuarios().remove(userName);
			   			servidor.getFouts().remove(userName);
			   			servidor.getFins().remove(userName);
			   			monitor.release_write();
			   			
			   			servidor.getLockPuerto().lock();
		   				servidor.setNuevoPuerto(servidor.getNuevoPuerto()-1);
		   				servidor.getLockPuerto().unlock();
			   			
			   			out.writeObject(new MensajeConfirmacionCerrarConexion("Servidor", m.getOrigen(), ficheros));
			   			out.flush();
			   			System.out.println("Desconectado del usuario: " + mcc.getOrigen());
			   			cerrar_conexion = true;
				  		break;
			   		case PEDIR_FICHERO:
			   			MensajePedirFichero mpf = (MensajePedirFichero) m;
			   			String fichero_solicitado = mpf.getNombreFichero();
			   			String propietario_fichero = mpf.getNombrePropietario();
			   			boolean existe_fichero=false;
			   			ObjectOutputStream out2 = null;
			   			
			   			//OBTENER FOUT DEL PROPIETARIO DEL FICHERO (SI EXISTE)
			   			monitor.request_read();
			   			boolean existe_propietario=servidor.getUsuarios().containsKey(propietario_fichero);
			   			if(existe_propietario) {
			   				existe_fichero=servidor.getUsuarios().get(propietario_fichero).getFicheros().contains(fichero_solicitado);
			   			}
			   			if(existe_propietario&&existe_fichero){
			   				out2=servidor.getFouts().get(propietario_fichero);
			   			}
			   			monitor.release_read();
			   			
			   			if(existe_propietario&&existe_fichero){
			   				//ENVIAR MENSAJE AL PROPIETARIO DEL FICHERO
				   			out2.writeObject(new MensajeEmitirFichero(m.getOrigen(), propietario_fichero, fichero_solicitado));
				   			out2.flush();
			   			}
			   			else {
			   				String error;
			   				if(!existe_propietario) {
			   					error="No hay ning�n usuario con nombre '" + propietario_fichero+"'.";
			   					System.err.println(error);
			   					out.writeObject(new MensajeNoHayFichero("Servidor", m.getOrigen(),error));
				   				out.flush();
			   				}else {
			   					error="No hay ning�n fichero con nombre '" + fichero_solicitado+"'.";
			   					System.err.println(error);
			   					out.writeObject(new MensajeNoHayFichero("Servidor", m.getOrigen(),error));
				   				out.flush();
			   				}
			   				
			   			}
				  		break;
			   		case PREPARADO_CS:
			   			MensajePreparadoCS mpcs = (MensajePreparadoCS) m;
			   			//OBTENER FOUT DEL USARIO QUE PIDE EL FICHERO
			   			monitor.request_read();
			   			ObjectOutputStream out1 = servidor.getFouts().get(m.getDestino());
			   			monitor.release_read();
			   			
			   			out1.writeObject(new MensajePreparadoSC(m.getOrigen(), m.getDestino(), mpcs.getIP(), mpcs.getPuerto()));
			   			out1.flush();
			   			break;
			   		case ANNADIR_FICHERO_USUARIO:
			   			MensajeAnnadirFicheroUsuario mafu = (MensajeAnnadirFicheroUsuario) m;
			   			monitor.request_write();
			   			servidor.getUsuarios().get(mafu.getOrigen()).getFicheros().add(mafu.getFichero());
			   			monitor.release_write();
			   			break;
			   		default:
			   			break;
			    }
			}
		} catch (IOException | ClassNotFoundException | InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
