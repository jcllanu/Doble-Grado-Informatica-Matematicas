package parte2;

import java.io.*;
import java.nio.file.*;

public class Fichero implements Serializable {
	
private static final long serialVersionUID = 1L;

	private String contenido;
	private String nombre;
	private String propietario;
	
	public Fichero(String path, String nombre, String propietario) {
		try {
			this.nombre=nombre;
			this.propietario=propietario;
			this.contenido = new String(Files.readAllBytes(Paths.get(path)));
		} catch (IOException e) {
			System.err.println("No se ha podido leer el fichero. Excepcion: " + e.getLocalizedMessage());
		}
	}
	
	public String getNombre() {
		return nombre;
	}
	public String getPropietario() {
		return propietario;
	}
	
	public String getContenido() {
		return this.contenido;
	}
	
	public void print() {
		System.out.print(contenido);
	}

}
