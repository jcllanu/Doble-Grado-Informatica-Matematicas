package parte2;

// OK

public class MensajeEmitirFichero extends Mensaje {

	private static final long serialVersionUID = 1L;

	private String nombre_fichero;
	
	public MensajeEmitirFichero(String origen, String destino, String nombre_fichero) {
		super(MensajeType.EMITIR_FICHERO, origen, destino);
		this.nombre_fichero = nombre_fichero;
	}
	
	public String getNombreFichero() {
		return this.nombre_fichero;
	}
}
