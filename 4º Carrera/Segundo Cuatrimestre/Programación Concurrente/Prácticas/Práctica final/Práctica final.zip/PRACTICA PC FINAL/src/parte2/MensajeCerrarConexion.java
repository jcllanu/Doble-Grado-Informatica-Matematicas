package parte2;

// OK

public class MensajeCerrarConexion extends Mensaje {

	private static final long serialVersionUID = 1L;

	public MensajeCerrarConexion(String origen, String destino) {
		super(MensajeType.CERRAR_CONEXION, origen, destino);
	}


}
