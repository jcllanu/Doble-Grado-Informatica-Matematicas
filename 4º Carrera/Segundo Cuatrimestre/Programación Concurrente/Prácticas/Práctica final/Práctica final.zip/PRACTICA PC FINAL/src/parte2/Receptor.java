package parte2;

import java.io.*;
import java.net.*;

public class Receptor extends Thread {

	private int puerto;
	LockBakery lock;
	private String ip_peer;
	private String usuario;
	private ObjectOutputStream fout;
	
	public Receptor(int puerto, String ip_peer, LockBakery lock, String usuario, ObjectOutputStream fout) {
		super();
		this.puerto = puerto;
		this.lock = lock;
		this.ip_peer = ip_peer;
		this.usuario = usuario;
		this.fout = fout;
	}
	
	public void run() {
		try {
			Socket socket = new Socket(ip_peer, puerto);
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			Fichero f = (Fichero) in.readObject();
			//sleep(10000);// Simular el tiempo de descarga
			socket.close();
			
			File file = new File(System.getProperty("user.dir") + "/" + this.usuario + "/ficheros/" + f.getPropietario() + "_" + f.getNombre());
			try { 
				if (file.createNewFile()) {  
					BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
					writer.append(f.getContenido());
					writer.close();
					fout.writeObject(new MensajeAnnadirFicheroUsuario(this.usuario, "Servidor", f.getPropietario() + "_" + f.getNombre()));
					fout.flush();
					
					lock.takeLock(3);
					System.out.println("(!) Descarga finalizada (Fichero: "+f.getNombre()+", Usuario: "+f.getPropietario()+")");
					System.out.println("---------------------------------------------------");
					f.print();
					System.out.println("");
					System.out.println("---------------------------------------------------");
					
					lock.releaseLock(3);
				}
			}   
			catch (IOException e) {  
				System.err.println("Debes tener una carpeta en tu directorio de nombre " + this.usuario + " y dentro de ella una carpeta de nombre 'ficheros'");   
			}  
			
		} catch (IOException | ClassNotFoundException e) { // | InterruptedException cuando el sleep est� descomentado
			e.printStackTrace();
		}
	}

}
