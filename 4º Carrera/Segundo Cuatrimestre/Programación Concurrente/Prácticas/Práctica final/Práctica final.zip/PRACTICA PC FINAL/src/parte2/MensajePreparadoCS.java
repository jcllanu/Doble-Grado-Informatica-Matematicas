package parte2;

public class MensajePreparadoCS extends Mensaje {

private static final long serialVersionUID = 1L;
	
	private String direccionIP;
	private int puerto;
	public MensajePreparadoCS(String origen, String destino, String direccionIP, int puerto) {
		super(MensajeType.PREPARADO_CS, origen, destino);
		this.direccionIP = direccionIP;
		this.puerto = puerto;
	}
	
	public String getIP() {
		return this.direccionIP;
	}
	
	public int getPuerto() {
		return this.puerto;
	}
	
}
