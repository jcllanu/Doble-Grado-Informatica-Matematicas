package parte2;

public class IntVol {
	volatile int n;
	public IntVol() {
		this.n=0;
	}
	public IntVol(int n) {
		this.n=n;
	}
	public int get() {
		return n;
	}
	public void set(int m) {
		this.n=m;
	}
}
