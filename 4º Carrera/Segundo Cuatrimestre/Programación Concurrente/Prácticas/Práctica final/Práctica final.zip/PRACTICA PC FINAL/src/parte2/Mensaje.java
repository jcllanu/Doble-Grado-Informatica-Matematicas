package parte2;

import java.io.*;

// MENSAJE (CLASE ABSTRACTA)

public abstract class Mensaje implements Serializable {

	private static final long serialVersionUID = 1L;
	
	MensajeType tipo;
	String origen;
	String destino;
	
	public Mensaje(MensajeType tipo, String origen, String destino) {
		super();
		this.tipo = tipo;
		this.origen = origen;
		this.destino = destino;
	}
	
	public MensajeType getTipo() {
		return this.tipo;
	}
	
	public String getOrigen() {
		return this.origen;
	}
	
	public String getDestino() {
		return this.destino;
	}


}
