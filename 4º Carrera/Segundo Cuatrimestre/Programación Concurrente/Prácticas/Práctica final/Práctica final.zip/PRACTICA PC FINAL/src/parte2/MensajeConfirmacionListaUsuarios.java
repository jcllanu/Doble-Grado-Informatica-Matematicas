package parte2;

import java.util.*;

public class MensajeConfirmacionListaUsuarios extends Mensaje {

	private static final long serialVersionUID = 1L;

	private ArrayList<String> lista_usuarios;
	private ArrayList<ArrayList<String>> lista_ficheros;
	
	public MensajeConfirmacionListaUsuarios(String origen, String destino, ArrayList<String> lista_usuarios, ArrayList<ArrayList<String>> lista_ficheros) {
		super(MensajeType.CONFIRMACION_LISTA_USUARIOS, origen, destino);
		this.lista_ficheros = lista_ficheros;
		this.lista_usuarios = lista_usuarios;
	}
	
	public ArrayList<String> getListaUsuarios(){
		return this.lista_usuarios;
	}

	public ArrayList<ArrayList<String>> getListaFicheros(){
		return this.lista_ficheros;
	}

}
