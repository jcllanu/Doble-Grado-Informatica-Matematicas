package parte2;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

// EJECUCI�N DE UN CLIENTE

public class ClienteExec {
	
		private Socket socket;
		private ObjectInputStream fin;
		private ObjectOutputStream fout;
		private String nombre_cliente;
		private String ip_local;
		private final static int puerto = 999;
		private ArrayList<String> ficheros = new ArrayList<String>();
		
		private static Scanner scanner = new Scanner(System.in);
		private Semaphore sem_espera;
		private LockBakery lock;
		boolean conexion_abortada=false;
		private String ipServer="localhost";
		
		protected ClienteExec() throws UnknownHostException, IOException {
			//Creaci�n del canal de comunicaci�n con el servidor
			this.socket = new Socket(ipServer, puerto);
			this.fin = new ObjectInputStream(socket.getInputStream());
			this.fout = new ObjectOutputStream(socket.getOutputStream());
			this.sem_espera = new Semaphore(0, true);
			this.lock = new LockBakery(3);
		}
		
		protected void exec() throws InterruptedException, IOException {
			//Se le pregunta el nombre al usuario
			System.out.print("�C�mo te llamas?: ");
			String input = scanner.nextLine();
			
			
			//Guardamos nombre e ip del usuario
			this.nombre_cliente = input;
			InetAddress address = InetAddress.getLocalHost();
			this.ip_local = address.getHostAddress();
			
			//Se crea el OyenteServidor
			Thread os = new OS(sem_espera,lock, this);
			os.start();
			
			//Se a�aden a la lista de ficheros que aporta este usuario los nombres de los archivos del 
			//documento /<nombre_cliente>/ficheros.txt
			try {
				FileReader fr = new FileReader (new File(System.getProperty("user.dir") + "/" + this.nombre_cliente + "/ficheros.txt"));
				BufferedReader br = new BufferedReader(fr);
				String linea;
				while((linea=br.readLine())!=null) {this.ficheros.add(linea);}
				br.close();
			}catch(Exception e) {
				System.out.println("(!) Informaci�n:");
				System.out.println("Para aportar informaci�n al sistema debes tener una carpeta en el directorio cuyo nombre sea tu nombre de usuario.");
				System.out.println("Dentro de esa carpeta debes tener un archivo \"ficheros.txt\" con el nombre de los ficheros de texto que aportas al sistema y otra carpeta \\ficheros con dichos ficheros de texto.");
				System.out.println("Por defecto no aportaras informaci�n.");
			}
		   
		    
		    
			
		    //El cliente env�a un mensaje de conexi�n al servidor
			MensajeConexion mensaje_enviar = new MensajeConexion(nombre_cliente, "Servidor", ip_local, ficheros);
			fout.writeObject(mensaje_enviar);
			fout.flush();
			
			//Espera a que el OS haga un sem_espera.release() cuando le confirmen la conexion
			sem_espera.acquire();
			if(conexion_abortada) {
				scanner.close();
				socket.close();
				System.exit(1);
			}
			
			//Men� para el usuario
			int comando = -1;
			while (comando != 4) {
				lock.takeLock(1);
				System.out.println("\nIntroduce un comando: \n\t 1) Consultar nombres de los usuarios actuales \n\t 2) Descargar informaci�n \n\t 3) Comprobar descargas pendientes \n\t 4) Cerrar conexi�n");
				comando = Integer.parseInt(scanner.next());
				switch (comando) {
					case 1 : 
						fout.writeObject(new MensajeListaUsuarios(nombre_cliente, "Servidor"));
						fout.flush();
						lock.releaseLock(1);
						sem_espera.acquire();
						break;
					case 2 :
						System.out.print("Pon el nombre del fichero: ");
						String nombre_fichero = scanner.next();
						System.out.print("Pon el nombre del propietario de este fichero: ");
						String nombre_propietario = scanner.next();
						fout.writeObject(new MensajePedirFichero(nombre_cliente, "Servidor", nombre_fichero,nombre_propietario));
						fout.flush();
						lock.releaseLock(1);
						//El usuario NO espera hasta que se realice la descarga
						break;
					case 3 :
						System.out.println("Comprobando descargas pendientes... ");
						lock.releaseLock(1);
						break;
					case 4 :
						fout.writeObject(new MensajeCerrarConexion(nombre_cliente, "Servidor"));
						fout.flush();
						lock.releaseLock(1);
						break;
					default :
						System.out.println("El comando debe ser 1, 2 o 3");
						lock.releaseLock(1);
						break;
				}
			}
			os.join();
			scanner.close();
			socket.close();
		}
			
		protected String getIPlocal() {
			return this.ip_local;
		}
		
		protected String getNombre() {
			return this.nombre_cliente;
		}
		
		public ObjectInputStream getInputStream() {
			return this.fin;
		}
		
		public ObjectOutputStream getOutputStream() {
			return this.fout;
		}
		public void abortarConexion() {conexion_abortada=true;}
		
}
