package parte2;

// OK

public class MensajeListaUsuarios extends Mensaje {

	private static final long serialVersionUID = 1L;

	public MensajeListaUsuarios(String origen, String destino) {
		super(MensajeType.LISTA_USUARIOS, origen, destino);
	}

}
