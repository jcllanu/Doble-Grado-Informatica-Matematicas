package ejer_3;

import java.util.concurrent.Semaphore;

public class Main {
	
	static final int M = 4;
	static final int N = 4;
	static final int K = 2;

	public static void main(String[] args) {
		Productor p[] = new Productor[N];
		Consumidor c[] = new Consumidor[M];
		Semaphore empty = new Semaphore(K,true);
		Semaphore full = new Semaphore(0,true);
		Semaphore mutexP = new Semaphore(1,true);
		Semaphore mutexC = new Semaphore(1,true);
		Buffer buf = new Buffer(K);
		for (int i = 0; i < N; i++) {
			p[i] = new Productor(i, empty, full, mutexP, buf);
			p[i].start();    
		}
		for (int i = 0; i < M; i++) {
			c[i] = new Consumidor(i, empty, full, mutexC, buf);
			c[i].start();	    
		}
		for (int i = 0; i < N; i++) {
			try {
				p[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
		for (int i = 0; i < M; i++) {
			try {
				c[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
	}
	
	static class Productor extends Thread implements Almacen  {
		int id;
		Buffer buf;
		Semaphore empty, full, mutexP;
		public Productor (int id, Semaphore empty, Semaphore full, Semaphore mutexP, Buffer buf) {
			this.id = id;
			this.empty = empty;
			this.full = full;
			this.buf = buf;
			this.mutexP = mutexP;
		}
		public void run() {
			for (int i = 0; i < 10; i++) {
				Producto p = new Producto(id, i);
				try {
					empty.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					mutexP.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				almacenar(p);
				System.out.println("Almacenamos el producto: " + p.toString());
				mutexP.release();
				full.release();
			}
		}
		@Override
		public void almacenar(Producto producto) {
			buf.almacenar(producto);
		}
		@Override
		public Producto extraer() {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	static class Consumidor extends Thread implements Almacen  {
		int id;
		Buffer buf;
		Semaphore empty, full, mutexC;
		public Consumidor (int id, Semaphore empty, Semaphore full, Semaphore mutexC, Buffer buf) {
			this.id = id;
			this.empty = empty;
			this.full = full;
			this.buf = buf;
			this.mutexC = mutexC;
		}
		public void run() {
			for (int i = 0; i < 10; i++) {
				try {
					full.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					mutexC.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Producto p = extraer();
				System.out.println("Consumimos el producto: " + p.toString() + " por el hilo: " + id);;
				mutexC.release();
				empty.release();
			}
		}
		@Override
		public void almacenar(Producto producto) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public Producto extraer() {
			return buf.extraer();
		}
	}

}

class Producto {
	int n = 0, k = 0;
	public Producto(int i, int k) {
		this.n = i;
		this.k = k;
	}
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
	public String toString() {
		return "(" + n + "," + k + ")";
	}
}

class Buffer {
	Producto[] buf;
	int K;
	private int ini = 0, fin = 0;
	public Buffer(int K) {
		buf = new Producto[K];
		this.K = K;
	}
	public void almacenar(Producto p) {
		buf[fin] = p;
		fin = (fin + 1) % K;
	}
	public Producto extraer() {
		Producto p = buf[ini];
		buf[ini] = null;
		ini = (ini + 1) % K;
		return p;
	}
}