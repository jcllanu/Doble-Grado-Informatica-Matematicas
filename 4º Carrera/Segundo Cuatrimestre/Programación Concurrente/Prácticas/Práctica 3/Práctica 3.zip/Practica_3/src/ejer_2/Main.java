package ejer_2;

import java.util.concurrent.Semaphore;

public class Main {
	
	static final int M = 2;
	static final int N = 2;

	public static void main(String[] args) {
		Productor p[] = new Productor[N];
		Consumidor c[] = new Consumidor[M];
		Semaphore empty = new Semaphore(1,true);
		Semaphore full = new Semaphore(0,true);
		Buffer buf = new Buffer();
		for (int i = 0; i < N; i++) {
			p[i] = new Productor(i, empty, full, buf);
			p[i].start();    
		}
		for (int i = 0; i < M; i++) {
			c[i] = new Consumidor(i, empty, full, buf);
			c[i].start();	    
		}
		for (int i = 0; i < N; i++) {
			try {
				p[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
		for (int i = 0; i < M; i++) {
			try {
				c[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}   
		}
	}
	
	static class Productor extends Thread implements Almacen  {
		int id;
		Buffer buf;
		Semaphore empty, full;
		public Productor (int id, Semaphore empty, Semaphore full, Buffer buf) {
			this.id = id;
			this.empty = empty;
			this.full = full;
			this.buf = buf;
		}
		public void run() {
			for (int i = 0; i < 10; i++) {
				Producto p = new Producto(id);
				try {
					empty.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				almacenar(p);
				System.out.println("Almacenamos el producto: " + id);
				full.release();
			}
		}
		@Override
		public void almacenar(Producto producto) {
			buf.almacenar(producto);
		}
		@Override
		public Producto extraer() {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	static class Consumidor extends Thread implements Almacen  {
		int id;
		Buffer buf;
		Semaphore empty, full;
		public Consumidor (int id, Semaphore empty, Semaphore full, Buffer buf) {
			this.id = id;
			this.empty = empty;
			this.full = full;
			this.buf = buf;
		}
		public void run() {
			for (int i = 0; i < 10; i++) {
				try {
					full.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Producto p = extraer();
				System.out.println("Consumimos el producto: " + p.get() + " por el hilo: " + id);;
				empty.release();
			}
		}
		@Override
		public void almacenar(Producto producto) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public Producto extraer() {
			return buf.extraer();
		}
	}

}

class Producto {
	int n = 0;
	public Producto(int i) {
		this.n = i;
	}
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
}

class Buffer {
	Producto[] buf = new Producto[1];
	public void almacenar(Producto p) {
		buf[0] = p;
	}
	public Producto extraer () {
		Producto p = buf[0];
		buf[0] = null;
		return p;
	}
}