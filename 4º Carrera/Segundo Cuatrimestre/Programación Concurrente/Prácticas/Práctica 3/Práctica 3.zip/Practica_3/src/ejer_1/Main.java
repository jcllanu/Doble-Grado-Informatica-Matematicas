package ejer_1;

import java.util.concurrent.Semaphore;

public class Main {

	static final int M = 600;
	static final int N = 600;
	volatile static boolean inInc = false;
	volatile static boolean inDec = false;
	volatile static int last;
	
	private static Semaphore sem = new Semaphore(1, true);

	public static void main(String[] args) {
		Datos d = new Datos();
		HiloIncrementador hi = new HiloIncrementador(d, sem);
		HiloDecrementador hd = new HiloDecrementador(d, sem);
		hi.start();
		hd.start();
		try {
			hi.join();
			hd.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("El valor final es: " +  d.n);
	}
	
	static class HiloIncrementador extends Thread  {
		Datos d;
		Semaphore sem;
		public HiloIncrementador (Datos d, Semaphore sem) {
			this.d = d;
			this.sem = sem;
		}
		
		public void run() {
			for(int i = 0; i < N; i++) {
				try {
					sem.acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				//Secci�n cr�tica
				d.n++;
				sem.release();
			}
		}
	}
	
	static class HiloDecrementador extends Thread  {
		Datos d;
		Semaphore sem;
		public HiloDecrementador (Datos d, Semaphore sem) {
			this.d = d;
			this.sem = sem;
		}
		public void run() {
			for(int i = 0; i < N; i++) {
				try {
					sem.acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				//Secci�n cr�tica
				d.n--;
				sem.release();
			}
		}
	}
	
}

class Datos {
	int n = 0;
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
}
