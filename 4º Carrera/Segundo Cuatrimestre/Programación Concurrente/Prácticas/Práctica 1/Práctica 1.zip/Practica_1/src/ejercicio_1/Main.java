package ejercicio_1;

public class Main {
	
	static final int N = 5;

	public static void main(String[] args) {
		Hilo h[] = new Hilo[N];
		for (int i = 0; i < N; i++) {
			h[i] = new Hilo(i);
		    h[i].start();
		}
		for (int i = 0; i < N; i++) {
		    try {
				h[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Han terminado todos los hilos");
	}

}

class Hilo extends Thread  {
	static final int T = 500;
	int id_hilo;
	public Hilo (int i) {
		this.id_hilo = i;
	}
	public void run() {
		System.out.println(id_hilo);
		try {
			Thread.sleep(T);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(id_hilo);
	}
}