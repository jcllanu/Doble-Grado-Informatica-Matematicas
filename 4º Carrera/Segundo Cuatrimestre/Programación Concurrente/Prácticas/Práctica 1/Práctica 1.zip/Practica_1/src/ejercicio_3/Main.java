package ejercicio_3;

public class Main {
	
	static final int N = 20;
	static int [][] a = new int[N][N];
	static int [][] b = new int[N][N];

	public static void main(String[] args) {
		HiloFila h[] = new HiloFila[N];
		Matriz m = new Matriz(N);
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				a[i][j] = i + j;
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				b[i][j] = i;
			}
		}
		for (int i = 0; i < N; i++) {
			h[i] = new HiloFila(i, m);
		    h[i].start();
		}
		for (int i = 0; i < N; i++) {
		    try {
				h[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				System.out.print(m.c[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	static class HiloFila extends Thread  {
		static final int T = 500;
		int i;
		Matriz m;
		public HiloFila (int i, Matriz m) {
			this.i = i;
			this.m = m;
		}
		public void run() {
			for(int j = 0; j < N; j++) {
				m.c[i][j] = 0;
				for(int k = 0; k < N; k++) {
					m.c[i][j] += a[i][k] * b[k][j];
				}
			}
		}
	}

}


class Matriz {
	int [][] c;
	int N;
	public Matriz(int N) {
		this.N = N;
		c = new int[N][N];
	}
}
