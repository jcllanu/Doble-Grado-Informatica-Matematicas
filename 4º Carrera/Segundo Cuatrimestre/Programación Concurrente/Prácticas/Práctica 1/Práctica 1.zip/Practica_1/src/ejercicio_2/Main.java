package ejercicio_2;

public class Main {
	
	// public static int n = 0;   NO!!!
	static final int M = 600;
	static final int N = 600;

	public static void main(String[] args) {
		HiloIncrementador hi[] = new HiloIncrementador[M];
		HiloDecrementador hd[] = new HiloDecrementador[M];
		Datos d = new Datos();
		for (int i = 0; i < M; i++) {
			hi[i] = new HiloIncrementador(i, d);
			hd[i] = new HiloDecrementador(i, d);
		    hi[i].start();
		    hd[i].start();
		}
		for (int i = 0; i < M; i++) {
		    try {
				hi[i].join();
				hd[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("El valor final es: " +  d.n);
	}
	
	static class HiloIncrementador extends Thread  {
		int id_hilo;
		Datos d;
		public HiloIncrementador (int i, Datos d) {
			this.id_hilo = i;
			this.d = d;
		}
		public void run() {
			for(int i = 0; i < N; i++) {
				d.n++;
			}
		}
	}
	
	static class HiloDecrementador extends Thread  {
		int id_hilo;
		Datos d;
		public HiloDecrementador (int i, Datos d) {
			this.id_hilo = i;
			this.d = d;
		}
		public void run() {
			for(int i = 0; i < N; i++) {
				d.n--;
			}
		}
	}

}

class Datos {
	int n = 0;
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
}
