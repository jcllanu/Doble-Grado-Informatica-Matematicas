package ejercicio_2;

public class LockRompeEmpate {
	
	int N;
	
	IntVol[] in; //Arrays de enteros vol�tiles
	IntVol[] last;
	
	public LockRompeEmpate (int N) {
		this.N = N;
		in = new IntVol[N];
		last = new IntVol[N];
		for(int i=0; i<N;i++) {
			in[i]=new IntVol();
			last[i]=new IntVol();
		}
	}
	
	// takeLock y releaseLock se llaman con el identificador del proceso de 1 a N
	
	public void takeLock (int i) {
		for (int j = 1; j <= N; j++) {
			in[i-1].set(j);
			last[j-1].set(i);
			for (int k = 1; k <= N; k++) {
				if (k != i) {
					while (in[k-1].get() >= in[i-1].get() && last[j-1].get() == i) {};
				}
			}
		}
	}
	
	public void releaseLock(int i) {
		in[i-1].set(0);
	}
	
}
