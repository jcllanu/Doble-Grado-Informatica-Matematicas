package ejercicio_2;
import java.util.concurrent.atomic.AtomicInteger;

public class LockTicket {
	
	int N;
	
	volatile AtomicInteger number;
	volatile int next;
	IntVol[] turnos;
	
	public LockTicket (int N) {
		this.N = N;
		number=new AtomicInteger(1);
		next=1;
		turnos = new IntVol[N];
		for(int i=0; i<N;i++) {
			turnos[i]=new IntVol();
		}
	}
	
	public void takeLock (int i) {
		turnos[i - 1].set(number.getAndIncrement());
		while (turnos[i - 1].get() != next) {};
	}
	
	public void releaseLock(int i) {
		next = next + 1;
	}

}
