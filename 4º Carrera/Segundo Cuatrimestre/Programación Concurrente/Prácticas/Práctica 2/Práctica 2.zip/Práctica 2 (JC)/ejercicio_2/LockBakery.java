package ejercicio_2;


public class LockBakery {
	
	int N;
	
	IntVol[] turnos;
	
	public LockBakery (int N) {
		this.N = N;
		turnos = new IntVol[N];
		for(int i=0; i<N;i++) {
			turnos[i]=new IntVol();
		}
	}
	
	public void takeLock (int i) {
		turnos[i-1].set(1);
		turnos[i - 1].set(maximo()+1);
		
		for (int j = 1; j <= N; j++) {
			if (j != i) {
				while (turnos[j - 1].get() != 0 && mayor(turnos[i - 1].get(),i,turnos[j - 1].get(),j)) {};
			}
		}
	}
	
	public void releaseLock(int i) {
		turnos[i - 1].set(0);
	}
	private int maximo() {
		int max=-1;
		for(int i=0; i<turnos.length;i++) {
			if(turnos[i].get()>=max) {
				max=turnos[i].get();
			}
		}
		return max;
	}
	private boolean mayor(int a, int b, int c, int d) {
		return a>c ||(a==c && b>d);
	}
}
