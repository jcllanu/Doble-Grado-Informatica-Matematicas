package ejercicio_1_rompe_empate;

public class Main {

    // public static int n = 0;   NO!!!
	static final int M = 600;
	static final int N = 600;
	volatile static boolean inInc = false;
	volatile static boolean inDec = false;
	volatile static int last;

	public static void main(String[] args) {
		
		Datos d = new Datos();
		HiloIncrementador hi = new HiloIncrementador(d);
		HiloDecrementador hd = new HiloDecrementador(d);
		hi.start();
		hd.start();
		try {
			hi.join();
			hd.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("El valor final es: " +  d.n);
	}
	
	static class HiloIncrementador extends Thread  {
		Datos d;
		public HiloIncrementador (Datos d) {
			this.d = d;
		}
		
		public void run() {
			for(int i = 0; i < N; i++) {
				//Antes de entrar en la secci�n cr�tica
				inInc=true;
				last=1;
				while(inDec && last==1) {}
				
				//Secci�n cr�tica
				d.n++;
				
				//Tras ejecutar la secci�n cr�tica
				inInc=false;
			}
		}
	}
	
	static class HiloDecrementador extends Thread  {
		Datos d;
		public HiloDecrementador (Datos d) {
			this.d = d;
		}
		public void run() {
			for(int i = 0; i < N; i++) {
				//Antes de entrar en la secci�n cr�tica
				inDec=true;
				last=2;
				while(inInc && last==2) {}
				
				//Secci�n cr�tica
				d.n--;
				
				//Tras ejecutar la secci�n cr�tica
				inDec=false;
			}
		}
	}
	
}

class Datos {
	int n = 0;
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
}

