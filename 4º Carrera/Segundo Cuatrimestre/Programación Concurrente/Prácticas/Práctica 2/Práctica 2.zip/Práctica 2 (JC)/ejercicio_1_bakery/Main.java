package ejercicio_1_bakery;

public class Main {

    // public static int n = 0;   NO!!!
	static final int M = 600;
	static final int N = 600;
	volatile static int turn1 =0;
	volatile static int turn2 =0;
	
	public static void main(String[] args) {
		Datos d = new Datos();
		HiloIncrementador hi = new HiloIncrementador(d);
		HiloDecrementador hd = new HiloDecrementador(d);
		hi.start();
		hd.start();
		try {
			hi.join();
			hd.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("El valor final es: " +  d.n);
	}
	
	static class HiloIncrementador extends Thread  {
		Datos d;
		public HiloIncrementador (Datos d) {
			this.d = d;
		}
		public void run() {
			for(int i = 0; i < N; i++) {
				//Antes de entrar en la secci�n cr�tica
				turn1=1;
				turn1=turn2+1;
				while(turn2!=0 && turn1>turn2) {}
				//Secci�n cr�tica
				d.n++;
				//Tras ejecutar la secci�n cr�tica
				turn1=0;
			}
		}
	}
	
	static class HiloDecrementador extends Thread  {
		Datos d;
		public HiloDecrementador (Datos d) {
			this.d = d;
		}
		public void run() {
			for(int i = 0; i < N; i++) {
				//Antes de entrar en la secci�n cr�tica
				turn2=1;
				turn2=turn1+1;
				while(turn1!=0 && turn2>=turn1) {}
				//Secci�n cr�tica
				d.n--;
				//Tras ejecutar la secci�n cr�tica
				turn2=0;
			}
		}
	}
	
}

class Datos {
	int n = 0;
	int get() {
		return n;
	}
	void set(int n_nuevo) {
		n = n_nuevo;
	}
}

