package alex;

import asint.ClaseLexica;

public class ALexOperations {
  private AnalizadorLexicoTiny alex;
  public ALexOperations(AnalizadorLexicoTiny alex) {
   this.alex = alex;   
  }
  
  
  public UnidadLexica unidadCorIzq() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.CA,
                                         alex.lexema()); 
  } 
  public UnidadLexica unidadCorDer() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.CC,
                                         alex.lexema()); 
  } 
  
  
  public UnidadLexica unidadPAp() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PAP); 
  } 
  public UnidadLexica unidadPCierre() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PCIERRE); 
  } 
  
  public UnidadLexica unidadEnt() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ENT,alex.lexema()); 
  } 
  public UnidadLexica unidadReal() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.REAL,alex.lexema()); 
  } 
  
  
  public UnidadLexica unidadFilter() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.FILTER); 
  } 
  public UnidadLexica unidadMap() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MAP); 
  } 
  public UnidadLexica unidadReduce() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.REDUCE); 
  } 
  public UnidadLexica unidadPrint() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PRINT); 
  } 
  
  
  public UnidadLexica unidadId() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.IDEN,
                                         alex.lexema()); 
  } 

  
  public UnidadLexica unidadSuma() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MAS); 
  } 
  public UnidadLexica unidadResta() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MENOS); 
  } 
  public UnidadLexica unidadMul() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.POR); 
  } 
  public UnidadLexica unidadDiv() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.DIV); 
  } 
  
  
  public UnidadLexica unidadAsignacion() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ASIG); 
  } 
  public UnidadLexica unidadComa() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.COMA); 
  } 
  public UnidadLexica unidadConcatenar() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.HASH); 
  } 
  
  
  public UnidadLexica unidadIgualBool() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.IGUAL); 
  } 
  public UnidadLexica unidadDesBool() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.DESIGUAL); 
  } 
  public UnidadLexica unidadMenorBool() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MENOR); 
  } 
  public UnidadLexica unidadMayorBool() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MAYOR); 
  } 
  
  
  public UnidadLexica unidadEof() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.EOF); 
  }
}
