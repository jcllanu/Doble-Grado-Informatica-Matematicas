package ast;

public class NodoWhile extends Nodo {

	private Nodo cond;
	private Nodo bloc;
    
    public NodoWhile() {
    	super();
    	this.cond = null;
    	this.bloc = null;
    }
    
    public NodoWhile(Nodo cond, Nodo bloc) {
    	super();
    	this.cond = cond;
    	this.bloc = bloc;
    }
    
	public Nodo getCond() {
		return this.cond;
	}
	
	public Nodo getBloc() {
		return this.bloc;
	}
	
	public void setCond(Nodo cond) {
		this.cond = cond;
	}
	
	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public NodeKind nodeKind(){return NodeKind.WHILE;}
    public String toString(){return "WHILE("+cond.toString()+","+bloc.toString()+")";}
}
