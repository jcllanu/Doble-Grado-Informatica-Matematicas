package ast;

public class NodoDeclaracion extends Nodo {

	private Nodo tipo;
	private Nodo iden;
    
    public NodoDeclaracion(Nodo tipo, Nodo iden) {
    	super();
    	this.tipo = tipo;
    	this.iden = iden;
    }
    
    public void setTipo(Nodo tipo) {
    	this.tipo = tipo;
	}
	
	public Nodo getTipo() {
		return this.tipo;
	}
	
	public void setIden(Nodo iden) {
    	this.iden = iden;
	}
	
	public Nodo getIden() {
		return this.iden;
	}
	public NodeKind nodeKind(){return NodeKind.DECLARACION;	}

    public String toString(){return "DECL("+tipo.toString()+","+iden.toString()+")";}
}
