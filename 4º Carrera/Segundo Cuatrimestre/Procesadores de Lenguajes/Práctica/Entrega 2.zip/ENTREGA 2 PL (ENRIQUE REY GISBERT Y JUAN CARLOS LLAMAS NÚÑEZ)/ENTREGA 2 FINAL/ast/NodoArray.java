package ast;

public class NodoArray extends NodoTipo {

	private Nodo param;
	private int tam;
    
    public NodoArray(Nodo param, int tam) {//Constructora para arrays
    	super(Type.ARRAY);
    	this.param = param;
	this.tam = tam;
    }

   
	public void setParam(Nodo param) {
    	this.param = param;
	}
	
	public Nodo getParam() {
		return this.param;
	}

	public void setTam(int tam) {
    	this.tam = tam;
	}
	
	public int getTam() {
		return this.tam;
	}

    public String toString(){return "ARRAY("+param.toString()+","+tam+")";}
}

