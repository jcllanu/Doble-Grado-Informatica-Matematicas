package ast;

public class NodoIf extends Nodo {

	private Nodo cond;
	private Nodo thenBloc;

	public NodoIf() {
		super();
		this.cond = null;
		this.thenBloc = null;
	}
	
	public NodoIf(Nodo cond, Nodo thenBloc) {
		super();
		this.cond = cond;
		this.thenBloc = thenBloc;
	}
	
	public NodoIf(Nodo cond, Nodo thenBloc, Nodo elseBloc) {
		super();
		this.cond = cond;
		this.thenBloc = thenBloc;
	}
	
	public Nodo getCond() {
		return this.cond;
	}
	
	public Nodo getThenBloc() {
		return this.thenBloc;
	}
	
	public void setCond(Nodo cond) {
		this.cond = cond;
	}
	
	public void setThenBloc(Nodo thenBloc) {
		this.thenBloc = thenBloc;
	}
	
	public NodeKind nodeKind(){return NodeKind.IF;}
    public String toString(){return "IF("+cond.toString()+","+thenBloc.toString()+")";}
}
