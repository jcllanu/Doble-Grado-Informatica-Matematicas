package ast;

public class NodoIfElse extends Nodo {

	private Nodo cond;
	private Nodo thenBloc;
	private Nodo elseBloc;

	public NodoIfElse() {
		super();
		this.cond = null;
		this.thenBloc = null;
		this.elseBloc = null;
	}
	
	public NodoIfElse(Nodo cond, Nodo thenBloc) {
		super();
		this.cond = cond;
		this.thenBloc = thenBloc;
		this.elseBloc = null;
	}
	
	public NodoIfElse(Nodo cond, Nodo thenBloc, Nodo elseBloc) {
		super();
		this.cond = cond;
		this.thenBloc = thenBloc;
		this.elseBloc = elseBloc;
	}
	
	public Nodo getCond() {
		return this.cond;
	}
	
	public Nodo getThenBloc() {
		return this.thenBloc;
	}
	
	public Nodo getElseBloc() {
		return this.elseBloc;
	}
	
	public void setCond(Nodo cond) {
		this.cond = cond;
	}
	
	public void setThenBloc(Nodo thenBloc) {
		this.thenBloc = thenBloc;
	}
	
	public void setElseBloc(Nodo elseBloc) {
		this.elseBloc = elseBloc;
	}

	public NodeKind nodeKind(){return NodeKind.IFELSE;}
    public String toString(){return "IF-ELSE("+cond.toString()+","+thenBloc.toString()+","+elseBloc.toString()+")";}
}
