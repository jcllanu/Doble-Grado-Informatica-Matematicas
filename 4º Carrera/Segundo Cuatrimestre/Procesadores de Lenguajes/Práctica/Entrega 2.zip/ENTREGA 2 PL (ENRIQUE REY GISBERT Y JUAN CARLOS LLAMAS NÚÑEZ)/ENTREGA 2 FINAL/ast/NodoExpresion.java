package ast;

public abstract class NodoExpresion extends Nodo {
    public NodeKind nodeKind() {return NodeKind.EXPRESION;}
}
