package ast;

public class NodoLlamada extends Nodo {
	
	private String nombre;
	private Nodo args;
	
	public NodoLlamada()
	{
		super();
		this.nombre = "";
		this.args = null;
	}
	
	public NodoLlamada(String nombre)
	{
		super();
		this.nombre = nombre;
		this.args = null;
	}
	
	public NodoLlamada(String nombre, Nodo args)
	{
		super();
		this.nombre = nombre;
		this.args = args;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Nodo getArgs() {
		return args;
	}

	public void setArgs(Nodo args) {
		this.args = args;
	}

	public NodeKind nodeKind(){return NodeKind.PRINT;}
    public String toString(){return "CALL("+nombre+","+args.toString()+")";}
}
