package ast;

public class NodoInt extends NodoTipo {
public NodoInt() {
    	super(Type.INT);
    }

    public String toString(){return "INT";}
}

