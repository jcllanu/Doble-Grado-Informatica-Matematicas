package ast;

public class NodoCase extends Nodo {

	private Nodo expr;
	private Nodo bloc;
    
    public NodoCase() {
    	super();
    	this.expr = null;
    	this.bloc = null;
    }
    
    public NodoCase(Nodo expr, Nodo bloc) {
    	super();
    	this.expr = expr;
    	this.bloc = bloc;
    }
    
	public Nodo getexpr() {
		return this.expr;
	}
	
	public Nodo getBloc() {
		return this.bloc;
	}
	
	public void setexpr(Nodo expr) {
		this.expr = expr;
	}
	
	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public NodeKind nodeKind(){return NodeKind.CASE;}
    public String toString(){return "CASE("+expr.toString()+","+bloc.toString()+")";}
}
