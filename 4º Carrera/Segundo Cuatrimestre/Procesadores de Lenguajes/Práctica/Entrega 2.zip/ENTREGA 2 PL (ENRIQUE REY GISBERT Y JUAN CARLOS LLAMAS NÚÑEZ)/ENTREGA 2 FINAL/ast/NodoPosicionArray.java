package ast;

public class NodoPosicionArray extends Nodo{
    private Nodo pm;
    private Nodo expr;

    public NodoPosicionArray(Nodo pm,Nodo expr) {
        this.pm = pm;
        this.expr = expr;
    }

    public String toString(){return "[]("+pm.toString()+","+expr.toString()+")";}
    
    public NodeKind nodeKind(){return NodeKind.POSICIONARRAY;}
}
