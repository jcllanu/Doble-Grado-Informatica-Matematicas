package ast;

public enum OperandoU {
  MENOS,NOT
}
