package ast;

public class NodoConstanteBool extends NodoExpresion {
    private boolean val;

    public NodoConstanteBool(boolean val) {
        this.val = val;
    }

    public boolean getVal() {return val;}

    public void setVal(boolean val) {this.val=val;}

    public String toString() {
        if(val) { return "true"; }
        else {return "false"; }
    }
}
