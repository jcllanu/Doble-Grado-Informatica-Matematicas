package ast;

public class NodoOperacionUnaria extends NodoExpresion {
    private Nodo opnd1;
    private OperandoU op;

    public NodoOperacionUnaria(Nodo opnd1, OperandoU op) {
        this.opnd1 = opnd1;
        this.op = op;
    }


    public Nodo getOpnd1() {return opnd1;}

    public void setOpnd1(Nodo opnd1) {this.opnd1=opnd1;}

    public String toString() {
        String aux[]={"menos","not"};
        return aux[op.ordinal()]+"("+getOpnd1().toString()+")";
    }
}
