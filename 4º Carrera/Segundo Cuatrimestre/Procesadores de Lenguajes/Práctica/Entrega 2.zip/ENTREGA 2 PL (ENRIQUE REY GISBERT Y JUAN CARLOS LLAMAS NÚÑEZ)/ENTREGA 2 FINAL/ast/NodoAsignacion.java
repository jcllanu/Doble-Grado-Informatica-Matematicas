package ast;

public class NodoAsignacion extends Nodo {

	private Nodo posmem;
	private Nodo expr;
    
    public NodoAsignacion(Nodo posmem, Nodo expr) {
    	super();
    	this.posmem = posmem;
		this.expr = expr;
    }
    
	
	public void setPosmem(Nodo posmem) {
    	this.posmem = posmem;
	}
	
	public Nodo getPosmem() {
		return this.posmem;
	}

	public void setExpr(Nodo expr) {
    	this.expr = expr;
	}
	
	public Nodo getExpr() {
		return this.expr;
	}
	public NodeKind nodeKind(){return NodeKind.ASIGNACION;	}

    public String toString(){return "ASIGN("+posmem.toString()+","+expr.toString()+")";}
}

