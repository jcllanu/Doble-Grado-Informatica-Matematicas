package ast;

import java.util.*;

public abstract class Lista extends Nodo {

	protected ArrayList<Nodo> lista;
	protected Nodo expr;
	
	public Lista(){
		super();
		this.expr = null;
		this.lista = new ArrayList<Nodo>();
	}
	
	public Lista(Nodo ins){
		super();
		this.expr = null;
		this.lista = new ArrayList<Nodo>();
    		this.lista.add(0, ins);
	}
	
	public void setExpr(Nodo expr) {
		this.expr = expr;
	}

	public void add(Nodo ins){
    	this.lista.add(0, ins);
    }

}
