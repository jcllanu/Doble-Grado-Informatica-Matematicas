package ast;

public class NodoBool extends NodoTipo {

    public NodoBool() {
    	super(Type.BOOL);
    	
    }

    public String toString(){return "BOOL";}
}

