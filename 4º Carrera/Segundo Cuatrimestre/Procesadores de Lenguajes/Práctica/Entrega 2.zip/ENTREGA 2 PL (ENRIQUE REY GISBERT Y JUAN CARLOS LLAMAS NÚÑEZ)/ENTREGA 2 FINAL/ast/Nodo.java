package ast;

public abstract class Nodo implements ASTNode {

	private Nodo derecha;
    
    public Nodo() {
    	super();
    	this.derecha = null;
    }
    
    public Nodo(Nodo derecha) {
    	super();
    	this.derecha = derecha;
    }
    
    public Nodo getDerecha() {
    	return this.derecha;
    }
    
    public void setDerecha(Nodo derecha) {
    	this.derecha = derecha;
    }
    
    public boolean existeDerecha() {
    	return (this.derecha != null);
    }

}
