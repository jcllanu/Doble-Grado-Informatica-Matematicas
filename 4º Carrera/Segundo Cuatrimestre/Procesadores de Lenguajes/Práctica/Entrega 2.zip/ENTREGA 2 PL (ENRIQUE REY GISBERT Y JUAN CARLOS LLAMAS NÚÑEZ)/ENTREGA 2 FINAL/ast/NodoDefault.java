package ast;

public class NodoDefault extends Nodo {

	private Nodo bloc;
    
    public NodoDefault() {
    	super();
    	
    	this.bloc = null;
    }
    
    public NodoDefault(Nodo bloc) {
    	super();
    	
    	this.bloc = bloc;
    }
    
	
	public Nodo getBloc() {
		return this.bloc;
	}
	
	
	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public NodeKind nodeKind(){return NodeKind.DEFAULT;}
    public String toString(){return "DEFAULT("+bloc.toString()+")";}
}
