package ast;

import java.util.*;

public class NodoFunciones extends Lista {
    
    public NodoFunciones() {
    	super();
    }
    
    public NodoFunciones(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){return NodeKind.FUNCIONES;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    return "FUNCIONES("+l+")";
    }

}
