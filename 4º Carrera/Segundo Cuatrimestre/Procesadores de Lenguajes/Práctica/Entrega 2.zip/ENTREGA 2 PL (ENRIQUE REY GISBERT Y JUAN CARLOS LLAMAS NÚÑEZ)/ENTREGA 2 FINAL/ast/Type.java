package ast;

public enum Type {
  INT, BOOL, ARRAY
}
