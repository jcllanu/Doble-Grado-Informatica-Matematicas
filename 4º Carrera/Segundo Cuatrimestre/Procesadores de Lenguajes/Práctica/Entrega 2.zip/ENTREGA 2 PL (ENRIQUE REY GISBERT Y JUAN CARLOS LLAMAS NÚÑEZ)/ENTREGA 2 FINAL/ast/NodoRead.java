package ast;

public class NodoRead extends Nodo {

    private Nodo iden;

    public NodoRead(Nodo iden) 
    {
    	super();
    	this.iden = iden;
    }

    public void setIden(Nodo iden) {
    	this.iden = iden;
	}
	
	public Nodo getIden() {
		return this.iden;
	}
	
	public NodeKind nodeKind(){return NodeKind.READ;}
    public String toString(){return "READ("+iden.toString()+")";}
	
}
