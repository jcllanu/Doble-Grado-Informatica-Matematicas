package ast;

public class NodoOperacionBinaria extends NodoExpresion {
    private Nodo opnd1;
    private Nodo opnd2;
    private OperandoB op;

    public NodoOperacionBinaria(Nodo opnd1, Nodo opnd2, OperandoB op) {
        this.opnd1 = opnd1;
        this.opnd2 = opnd2;
        this.op = op;
    }


    public Nodo getOpnd1() {return opnd1;}
    public Nodo getOpnd2() {return opnd2;}
    public void setOpnd1(Nodo opnd1) {this.opnd1=opnd1;}
    public void setOpnd2(Nodo opnd2) {this.opnd2=opnd2;}   
    public String toString() {
        String aux[]={"suma","resta","multiplicacion","division","modulo","potencia","or","and","igual","desigual","menorigual","mayor","mayorigual","menor"};
        return aux[op.ordinal()]+"("+getOpnd1().toString()+","+getOpnd2().toString()+")";
    }
}
