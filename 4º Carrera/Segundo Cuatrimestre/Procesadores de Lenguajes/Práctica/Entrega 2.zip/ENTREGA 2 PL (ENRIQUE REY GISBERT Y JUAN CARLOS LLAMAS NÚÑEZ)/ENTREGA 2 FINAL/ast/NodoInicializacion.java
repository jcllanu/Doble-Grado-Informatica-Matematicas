package ast;

public class NodoInicializacion extends Nodo {

	private Nodo tipo;
	private Nodo iden;
	private Nodo expr;
    
    public NodoInicializacion(Nodo tipo, Nodo iden, Nodo expr) {
    	super();
    	this.tipo = tipo;
    	this.iden = iden;
		this.expr = expr;
    }
    
    public void setTipo(Nodo tipo) {
    	this.tipo = tipo;
	}
	
	public Nodo getTipo() {
		return this.tipo;
	}
	
	public void setIden(Nodo iden) {
    	this.iden = iden;
	}
	
	public Nodo getIden() {
		return this.iden;
	}

	public void setExpr(Nodo expr) {
    	this.expr = expr;
	}
	
	public Nodo getExpr() {
		return this.expr;
	}
	public NodeKind nodeKind(){return NodeKind.INICIALIZACION;	}

    public String toString(){return "INIZ("+tipo.toString()+","+iden.toString()+","+expr.toString()+")";}
}

