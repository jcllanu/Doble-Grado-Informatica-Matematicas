package ast;

public class NodoReturn extends Nodo {
	
	private Nodo expr;
	
	public NodoReturn(Nodo expr)
	{
		super();
		this.expr = expr;
	}

	public void setExpr(Nodo expr) {
		this.expr = expr;
	}

	public Nodo getExpr() {
		return this.expr;
	}

	public NodeKind nodeKind(){return NodeKind.RETURN;}
    public String toString(){return "RETURN("+expr.toString()+")";}
}
