package ast;

import java.util.*;

public class NodoLista extends Lista {

    public NodoLista() {
    	super();
    }
    
    public NodoLista(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){return NodeKind.LISTA;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    return "LISTA("+l+")";
    }

}
