package ast;

public class NodoFuncion extends Nodo {
	
	private Nodo type;
	private String nombre;
	private Nodo args;
	private Nodo bloc;
	private int numero_args;
	
	public NodoFuncion() {
		super();
		this.type = null;
		this.nombre = "";
		this.args = null;
		this.bloc = null;
		this.numero_args = 0;
	}
	
	public NodoFuncion(Nodo type, String nombre) {
		super();
		this.type = type;
		this.nombre = nombre;
		this.args = null;
		this.bloc = null;
		this.numero_args = 0;
	}
	
	public NodoFuncion(Nodo type, String nombre, Nodo bloc) {
		super();
		this.type = type;
		this.nombre = nombre;
		this.args = null;
		this.bloc = bloc;
		this.numero_args = 0;
	}
	
	public NodoFuncion(Nodo type, String nombre, Nodo args, int numero_args) {
		super();
		this.type = type;
		this.nombre = nombre;
		this.args = args;
		this.bloc = null;
		this.numero_args = numero_args;
	}
	
	public NodoFuncion(String nombre, Nodo args, int numero_args, Nodo bloc) {
		super();
		this.type = null;
		this.nombre = nombre;
		this.args = args;
		this.bloc = bloc;
		this.numero_args = 0;
	}
	
	public NodoFuncion(Nodo type, String nombre, Nodo args, int numero_args, Nodo bloc) {
		super();
		this.type = type;
		this.nombre = nombre;
		this.args = args;
		this.bloc = bloc;
		this.numero_args = 0;
	}

	public Nodo getType() {
		return this.type;
	}

	public void setType(Nodo type) {
		this.type = type;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Nodo getArgs() {
		return this.args;
	}

	public void setArgs(Nodo args) {
		this.args = args;
	}

	public Nodo getBloc() {
		return this.bloc;
	}

	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public int getNumero_args() {
		return this.numero_args;
	}

	public void setNumero_args(int numero_args) {
		this.numero_args = numero_args;
	}
	public NodeKind nodeKind(){return NodeKind.FUNCION;	}

    public String toString(){
    if (type != null) { return "FUNC("+type.toString()+","+nombre+","+args.toString()+","+bloc.toString()+")";}
    else {return "FUNC(void,"+nombre+","+args.toString()+","+bloc.toString()+")";}
	}
}
