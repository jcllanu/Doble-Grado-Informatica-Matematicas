package ast;

public class Inicio extends Nodo {

	private Nodo vars;
	private Nodo funs;
    
    public Inicio(Nodo vars, Nodo funs) {
    	super();
    	this.vars = vars;
    	this.funs = funs;
    }
    
    public void setVars(Nodo vars) {
    	this.vars = vars;
	}
	
	public Nodo getVars() {
		return this.vars;
	}
	
	public void setFuns(Nodo funs) {
    	this.funs = funs;
	}
	
	public Nodo getFuns() {
		return this.funs;
	}
	public NodeKind nodeKind(){return NodeKind.INICIO;	}

    public String toString(){return "inicio("+vars.toString()+","+funs.toString()+")";}
}
