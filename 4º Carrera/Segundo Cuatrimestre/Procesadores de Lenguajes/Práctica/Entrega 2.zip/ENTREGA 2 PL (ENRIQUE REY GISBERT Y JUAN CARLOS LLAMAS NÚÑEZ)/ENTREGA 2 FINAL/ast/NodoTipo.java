package ast;

public abstract class NodoTipo extends Nodo {

	private Type tipo;
    
    public NodoTipo() {
    	super();
    	this.tipo=null;
    }
    public NodoTipo(Type tipo) {
    	super();
    	this.tipo=tipo;
    }
    public void setTipo(Type tipo) {
    	this.tipo = tipo;
	}
	
	public Type getTipo() {
		return this.tipo;
	}
	
	public NodeKind nodeKind(){return NodeKind.TIPO;}
}

