package ast;

public class NodoVariable extends Nodo{
    private String nombre;

    public NodoVariable(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre=nombre;}

    public String toString() {
        return nombre.toString();
    }
    public NodeKind nodeKind(){return NodeKind.VARIABLE;}
    
}
