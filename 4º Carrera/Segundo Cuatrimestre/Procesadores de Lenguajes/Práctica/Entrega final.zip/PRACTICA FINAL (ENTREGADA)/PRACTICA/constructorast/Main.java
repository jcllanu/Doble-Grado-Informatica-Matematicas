package constructorast;

import ast.*;
import java.io.*;
import java.util.*;
import alex.AnalizadorLexicoExp;

public class Main {

   private static final boolean mostrarAST = true;          // Mostrar el AST
   private static final boolean mostrarErrorTipado = true;  // Ademas de fila y columna, muestra información sobre el error.
	
   public static void main(String[] args) throws Exception {
	    	
   		// LEXICO / SINTACTICO / AST
   		
		ConstructorASTExp constructorast=null;
		Nodo ast=null;
		try{
			Reader input = new InputStreamReader(new FileInputStream(args[0]));
			AnalizadorLexicoExp alex = new AnalizadorLexicoExp(input);
			constructorast = new ConstructorASTExp(alex);
			ast=(Nodo)constructorast.parse().value;
		}catch(Exception e){
			System.out.println("Fallo fatal en el proceso de análisis sintáctico (Revisa el nombre del fichero).");
			System.exit(1);
		}
		if(constructorast.getErrores().algunError()){
			System.out.println("Fallo fatal en el proceso de análisis sintáctico.");
			System.exit(1);
		}

	 	System.out.println("Análisis sintáctico: OK");

		if(mostrarAST){
			System.out.println("El AST es: ");
			System.out.println(ast);
		}
	 	
	 	// VINCULACION
	 	
	 	Vinculador vinculador = new Vinculador();
	 	ArrayList<Nodo> fallosvinculacion = ast.bind(vinculador);
	 	if (fallosvinculacion.isEmpty()) {
		 	System.out.println("Vinculación: OK ");
	 	}
	 	else {
		 	System.out.println("Error(es) en vinculación:");
		 	for (int i = 0; i < fallosvinculacion.size(); i++) {
		 		if (fallosvinculacion.get(i).nodeKind() == NodeKind.VARIABLE) {
		 			System.out.println("Uso de variable "+((NodoVariable)fallosvinculacion.get(i)).getNombre()+" no declarada en fila "+fallosvinculacion.get(i).getFila()+" y columna "+fallosvinculacion.get(i).getColumna()+".");
		 		}
		 		else {
		 			System.out.println("Uso de función "+((NodoLlamada)fallosvinculacion.get(i)).getNombre()+" no declarada en fila "+fallosvinculacion.get(i).getFila()+" y columna "+fallosvinculacion.get(i).getColumna()+".");
		 		}
			}
			System.out.println("Fallo fatal en el proceso de vinculación.");
			System.exit(1);
	 	}
	 	
	 	// TIPADO
	 	
	 	ArrayList<Nodo> fallostipado = ast.type();
	 	if (fallostipado.isEmpty()) {
		 	System.out.println("Tipado: OK");
	 	}
	 	else {
		 	System.out.println("Error(es) en tipado:");
		 	for (int i = 0; i < fallostipado.size(); i++) {
				if(mostrarErrorTipado){
					System.out.println("Error de tipado en fila "+fallostipado.get(i).getFila()+" y columna "+fallostipado.get(i).getColumna()+". "+fallostipado.get(i).getError());
				}else{
					System.out.println("Error de tipado en fila "+fallostipado.get(i).getFila()+" y columna "+fallostipado.get(i).getColumna()+".");
				}
				
		 	}
		 	System.out.println("Fallo fatal en el proceso de tipado.");
			System.exit(1);
	 	}
	 	
	 	// GENERACION DE CODIGO
	 	
	 	String code = "";
	 	
	 	// ENCABEZADO
	 	
	 	code+="(module\n";
	    code+="(type $_sig_i32i32i32 (func (param i32 i32 i32) ))\n";
	 	code+="(type $_sig_i32ri32 (func (param i32) (result i32)))\n";
		code+="(type $_sig_i32 (func (param i32)))\n";
		code+="(type $_sig_ri32 (func (result i32)))\n";
	 	code+="(type $_sig_void (func ))\n";
		code+="(import \"runtime\" \"exceptionHandler\" (func $exception (type $_sig_i32)))";
		code+="(import \"runtime\" \"print\" (func $print (param i32)))\n";
		code+="(import \"runtime\" \"read\" (func $read (result i32)))\n";
		code+="(memory 2000)\n";
		
		for(int i = 0; i < ((Inicio)ast).getMax(); i++) {							// getMax es el tamaño máximo de lo que puede devolver una funcion 
			code+="(global (mut i32) (i32.const 0))\n";
		}

		code+="(global $SP (mut i32) (i32.const 0)) ;; start of stack\n";
		code+="(global $MP (mut i32) (i32.const 0)) ;; mark pointer\n";
		code+="(global $NP (mut i32) (i32.const 131071996)) ;; heap 2000*64*1024-4\n";

		code+="(global $base (mut i32) (i32.const 0)) ;; para trabajar con potencias\n";	
		code+="(global $exponente (mut i32) (i32.const 0))\n";
		
		code+="(global $asig (mut i32) (i32.const 0)) ;; para asginaciones\n";
		code+="(global $asig2 (mut i32) (i32.const 0)) ;; para asginaciones\n";
		
		code+="(start $main)\n";
		
		// RESERVE STACK
		
		code+="(func $reserveStack (param $size i32)\n(result i32)\nget_global $MP\nget_global $SP\nset_global $MP\nget_global $SP\nget_local $size\ni32.add\nset_global $SP\nget_global $SP\nget_global $NP\ni32.gt_u\nif\ni32.const 3\ncall $exception\nend\n)\n";
   
   		// FREE STACK
   
   		code+="(func $freeStack (type $_sig_void)\nget_global $MP\ni32.load\ni32.load offset=4\nset_global $SP\nget_global $MP\ni32.load\nset_global $MP\n)\n";
   		
		
		// CODIGO AST
		
		String code3="(func $main \n(local $localsStart i32)\n(local $temp i32)\ni32.const ";
		String code4="  ;; let this be the stack size needed (params+locals+2)*4\ncall $reserveStack  ;; returns old MP (dynamic link)\nset_local $temp\nget_global $MP\nget_local $temp\ni32.store\nget_global $MP\nget_global $SP\ni32.store offset=4\nget_global $MP\ni32.const 8\ni32.add\nset_local $localsStart\n";
		String code5=ast.generateCode();
		
		code+=code3+Integer.toString((Integer)((Inicio)ast).getGlobales()+8)+code4+code5+")";
		
		// CREACIÓN DEL ARCHIVO WAT
		
	 	File file   = new File("main.wat");
		file.delete();
		if (file.createNewFile()) {
			BufferedWriter writer = new BufferedWriter(new FileWriter("main.wat", true));
			writer.append(code);
			writer.close();
		}
		else {
			System.out.println("No se ha podido crear el archivo main.wat. Fallo fatal en el proceso de generación de código.");
		}
		
	} 
} 
   
