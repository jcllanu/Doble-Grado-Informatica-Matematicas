package ast;

import java.util.*;

public class NodoIf extends Nodo {

	private Nodo cond;
	private Nodo thenBloc;

	public NodoIf() {
		super();
		this.cond = null;
		this.thenBloc = null;
	}
	
	public NodoIf(Nodo cond, Nodo thenBloc, int fila, int columna) {
		super(fila, columna);
		this.cond = cond;
		this.thenBloc = thenBloc;
	}
	
	public NodoIf(Nodo cond, Nodo thenBloc, Nodo elseBloc, int fila, int columna) {
		super(fila, columna);
		this.cond = cond;
		this.thenBloc = thenBloc;
	}
	
	public Nodo getCond() {
		return this.cond;
	}
	
	public Nodo getThenBloc() {
		return this.thenBloc;
	}
	
	public void setCond(Nodo cond) {
		this.cond = cond;
	}
	
	public void setThenBloc(Nodo thenBloc) {
		this.thenBloc = thenBloc;
	}
	
	public NodeKind nodeKind(){return NodeKind.IF;}
    public String toString(){return "IF("+cond.toString()+","+thenBloc.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux = cond.bind(v);
		v.abreBloque();
		aux.addAll(thenBloc.bind(v));
		v.cierraBloque();
		return aux;
	}
	
	public ArrayList<Nodo> type(){
		ArrayList<Nodo> aux = cond.type();
		if(aux.isEmpty()&&cond.getTipo().getType() != Type.BOOL) {
			cond.setError("La condición de un if/elif debe ser de tipo BOOL. La expresión era de tipo "+cond.getTipo().toString()+".");
			aux.add(cond);
		}
		aux.addAll(thenBloc.type());
		return aux;
	}
	
	public String codeI(){
		((NodoInstrucciones)thenBloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		String code=";;Empieza el if\n"+cond.codeE();
		code+="if\n";
		code+=thenBloc.generateCode();
		code+="else\n";
		code+="end\n;;Termina el if\n";

		return code;
	}
	
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		cond.calcula_hueco_param(f);
		thenBloc.calcula_hueco_param(f);
	}

	public String codeForElif(){
		System.out.println(miBloque);
		((NodoInstrucciones)thenBloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		String code=cond.codeE();
		code+="if\n";
		code+=thenBloc.generateCode();
		code+="else\n";
		//DEJA ABIERTO EL ELSE
		return code;
	}
	
	public void maxMemory(Entero c, Entero max){
		Entero c1=new Entero(0);
		Entero max1=new Entero(0);
		thenBloc.maxMemory(c1,max1);
		if(c.getEntero()+max1.getEntero()>max.getEntero()){
			max.setEntero(c.getEntero()+max1.getEntero());
		}
	}
}
