package ast;
import java.util.*;
public class Entero {

	private int n;
	public Entero(int n){
		this.n=n;
	}
	public int getEntero(){
	return n;
	}
	public void setEntero(int n){
	this.n=n;
	}	
}   

   
