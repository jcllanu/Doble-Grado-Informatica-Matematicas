package ast;

import java.util.*;

public class NodoReturn extends Nodo {
	
	private Nodo expr;
	private Nodo funcion;
	private int return_pos = 0;
	
	public NodoReturn(Nodo expr, int fila, int columna) {
		super(fila, columna);
		this.expr = expr;
	}

	public void setExpr(Nodo expr) {
		this.expr = expr;
	}

	public Nodo getExpr() {
		return this.expr;
	}

	public NodeKind nodeKind(){return NodeKind.RETURN;}
    public String toString(){return "RETURN("+expr.toString()+")";}
	
	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux = expr.bind(v);
		funcion=v.getFuncionActual();
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = expr.type();
		if(aux.isEmpty()) {
			if(funcion.getTipo()==null){
				this.setError("Instrucción return en una función que devuelve VOID.");
				aux.add(this);
			}
			else if(!expr.getTipo().compare(funcion.getTipo())) {
				expr.setError("El tipo devuelto por la función es "+funcion.getTipo().toString()+" y el tipo de la expresión es "+expr.getTipo().toString()+".");
				aux.add(expr);
			}
		}
		return aux;
	}
	public String codeI(){
		String code = "";
		if(expr.getTipo().getType()!=Type.ARRAY && expr.getTipo().getType()!=Type.STRUCT){
			if(expr.nodeKind()!=NodeKind.LLAMADA){
				code += expr.codeE();
				code += "set_global " + Integer.toString((Integer)return_pos) + "\n";
				return_pos++;
			}else if(expr.nodeKind()==NodeKind.LLAMADA) {
				code += expr.codeE();
				code += "set_global " + Integer.toString((Integer)return_pos) + "\n";
				return_pos++;
			}
		}else if (expr.nodeKind()==NodeKind.LISTA) {
			code+=asignar2(expr.getTipo(), expr);
		}else if(expr.nodeKind()==NodeKind.POSICIONARRAY || expr.nodeKind()==NodeKind.ACCESOCAMPO || expr.nodeKind()==NodeKind.VARIABLE){
			code+=asignar(expr.getTipo(), expr.codeD());
		}
		return code;
	}
	
	private String asignar2(NodoTipo tipoAsignar, Nodo expresion){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			String aux = expresion.codeE()+"set_global " + Integer.toString((Integer)return_pos) + "\n";
			return_pos++;
			return aux;
		}else if(tipoAsignar.getType()==Type.ARRAY){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);
					code+=asignar2(((NodoArray)tipoAsignar).getParam(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return asignar(tipoAsignar, expresion.codeD());
			}
			
		}else if(tipoAsignar.getType()==Type.STRUCT){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i); // La nueva expresion que cargar es la poscicion i esima 
					code+=asignar2(((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return asignar(tipoAsignar, expresion.codeD());
			}
		}
		return "";
	}
	private String asignar(NodoTipo tipoAsignar, String pm_cargar){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			String aux = pm_cargar+"i32.load\n"+"set_global " + Integer.toString((Integer)return_pos) + "\n";
			return_pos++;
			return aux;
		}else if(tipoAsignar.getType()==Type.ARRAY){
			String code="";
			for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_cargar+="i32.add\n";
				code+=asignar(((NodoArray)tipoAsignar).getParam(),nueva_pm_cargar);
			}
			return code;
		}else if(tipoAsignar.getType()==Type.STRUCT){
			String code="";
			int acum = 0;
			for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
				String nueva_pm_cargar=pm_cargar; //La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_cargar+="i32.add\n";
				acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
				code+=asignar(((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_pm_cargar);
			}
			return code;
		}
		return "";
	}
}
