package ast;

import java.util.*;

public class NodoOperacionBinaria extends Nodo {

    private Nodo opnd1;
    private Nodo opnd2;
    private OperandoB op;

    public NodoOperacionBinaria(Nodo opnd1, Nodo opnd2, OperandoB op, int fila, int columna) {
    	super(fila, columna);
        this.opnd1 = opnd1;
        this.opnd2 = opnd2;
        this.op = op;
    }

    public Nodo getOpnd1() {return opnd1;}
    public Nodo getOpnd2() {return opnd2;}
    public void setOpnd1(Nodo opnd1) {this.opnd1=opnd1;}
    public void setOpnd2(Nodo opnd2) {this.opnd2=opnd2;}   
    
    public String toString() {
        String aux[]={"suma","resta","multiplicacion","division","modulo","potencia","or","and","igual","desigual","menorigual","mayor","mayorigual","menor"};
        return aux[op.ordinal()]+"("+getOpnd1().toString()+","+getOpnd2().toString()+")";
    }

	public NodeKind nodeKind(){ return NodeKind.EXPRESION; }
	
    public ArrayList<Nodo> bind(Vinculador v) {
		ArrayList<Nodo> aux=opnd1.bind(v);
		aux.addAll(opnd2.bind(v));
		return aux;
	}
	
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		opnd1.calcula_hueco_param(f);
		opnd2.calcula_hueco_param(f);
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = opnd1.type();
		aux.addAll(opnd2.type());
		if(this.op == OperandoB.SUMA || this.op == OperandoB.RESTA || this.op == OperandoB.MULTIPLICACION || this.op == OperandoB.DIVISION || this.op == OperandoB.MODULO || this.op == OperandoB.POTENCIA) {
			if(this.opnd1.getTipo().getType() != Type.INT) {
				opnd1.setError("Se esperaba una expresión de tipo INT. El tipo de la expresión es "+opnd1.getTipo().toString()+".");
				aux.add(opnd1);
			}
			if(this.opnd2.getTipo().getType() != Type.INT) {
				opnd2.setError("Se esperaba una expresión de tipo INT. El tipo de la expresión es "+opnd2.getTipo().toString()+".");
				aux.add(opnd2);
			}
			this.tipo = new NodoInt();
		}
		else if (this.op == OperandoB.MENORIGUAL || this.op == OperandoB.MAYOR || this.op == OperandoB.MAYORIGUAL || this.op == OperandoB.MENOR) {
			if(this.opnd1.getTipo().getType() != Type.INT) {
				opnd1.setError("Se esperaba una expresión de tipo INT. El tipo de la expresión es "+opnd1.getTipo().toString()+".");
				aux.add(opnd1);
			}
			if(this.opnd2.getTipo().getType() != Type.INT) {
				opnd2.setError("Se esperaba una expresión de tipo INT. El tipo de la expresión es "+opnd2.getTipo().toString()+".");
				aux.add(opnd2);
			}
			this.tipo = new NodoBool();
		}
		else if (this.op == OperandoB.OR || this.op == OperandoB.AND) {
			if(this.opnd1.getTipo().getType() != Type.BOOL) {
				opnd1.setError("Se esperaba una expresión de tipo BOOL. El tipo de la expresión es "+opnd1.getTipo().toString()+".");
				aux.add(opnd1);
			}
			if(this.opnd2.getTipo().getType() != Type.BOOL) {
				opnd2.setError("Se esperaba una expresión de tipo BOOL. El tipo de la expresión es "+opnd2.getTipo().toString()+".");
				aux.add(opnd2);
			}
			this.tipo = new NodoBool();
		}
		else if (this.op == OperandoB.IGUAL || this.op == OperandoB.DESIGUAL) {
			if(!this.opnd1.getTipo().compare(this.opnd2.getTipo())) {
				this.setError("Distintos tipos de los elementos a comparar: "+opnd1.getTipo().toString()+" y "+opnd2.getTipo().toString()+".");
				aux.add(this);
			}
			this.tipo = new NodoBool();
		}
		return aux;
	}
	public String codeE(){
		String code="";
		if(op==OperandoB.IGUAL){
			code+=codigoigual(opnd1,opnd2,opnd2.getTipo());
		} 
		else if(op==OperandoB.DESIGUAL){
			code+=codigoigual(opnd1,opnd2,opnd2.getTipo())+"i32.eqz\n";
		}
		else if (op!=OperandoB.POTENCIA){
			code+=opnd1.codeE();
			code+=opnd2.codeE();
			String aux[]={"i32.add\n","i32.sub\n","i32.mul\n","i32.div_s\n","i32.rem_u\n","","i32.or\n","i32.and\n","i32.eq\n","i32.ne\n","i32.le_s\n","i32.gt_s\n","i32.ge_s\n","i32.lt_s\n"};
			code+=aux[op.ordinal()];
		} else {
			code=";;Empieza el calculo de la potencia\n";
			//a ^ b = a*a*... *a*a (b veces) si b es positivo o 1 en caso contrario. 
			//Si opnd2>0 
			code+=opnd2.codeE();
			code+="i32.const 0\n";
			code+="i32.gt_s\n";
			//then
			code+="if\n";//-->pot=a^b
				code+=opnd1.codeE();
				code+="set_global $base\n";
				code+=opnd2.codeE();
				code+="set_global $exponente\n";
				code+="block\nloop\n";
				//Si el exponente es mayor que 1 (todavía)
				code+="get_global $exponente\n";
				code+="i32.const 1\n";
				code+="i32.gt_s\n";
				code+="i32.eqz\nbr_if 1\n";
					//Cuerpo del bucle
					//base=base*opdn1
					code+="get_global $base\n";
					code+=opnd1.codeE();
					code+="i32.mul\n";
					code+="set_global $base\n";
					//exponente--;
					code+="get_global $exponente\n";
					code+="i32.const 1\n";
					code+="i32.sub\n";
					code+="set_global $exponente\n";
				code+="br 0\nend\nend\n";
			//else
			code+="else\n";
				code+="i32.const 1\n";
				code+="set_global $base\n";
			code+="end\n";
			code+="get_global $base\n";
			code+=";;Termina el calculo de la potencia\n";
		}
		return code;
	}
	public String codigoigual(Nodo op1, Nodo op2,NodoTipo tipo){
		String code="";
		if(tipo.getType()==Type.INT ||tipo.getType()==Type.BOOL){
			return op1.codeE()+op2.codeE()+"i32.eq\n";
		}else if(tipo.getType()==Type.ARRAY){
			if(op1.nodeKind()==NodeKind.LISTA){
				if(op2.nodeKind()==NodeKind.LISTA){//AMBOS LISTAS
					if(((NodoArray)tipo).getTam()==0){
						return "i32.const 1\n";//Arrays de tamaño 0 son iguales
					}
					//El tamaño de los arrays es al menos 1
					code+=codigoigual(((NodoLista)op1).getLista().get(0),((NodoLista)op2).getLista().get(0),((NodoArray)tipo).getParam());
					for(int i=1; i<((NodoArray)tipo).getTam();i++){
						code+=codigoigual(((NodoLista)op1).getLista().get(i),((NodoLista)op2).getLista().get(i),((NodoArray)tipo).getParam());
						code+="i32.and\n";
					}
					return code;
				}else if(op2.nodeKind()==NodeKind.POSICIONARRAY||op2.nodeKind()==NodeKind.ACCESOCAMPO || op2.nodeKind()==NodeKind.VARIABLE){//op1 es una lista y op2 devuelve una lista
					return codigoigual2(op1,op2.codeD(),tipo);
				}
			}else if(op1.nodeKind()==NodeKind.POSICIONARRAY||op1.nodeKind()==NodeKind.ACCESOCAMPO || op1.nodeKind()==NodeKind.VARIABLE){//op1 devuelve una lista y op2 es una lista
				if(op2.nodeKind()==NodeKind.LISTA){
					return codigoigual3(op1.codeD(),op2,tipo);
				}else if(op2.nodeKind()==NodeKind.POSICIONARRAY||op2.nodeKind()==NodeKind.ACCESOCAMPO || op2.nodeKind()==NodeKind.VARIABLE){//ambos devuelven listas
					return codigoigual4(op1.codeD(),op2.codeD(),tipo);
				}
			}
		}else if(tipo.getType()==Type.STRUCT){
			if(op1.nodeKind()==NodeKind.LISTA){
				if(op2.nodeKind()==NodeKind.LISTA){//AMBOS LISTAS
					if(((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size()==0){
						return "i32.const 1\n";//Structs con 0 campos son iguales
					}
					//Structs con al menos un campo
					code+=codigoigual(((NodoLista)op1).getLista().get(0),((NodoLista)op2).getLista().get(0),((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo());
					for(int i=1; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
						code+=codigoigual(((NodoLista)op1).getLista().get(i),((NodoLista)op2).getLista().get(i),((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
						code+="i32.and\n";
					}
					return code;
				}else if(op2.nodeKind()==NodeKind.POSICIONARRAY||op2.nodeKind()==NodeKind.ACCESOCAMPO || op2.nodeKind()==NodeKind.VARIABLE){//op1 es una lista y op2 devuelve una lista
					return codigoigual2(op1,op2.codeD(),tipo);
				}
			}else if(op1.nodeKind()==NodeKind.POSICIONARRAY||op1.nodeKind()==NodeKind.ACCESOCAMPO || op1.nodeKind()==NodeKind.VARIABLE){//op1 devuelve una lista y op2 es una lista
				if(op2.nodeKind()==NodeKind.LISTA){
					return codigoigual3(op1.codeD(),op2,tipo);
				}else if(op2.nodeKind()==NodeKind.POSICIONARRAY||op2.nodeKind()==NodeKind.ACCESOCAMPO || op2.nodeKind()==NodeKind.VARIABLE){//ambos devuelven listas
					return codigoigual4(op1.codeD(),op2.codeD(),tipo);
				}
			}
		}
		return code;
	}

	public String codigoigual2(Nodo op1, String posmem_op2,NodoTipo tipo){
		String code="";
		if(tipo.getType()==Type.INT ||tipo.getType()==Type.BOOL){
			return op1.codeE()+posmem_op2+"i32.load\n"+"i32.eq\n";
		}else if(tipo.getType()==Type.ARRAY){
			if(op1.nodeKind()==NodeKind.LISTA){
					if(((NodoArray)tipo).getTam()==0){
						return "i32.const 1\n";//Arrays de tamaño 0 son iguales
					}
					//El tamaño de los arrays es al menos 1
					code+=codigoigual2(((NodoLista)op1).getLista().get(0),posmem_op2,((NodoArray)tipo).getParam());
					for(int i=1; i<((NodoArray)tipo).getTam();i++){
						//A la posicion de partida le sumo i por el tamaño de los elementos del array
						String aux= posmem_op2+ "i32.const "+Integer.toString((Integer)((NodoArray)tipo).getParam().size()*i)+"\n"+"i32.add\n";
						code+=codigoigual2(((NodoLista)op1).getLista().get(i),aux,((NodoArray)tipo).getParam());
						code+="i32.and\n";
					}
					return code;
				
			}else if(op1.nodeKind()==NodeKind.POSICIONARRAY||op1.nodeKind()==NodeKind.ACCESOCAMPO || op1.nodeKind()==NodeKind.VARIABLE){//op1 devuelve una lista y op2 también
				return codigoigual4(op1.codeD(),posmem_op2,tipo);	
			}
		}else if(tipo.getType()==Type.STRUCT){
			if(op1.nodeKind()==NodeKind.LISTA){
					if(((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size()==0){
						return "i32.const 1\n";//Arrays de tamaño 0 son iguales
					}
					//El tamaño de los arrays es al menos 1
					code+=codigoigual2(((NodoLista)op1).getLista().get(0),posmem_op2,((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo());
					int acum=((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo().size();
					for(int i=1; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
						//A la posicion de partida le sumo i por el tamaño de los elementos del array
						String aux= posmem_op2+ "i32.const "+Integer.toString((Integer)acum)+"\n"+"i32.add\n";
						code+=codigoigual2(((NodoLista)op1).getLista().get(i),aux,((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
						code+="i32.and\n";
						acum+=((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
					}
					return code;
				
			}else if(op1.nodeKind()==NodeKind.POSICIONARRAY||op1.nodeKind()==NodeKind.ACCESOCAMPO || op1.nodeKind()==NodeKind.VARIABLE){//op1 devuelve una lista y op2 también
				return codigoigual4(op1.codeD(),posmem_op2,tipo);	
			}
		}
		return code;
	}

	public String codigoigual3(String posmem_op1, Nodo op2,NodoTipo tipo){//Simétrica a codigoigual2
		String code="";
		if(tipo.getType()==Type.INT ||tipo.getType()==Type.BOOL){
			return posmem_op1+"i32.load\n"+op2.codeE()+"i32.eq\n";
		}else if(tipo.getType()==Type.ARRAY){
			if(op2.nodeKind()==NodeKind.LISTA){
					if(((NodoArray)tipo).getTam()==0){
						return "i32.const 1\n";//Arrays de tamaño 0 son iguales
					}
					//El tamaño de los arrays es al menos 1
					code+=codigoigual3(posmem_op1,((NodoLista)op2).getLista().get(0),((NodoArray)tipo).getParam());
					for(int i=1; i<((NodoArray)tipo).getTam();i++){
						//A la posicion de partida le sumo i por el tamaño de los elementos del array
						String aux= posmem_op1+ "i32.const "+Integer.toString((Integer)((NodoArray)tipo).getParam().size()*i)+"\n"+"i32.add\n";
						code+=codigoigual3(aux,((NodoLista)op2).getLista().get(i),((NodoArray)tipo).getParam());
						code+="i32.and\n";
					}
					return code;
				
			}else if(op2.nodeKind()==NodeKind.POSICIONARRAY||op2.nodeKind()==NodeKind.ACCESOCAMPO || op2.nodeKind()==NodeKind.VARIABLE){//op1 devuelve una lista y op2 también
				return codigoigual4(posmem_op1,op2.codeD(),tipo);	
			}
		}else if(tipo.getType()==Type.STRUCT){
			if(op2.nodeKind()==NodeKind.LISTA){
					if(((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size()==0){
						return "i32.const 1\n";//Arrays de tamaño 0 son iguales
					}
					//El tamaño de los arrays es al menos 1
					code+=codigoigual3(posmem_op1,((NodoLista)op2).getLista().get(0),((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo());
					int acum=((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo().size();
					for(int i=1; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
						String aux= posmem_op1+ "i32.const "+Integer.toString((Integer)acum)+"\n"+"i32.add\n";
						code+=codigoigual3(aux,((NodoLista)op2).getLista().get(i),((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
						code+="i32.and\n";
						acum+=((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
					}
					return code;
				
			}else if(op2.nodeKind()==NodeKind.POSICIONARRAY||op2.nodeKind()==NodeKind.ACCESOCAMPO || op2.nodeKind()==NodeKind.VARIABLE){//op1 devuelve una lista y op2 también
				return codigoigual4(posmem_op1,op2.codeD(),tipo);	
			}
		}
		return code;
	}

	public String codigoigual4(String posmem_op1, String posmem_op2,NodoTipo tipo){
		String code="";
		if(tipo.getType()==Type.INT ||tipo.getType()==Type.BOOL){
			return posmem_op1+"i32.load\n"+posmem_op2+"i32.load\n"+"i32.eq\n";
		}else if(tipo.getType()==Type.ARRAY){
			if(((NodoArray)tipo).getTam()==0){
				return "i32.const 1\n";//Arrays de tamaño 0 son iguales
			}
			//El tamaño de los arrays es al menos 1
			code+=codigoigual4(posmem_op1,posmem_op2,((NodoArray)tipo).getParam());
			for(int i=1; i<((NodoArray)tipo).getTam();i++){
				//A la posicion de partida le sumo i por el tamaño de los elementos del array
				String aux= posmem_op1+ "i32.const "+Integer.toString((Integer)((NodoArray)tipo).getParam().size()*i)+"\n"+"i32.add\n";
				String aux2= posmem_op2+ "i32.const "+Integer.toString((Integer)((NodoArray)tipo).getParam().size()*i)+"\n"+"i32.add\n";
				code+=codigoigual4(aux,aux2,((NodoArray)tipo).getParam());
				code+="i32.and\n";
			}
			return code;
		}else if(tipo.getType()==Type.STRUCT){
			if(((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size()==0){
				return "i32.const 1\n";//Arrays de tamaño 0 son iguales
			}
			//El tamaño de los arrays es al menos 1
			code+=codigoigual4(posmem_op1,posmem_op2,((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo());
			int acum=((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(0).getTipo().size();
			for(int i=1; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
				//A la posicion de partida le sumo i por el tamaño de los elementos del array
				String aux= posmem_op1+ "i32.const "+Integer.toString((Integer)acum)+"\n"+"i32.add\n";
				String aux2= posmem_op2+ "i32.const "+Integer.toString((Integer)acum)+"\n"+"i32.add\n";
				code+=codigoigual4(aux,aux2,((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
				code+="i32.and\n";
			}
			return code;
		}
		return code;
	}
}
