package ast;

import java.util.*;

public class NodoAsignacion extends Nodo {

	private Nodo posmem;
	private Nodo expr;
    
    public NodoAsignacion(Nodo posmem, Nodo expr, int fila, int columna) {
    	super(fila, columna);
    	this.posmem = posmem;
		this.expr = expr;
    }
    
	
	public void setPosmem(Nodo posmem) {
    	this.posmem = posmem;
	}
	
	public Nodo getPosmem() {
		return this.posmem;
	}

	public void setExpr(Nodo expr) {
    	this.expr = expr;
	}
	
	public Nodo getExpr() {
		return this.expr;
	}
	public NodeKind nodeKind(){return NodeKind.ASIGNACION;	}

    public String toString(){return "ASIGN("+posmem.toString()+","+expr.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux=posmem.bind(v);
		aux.addAll(expr.bind(v));
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = posmem.type();
		ArrayList<Nodo> aux2 = expr.type();
		aux.addAll(aux2);

		if(aux.isEmpty()&&aux2.isEmpty()&&!(expr.getTipo().compare(posmem.getTipo()))) {
			if(expr.getTipo().nodeKind() == NodeKind.STRUCT && posmem.getTipo().nodeKind() == NodeKind.STRUCT){
				expr.setError("A pesar de ser ambos de tipo STRUCT, no comparten los tipos de sus campos.");
				aux.add(expr);
			}
			else {
				expr.setError("El tipo esperado era "+posmem.getTipo().toString()+" y el tipo de la expresión es "+expr.getTipo().toString()+".");
				aux.add(expr);
			}
		}
		return aux;
	}
	public String codeI(){
		String code=";;Empieza la asignacion\n";
		if(expr.nodeKind()!=NodeKind.LLAMADA && (expr.getTipo().getType()!=Type.ARRAY &&expr.getTipo().getType()!=Type.STRUCT)){
			if(expr.nodeKind()!=NodeKind.LLAMADA){
				code+=posmem.codeD();
				code+=expr.codeE();
				code+="i32.store\n;;Termina la asignacion\n";
			}
		}else if(expr.nodeKind()==NodeKind.LLAMADA) {
				code+=expr.codeE();
				for(int i = 0; i < ((NodoFuncion)((NodoLlamada)expr).getDeclaracion()).getTipo().size()/4; i++) {
					code+=posmem.codeD();
					code+="i32.const "+Integer.toString((Integer)i*4)+"\n";
					code+="i32.add\n";
					code+="set_global $asig\n";
					code+="set_global $asig2\n";
					code+="get_global $asig\n";
					code+="get_global $asig2\n";
					code+="i32.store\n";
				}
		}else if (expr.nodeKind()==NodeKind.LISTA) {
			code+=asignar2(posmem.codeD(), expr.getTipo(), expr);
			/*ArrayList<Nodo> l =((NodoLista)expr).getLista(); 
			for(int i=0;i<l.size();i++){
				code+=iden.codeD();
				code+="i32.const "+Integer.toString((Integer)l.get(i).getTipo().size()*i)+"\n";
				code+="i32.add\n";
				code+=l.get(i).codeE();
				code+="i32.store   ;;Elemento"+i+"\n";
			}*/
			code+=";;Termina la asignacion\n";
		}else if(expr.nodeKind()==NodeKind.POSICIONARRAY || expr.nodeKind()==NodeKind.ACCESOCAMPO || expr.nodeKind()==NodeKind.VARIABLE){
			code+=asignar(posmem.codeD(), expr.getTipo(), expr.codeD());
			code+=";;Termina la asignacion\n";
		}
		return code;
	}
	private String asignar2(String pm_guardar, NodoTipo tipoAsignar, Nodo expresion){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			return pm_guardar+expresion.codeE()+"i32.store\n";
		}else if(tipoAsignar.getType()==Type.ARRAY){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
					String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
					nueva_pm_guardar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
					nueva_pm_guardar+="i32.add\n";
				
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);//La nueva expresion que cargar es la poscicion i esima de lo cargado
					code+=asignar2(nueva_pm_guardar,((NodoArray)tipoAsignar).getParam(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return asignar(pm_guardar, tipoAsignar, expresion.codeD());
			}
			
		}else if(tipoAsignar.getType()==Type.STRUCT){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				int acum = 0;
				for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
					String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
					nueva_pm_guardar+="i32.const "+Integer.toString((Integer)acum)+"\n";
					nueva_pm_guardar+="i32.add\n";
					acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
				
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);//La nueva expresion que cargar es la poscicion i esima de lo cargad0
					code+=asignar2(nueva_pm_guardar,((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return asignar(pm_guardar, tipoAsignar, expresion.codeD());
			}
		}
		return "";
	}
	private String asignar(String pm_guardar, NodoTipo tipoAsignar, String pm_cargar){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			return pm_guardar+pm_cargar+"i32.load\n"+"i32.store\n";
		}else if(tipoAsignar.getType()==Type.ARRAY){
			String code="";
			for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
				String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
				nueva_pm_guardar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_guardar+="i32.add\n";
				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_cargar+="i32.add\n";

				code+=asignar(nueva_pm_guardar,((NodoArray)tipoAsignar).getParam(),nueva_pm_cargar);
			}
			return code;
		}else if(tipoAsignar.getType()==Type.STRUCT){
			String code="";
			int acum = 0;
			for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
				String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
				nueva_pm_guardar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_guardar+="i32.add\n";

				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_cargar+="i32.add\n";

				acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();

				code+=asignar(nueva_pm_guardar,((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_pm_cargar);
			}
			return code;
		}
		return "";
	}
}

