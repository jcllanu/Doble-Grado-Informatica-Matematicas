package ast;

import java.util.*;

public class NodoElif extends Lista {

    public NodoElif() {
    	super();
    }
    
    public NodoElif(Nodo ins, int fila, int columna) {
    	super(ins, fila, columna);
    }
    
    public NodeKind nodeKind(){return NodeKind.ELIF;}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    	return "IF-ELIF-ELSE("+l+")";
    }

	public int calcular_delta(int delta, NodoInstrucciones n){
		for(Nodo m: lista){
			m.calcular_delta(delta,n);
		}
		return 0;
	}
	
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		for(Nodo m: lista){
			m.calcula_hueco_param(f);
		}
	}
	
	public String codeI(){
		int endspendientes=0;
		String code=";;Empieza el if-else-if\n";
		for(int i = 0; i < this.lista.size(); i++) {
			if(lista.get(i).nodeKind()==NodeKind.IF){
				code+=((NodoIf)lista.get(i)).codeForElif();//DEJA ABIERTO EL ELSE (Falta el end)
				endspendientes++;
			}else{
				code+=((NodoIfElse) lista.get(i)).codeForElif();
			}
    	}
		for(int i=0; i<endspendientes;i++){
			code+="end\n";
		}
		code+=";;Termina el if-else-if\n";
		return code;
	}
	public void maxMemory(Entero c, Entero max){
		for(Nodo m: lista){
			m.maxMemory(c,max);
		}
	}
	
}
