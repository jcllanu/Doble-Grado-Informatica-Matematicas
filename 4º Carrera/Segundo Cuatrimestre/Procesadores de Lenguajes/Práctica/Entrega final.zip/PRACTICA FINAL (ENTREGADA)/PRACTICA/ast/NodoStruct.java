package ast;

import java.util.*;

public class NodoStruct extends NodoTipo {   

	private String nombreStructDeclarado;
	private NodoDeclaracionStruct declaracion;        

    public NodoStruct(String nombreStructDeclarado) {
    	super(Type.STRUCT);
    	this.nombreStructDeclarado = nombreStructDeclarado;
    }
    
    public NodoStruct(String nombreStructDeclarado, NodoDeclaracionStruct declaracion) {
    	super(Type.STRUCT);
    	this.nombreStructDeclarado = nombreStructDeclarado;
    	this.declaracion = declaracion;
    }
    
    public NodoDeclaracionStruct getDeclaracion() {
    	return declaracion;
    }
    
    public NodeKind nodeKind(){return NodeKind.STRUCT;	}

    public String toString(){
    	return "STRUCT("+nombreStructDeclarado+")";
    }
    
    public ArrayList<Nodo> bind(Vinculador v) {
    	declaracion=(NodoDeclaracionStruct)v.buscaId(nombreStructDeclarado);
		ArrayList<Nodo> aux = new ArrayList<Nodo>();
		if(declaracion == null) { aux.add(this); }
		return aux;
    }
    public int size() {
    	int s = 0;
		ArrayList<Nodo> l = declaracion.getCampos().getLista();
		for(Nodo n:l){
			s+=n.getTipo().size();
		}
    	return s;
    }
   	public String generateCode(){
		String code="";
		return code;
	} 
}
