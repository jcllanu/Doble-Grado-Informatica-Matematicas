package ast;

import java.util.*;

public class NodoIfElse extends Nodo {

	private Nodo cond;
	private Nodo thenBloc;
	private Nodo elseBloc;

	public NodoIfElse() {
		super();
		this.cond = null;
		this.thenBloc = null;
		this.elseBloc = null;
	}
	
	public NodoIfElse(Nodo cond, Nodo thenBloc, int fila, int columna) {
		super(fila, columna);
		this.cond = cond;
		this.thenBloc = thenBloc;
		this.elseBloc = null;
	}
	
	public NodoIfElse(Nodo cond, Nodo thenBloc, Nodo elseBloc, int fila, int columna) {
		super(fila, columna);
		this.cond = cond;
		this.thenBloc = thenBloc;
		this.elseBloc = elseBloc;
	}
	
	public Nodo getCond() {
		return this.cond;
	}
	
	public Nodo getThenBloc() {
		return this.thenBloc;
	}
	
	public Nodo getElseBloc() {
		return this.elseBloc;
	}
	
	public void setCond(Nodo cond) {
		this.cond = cond;
	}
	
	public void setThenBloc(Nodo thenBloc) {
		this.thenBloc = thenBloc;
	}
	
	public void setElseBloc(Nodo elseBloc) {
		this.elseBloc = elseBloc;
	}

	public NodeKind nodeKind(){return NodeKind.IFELSE;}
    public String toString(){return "IF-ELSE("+cond.toString()+","+thenBloc.toString()+","+elseBloc.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux=cond.bind(v);
		v.abreBloque();
		aux.addAll(thenBloc.bind(v));
		v.cierraBloque();
		v.abreBloque();
		aux.addAll(elseBloc.bind(v));
		v.cierraBloque();
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = cond.type();
		if(aux.isEmpty()&&cond.getTipo().getType() != Type.BOOL) {
			cond.setError("La condición de un if/elif debe ser de tipo BOOL. La expresión era de tipo "+cond.getTipo().toString()+".");
			aux.add(cond);
		}
		aux.addAll(thenBloc.type());
		aux.addAll(elseBloc.type());
		return aux;
	}
	public String codeI(){
		return ";;Empieza el if-else\n"+this.codeForElif()+";;Termina el if-else\n";
	}
	
	public String codeForElif(){
		((NodoInstrucciones)thenBloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		((NodoInstrucciones)elseBloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		String code=cond.codeE();
		code+="if\n";
		code+=thenBloc.generateCode();
		code+="else\n";
		code+=elseBloc.generateCode();
		code+="end\n";
		return code;
	}
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		cond.calcula_hueco_param(f);
		thenBloc.calcula_hueco_param(f);
		elseBloc.calcula_hueco_param(f);
	}
	public void maxMemory(Entero c, Entero max){
		Entero c1=new Entero(0);
		Entero max1=new Entero(0);
		thenBloc.maxMemory(c1,max1);
		if(c.getEntero()+max1.getEntero()>max.getEntero()){
			max.setEntero(c.getEntero()+max1.getEntero());
		}
		Entero c2=new Entero(0);
		Entero max2=new Entero(0);
		elseBloc.maxMemory(c2,max2);
		if(c.getEntero()+max2.getEntero()>max.getEntero()){
			max.setEntero(c.getEntero()+max2.getEntero());
		}
	}
}
