package ast;

import java.util.*;

public class Inicio extends Nodo {

	private Nodo creations;
	private Nodo funs;
    	private int globales;
    	
    public Inicio(Nodo creations, Nodo funs) {
    	super();
    	this.creations = creations;
    	this.funs = funs;
    }
    
    public void setCreations(Nodo creations) {
    	this.creations = creations;
	}
	
	public Nodo getCreations() {
		return this.creations;
	}
	
	public void setFuns(Nodo funs) {
    	this.funs = funs;
	}
	
	public Nodo getFuns() {
		return this.funs;
	}
	
	public NodeKind nodeKind() { return NodeKind.INICIO; }

    public String toString() { return "inicio("+creations.toString()+","+funs.toString()+")"; }
	
	public ArrayList<Nodo> bind(Vinculador v) {
		v.inicializa();
		v.abreBloque();
		ArrayList<Nodo> aux  = creations.bind(v);
		ArrayList<Nodo> aux2 = funs.bind(v);
		v.cierraBloque();
		aux.addAll(aux2);
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux  = creations.type();
		ArrayList<Nodo> aux2 = funs.type();
		aux.addAll(aux2); 
		return aux;
	}
	
	public String generateCode(){
		String code = "";
		globales=((Creations)creations).calcular_delta(0,new NodoInstrucciones(0));
		((NodoFunciones)funs).setEspacioGlobales(globales);
		code += creations.generateCode();
		code += "call $main_real\n";
		code+="call $freeStack\n";
		code += ")\n(export \"main\" (func $main))\n";
		code += funs.generateCode();
		return code;
	}
	public int getGlobales(){
		return globales;
	}
	public int getMax(){
		return ((NodoFunciones)funs).getMax();
	}
}
