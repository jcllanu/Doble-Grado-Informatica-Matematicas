package ast;

import java.util.*;

public abstract class NodoTipo extends Nodo {

	private Type tipo;
    
    public NodoTipo() {
    	super();
    	this.tipo=null;
    }
    public NodoTipo(Type tipo) {
    	super();
    	this.tipo=tipo;
    }
    
    public void setType(Type tipo) {
    	this.tipo = tipo;
	}
	
	public Type getType() {
		return this.tipo;
	}
	
	public NodeKind nodeKind(){return NodeKind.TIPO;}
	
	public ArrayList<Nodo> bind(Vinculador v){
		return new ArrayList<Nodo>();
	}
	
	public ArrayList<Nodo> type() {
		return new ArrayList<Nodo>();
	}
	
	public boolean compare(NodoTipo a) {
		if (this.tipo == a.getType()) {
			if (this.tipo != Type.ARRAY && this.tipo != Type.STRUCT) {
				return true;
			}
			else if (this.tipo == Type.STRUCT) {
				NodoDeclaracionStruct aux = (NodoDeclaracionStruct)((NodoStruct)this).getDeclaracion();
				NodoDeclaracionStruct otro = (NodoDeclaracionStruct)((NodoStruct)a).getDeclaracion();
				if (aux.getCampos().getLista().size() != otro.getCampos().getLista().size()){
					return false;
				}
				else if (aux.getCampos().getLista().size() == 0) {
					return true;
				}
				return aux.getCampos().compruebaTipos(otro.getCampos().getLista());
			}
			else {
				NodoArray aux = (NodoArray)this;
				NodoArray otro= (NodoArray)a;
				if(aux.getTam()!= otro.getTam()){
					return false;
				}
				else if(aux.getTam()==0){
					return true;
				}
				return ((NodoTipo)aux.getParam()).compare(((NodoTipo)otro.getParam()));
				
			}
		}
		else {
			return false;
		}
	}
	
	public abstract int size();
	
	public String generateCode(){
		String code="";
		return code;
	}
}

