package ast;

import java.util.*;

public class NodoOperacionUnaria extends Nodo {

    private Nodo opnd1;
    private OperandoU op;

    public NodoOperacionUnaria(Nodo opnd1, OperandoU op, int fila, int columna) {
    	super(fila, columna);
        this.opnd1 = opnd1;
        this.op = op;
    }


    public Nodo getOpnd1() {return opnd1;}

    public void setOpnd1(Nodo opnd1) {this.opnd1=opnd1;}

    public String toString() {
        String aux[]={"menos","not"};
        return aux[op.ordinal()]+"("+getOpnd1().toString()+")";
    }
    
    public NodeKind nodeKind(){return NodeKind.EXPRESION;	}

    public ArrayList<Nodo> bind(Vinculador v){
		return opnd1.bind(v);
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = opnd1.type();
		if(aux.isEmpty()){
			if(this.op == OperandoU.MENOS) {
				if(this.opnd1.getTipo().getType() != Type.INT) {
					opnd1.setError("Se esperaba una expresión de tipo INT. El tipo de la expresión es "+opnd1.getTipo().toString()+".");
					aux.add(opnd1);
				}
				this.tipo = new NodoInt();
			}
			else if (this.op == OperandoU.NOT) {
				if(this.opnd1.getTipo().getType() != Type.BOOL) {
					opnd1.setError("Se esperaba una expresión de tipo BOOL. El tipo de la expresión es "+opnd1.getTipo().toString()+".");
					aux.add(opnd1);
				}
				this.tipo = new NodoBool();
			}
		}
		return aux;
	}
	public String codeE(){
		String code="";
		if (this.op == OperandoU.MENOS) {
			code+="i32.const 0\n" + opnd1.codeE() + "i32.sub\n";
		} else {
			code+=opnd1.codeE()+"i32.eqz\n";
		}
		return code;
	}
}
