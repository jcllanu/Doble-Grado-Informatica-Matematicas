package ast;

import java.util.*;

public class NodoInstrucciones extends Lista {
    private int inicio_memoria_marco;
    public NodoInstrucciones() {
    	super();
    }
    public NodoInstrucciones(int inicio_memoria_marco) {
    	super();
		this.inicio_memoria_marco=inicio_memoria_marco;
		this.delta=0;
    }
    public NodoInstrucciones(Nodo ins) {
    	super(ins);
    }
    public int getInicioMemoriaBloque() {
		return inicio_memoria_marco;
	}
	 public void setInicioMemoriaBloque(int n) {
		inicio_memoria_marco=n;
	}
    public NodeKind nodeKind(){return NodeKind.INSTRUCCIONES;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    return "INSTRUCCIONES("+l+")";
    }
	public String generateCode(){
		this.calcular_delta(0,this);
		String code="";
		for(Nodo n: lista){
			code+=n.codeI();
		}
		return code;
	}

	public int calcular_delta(int delta, NodoInstrucciones n){
		this.delta=0;
		for(Nodo m: lista){
			this.delta+=m.calcular_delta(this.delta,n);
		}
		return 0;
	}
	
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		for(Nodo m: lista){
			m.calcula_hueco_param(f);
		}
	}
	
	public void maxMemory(Entero c, Entero max){
		for(Nodo m: lista){
			m.maxMemory(c,max);
		}
	}
}
