package ast;

import java.util.*;

public class NodoLlamada extends Nodo {
	
	private String nombre;
    	
	private Lista args;
	private Nodo declaracion;
	
	public NodoLlamada(String nombre, int fila, int columna, Lista args) {
		super(fila, columna);
		this.nombre = nombre;
		this.args = args;
	}
	
	
	public NodoLlamada()
	{
		super();
		this.nombre = "";
		this.args = null;
	}
	
	public NodoLlamada(String nombre)
	{
		super();
		this.nombre = nombre;
		this.args = null;
	}
	
	public NodoLlamada(String nombre, Lista args)
	{
		super();
		this.nombre = nombre;
		this.args = args;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Lista getArgs() {
		return args;
	}

	public void setArgs(Lista args) {
		this.args = args;
	}
	
	public NodoFuncion getDeclaracion() {
		return ((NodoFuncion)this.declaracion);
	}

	public NodeKind nodeKind(){return NodeKind.LLAMADA;}
    public String toString(){return "CALL("+nombre+","+args.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		declaracion=v.buscaId(nombre);
		ArrayList<Nodo> aux = new ArrayList<Nodo>();
		if(declaracion == null) {
			aux.add(this);
		}
		else {
			this.tipo = ((NodoFuncion)declaracion).getTipo();
		}
		aux.addAll(args.bind(v));
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = args.type();
		if(aux.isEmpty()){
			ArrayList<Nodo> tiposArgs = ((NodoArgumentosLlamada)args).getTipos();
			ArrayList<Boolean> esVariable = ((NodoArgumentosLlamada)args).getEsVariable();
			ArrayList<Nodo> tiposFuncion = ((NodoFuncion)declaracion).getArgs().getLista();
			if(tiposArgs.size()!=tiposFuncion.size()){
				this.setError("Llamada con distinto número de argumentos que en la declaración de la función.");
				aux.add(this);
				return aux;
			}
			for(int i = 0; i < tiposArgs.size(); i++) {
				Nodo tipoArg=tiposArgs.get(i);
				Nodo tipoFunc=tiposFuncion.get(i).getTipo();
				if (!((NodoTipo)tipoArg).compare(((NodoTipo)tipoFunc))) {
					args.getLista().get(i).setError("Se esperaba un argumento de tipo "+((NodoTipo)tipoFunc).toString()+" y el argumento es de tipo "+((NodoTipo)tipoArg).toString()+".");
					aux.add(args.getLista().get(i));
				}else if(((NodoArgumento)tiposFuncion.get(i)).getAmp()&&!esVariable.get(i)){
					args.getLista().get(i).setError("Se esperaba un argumento por referencia (designador).");
					aux.add(args.getLista().get(i));
				}
			}
			
		}
		return aux;
	}
	public String codeE(){
		return codeI();
	}
	public String codeI(){
		String code = "";
		int desp = 8;
		// PONGO LOS PARAMETROS ESTATICOS EVALUADOS Y LAS DIRECCIONES DE LOS DINAMICOS
		for (int i = 0; i < this.args.getLista().size(); i++) { 
			if (((NodoArgumento)((NodoFuncion)declaracion).getArgs().getLista().get(i)).getAmp()) {
				code += "get_global $SP\n";
				code += "i32.const "+Integer.toString((Integer)desp)+"\n";
				code += "i32.add\n";
				code +=  args.getLista().get(i).codeD();
				code += "i32.store\n";
				desp += 4;
			}
			else {
				Nodo expr = this.args.getLista().get(i);
				if(expr.nodeKind()!=NodeKind.LLAMADA && (expr.getTipo().getType()!=Type.ARRAY && expr.getTipo().getType()!=Type.STRUCT)){
					if(expr.nodeKind()!=NodeKind.LLAMADA){
						code += "get_global $SP\n";
						code += "i32.const "+Integer.toString((Integer)desp)+"\n";
						code += "i32.add\n";
						code += expr.codeE();
						code += "i32.store\n";
						desp += 4;
					}
				}else if(expr.nodeKind()==NodeKind.LLAMADA) {
						code+=expr.codeE();
						for(int j = 0; j < ((NodoFuncion)(((NodoLlamada)expr).getDeclaracion())).getTipo().size()/4; j++) {
							code += "get_global $SP\n";
							code += "i32.const "+Integer.toString((Integer)desp)+"\n";
							code += "i32.add\n";
							code +="i32.const "+Integer.toString((Integer)j*4)+"\n";
							code +="i32.add\n";
							code+="set_global $asig\n";
							code+="set_global $asig2\n";
							code+="get_global $asig\n";
							code+="get_global $asig2\n";
							code+="i32.store\n";
						}
						desp+=((NodoFuncion)((NodoLlamada)expr).getDeclaracion()).getTipo().size();
				}else if (expr.nodeKind()==NodeKind.LISTA) {
					String actual = "";
					actual += "get_global $SP\n";
					actual += "i32.const "+Integer.toString((Integer)desp)+"\n";
					actual += "i32.add\n";
					code+=asignar2(actual, expr.getTipo(), expr);
					desp+=expr.getTipo().size();
				}else if(expr.nodeKind()==NodeKind.POSICIONARRAY || expr.nodeKind()==NodeKind.ACCESOCAMPO || expr.nodeKind()==NodeKind.VARIABLE){
					String actual = "";
					actual += "get_global $SP\n";
					actual += "i32.const "+Integer.toString((Integer)desp)+"\n";
					actual += "i32.add\n";
					code+=asignar(actual, expr.getTipo(), expr.codeD());
					desp+=expr.getTipo().size();
				}
			}
		}
		// LLAMADA
		code += "call $" + this.nombre + "\n";
		if (((NodoFuncion)declaracion).getTipo() != null) {
			for(int i = (((NodoFuncion)declaracion).getTipo().size())/4 - 1; i >= 0; i--) {
				code += "get_global "+Integer.toString((Integer)i)+"\n";
			}
		}
		return code;
	}
	
	private String asignar2(String pm_guardar, NodoTipo tipoAsignar, Nodo expresion){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			return pm_guardar+expresion.codeE()+"i32.store\n";
		}else if(tipoAsignar.getType()==Type.ARRAY){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
					String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
					nueva_pm_guardar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
					nueva_pm_guardar+="i32.add\n";
				
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);//La nueva expresion que cargar es la poscicion i esima de lo cargado
					code+=asignar2(nueva_pm_guardar,((NodoArray)tipoAsignar).getParam(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return asignar(pm_guardar, tipoAsignar, expresion.codeD());
			}
			
		}else if(tipoAsignar.getType()==Type.STRUCT){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				int acum = 0;
				for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
					String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
					nueva_pm_guardar+="i32.const "+Integer.toString((Integer)acum)+"\n";
					nueva_pm_guardar+="i32.add\n";
					acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
				
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);//La nueva expresion que cargar es la poscicion i esima de lo cargad0
					code+=asignar2(nueva_pm_guardar,((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return asignar(pm_guardar, tipoAsignar, expresion.codeD());
			}
		}
		return "";
	}
	private String asignar(String pm_guardar, NodoTipo tipoAsignar, String pm_cargar){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			return pm_guardar+pm_cargar+"i32.load\n"+"i32.store\n";
		}else if(tipoAsignar.getType()==Type.ARRAY){
			String code="";
			for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
				String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
				nueva_pm_guardar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_guardar+="i32.add\n";
				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_cargar+="i32.add\n";

				code+=asignar(nueva_pm_guardar,((NodoArray)tipoAsignar).getParam(),nueva_pm_cargar);
			}
			return code;
		}else if(tipoAsignar.getType()==Type.STRUCT){
			String code="";
			int acum = 0;
			for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
				String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
				nueva_pm_guardar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_guardar+="i32.add\n";

				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_cargar+="i32.add\n";

				acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();

				code+=asignar(nueva_pm_guardar,((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_pm_cargar);
			}
			return code;
		}
		return "";
	}
	
}
