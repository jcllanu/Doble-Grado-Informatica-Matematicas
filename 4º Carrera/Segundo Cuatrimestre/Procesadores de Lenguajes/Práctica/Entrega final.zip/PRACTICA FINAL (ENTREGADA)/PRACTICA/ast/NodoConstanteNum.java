package ast;

import java.util.*;

public class NodoConstanteNum extends Nodo {

    private int val;

    public NodoConstanteNum(int val, int fila, int columna) {
    	super(fila, columna);
        this.val = val;
        this.tipo = new NodoInt();
    }

    public int getVal() {return val;}

    public void setVal(int val) {this.val=val;}

    public String toString() {
        return Integer.toString((Integer)val);
    }
    public ArrayList<Nodo> bind(Vinculador v){
		return new ArrayList<Nodo>();
	}
	public ArrayList<Nodo> type() {
		return new ArrayList<Nodo>();
	}
	
	public NodeKind nodeKind(){return NodeKind.CONSTANTE;	}
    
	public String codeE(){
		String code="i32.const "+this.toString()+"\n";
		return code;
	}

}
