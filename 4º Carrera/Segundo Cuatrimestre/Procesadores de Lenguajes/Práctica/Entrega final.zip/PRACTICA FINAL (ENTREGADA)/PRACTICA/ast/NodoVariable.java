package ast;

import java.util.*;

public class NodoVariable extends Nodo {

    private String nombre;
    private Nodo definicion;
      
    public NodoVariable(String nombre, int fila, int columna) {
    	super(fila,columna);
        this.nombre = nombre;
    }

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre=nombre;}

    public String toString() {
        return nombre.toString();
    }
   
    public NodeKind nodeKind(){return NodeKind.VARIABLE;}

    public ArrayList<Nodo> bind(Vinculador v){
		this.definicion=v.buscaId(nombre);
        if (this.definicion==null) {
            ArrayList<Nodo> aux = new ArrayList<Nodo>();
            aux.add(this);
            return aux;

        } else {
            return new ArrayList<Nodo>();
        }
	}
	
	public ArrayList<Nodo> type() {
		this.tipo = definicion.getTipo();
		return new ArrayList<Nodo>();
	}

	public String codeE(){
        return this.codeD()+"i32.load\n";
    }
    public String codeD() {
        String code="i32.const "+Integer.toString((Integer)this.getDelta())+"\n";
        //obtener inicio memoria del marco de id
        int ini = 0;
        if(definicion.nodeKind()==NodeKind.INICIALIZACION){
        	if (((NodoInicializacion)definicion).getMiBloque().getFuncion() != null)
            	ini+= ((NodoInicializacion)definicion).getMiBloque().getFuncion().hueco_param();
            ini+= ((NodoInicializacion)definicion).getMiBloque().getInicioMemoriaBloque();
        }else if (definicion.nodeKind()==NodeKind.DECLARACION) {
        	if (((NodoDeclaracion)definicion).getMiBloque().getFuncion() != null)
            	ini+= ((NodoDeclaracion)definicion).getMiBloque().getFuncion().hueco_param();
            ini+=((NodoDeclaracion)definicion).getMiBloque().getInicioMemoriaBloque();
        }else {  // NodeKind.ARGUMENTO
            for(int i = 0; i < ((NodoArgumento)definicion).getFuncion().getArgs().getLista().size(); i++) {
            	if (((NodoArgumento)definicion).getFuncion().getArgs().getLista().get(i) == this.definicion) {
            		break;
            	}
                if(((NodoArgumento)((NodoArgumento)definicion).getFuncion().getArgs().getLista().get(i)).getAmp()){
                    ini+=4;
                }else{
            	    ini += ((NodoArgumento)definicion).getFuncion().getArgs().getLista().get(i).getTipo().size();
                }
            }
        }
        
        code+="i32.const "+Integer.toString((Integer)ini)+"\n";
        code+="i32.add\n";
        boolean b = (definicion.nodeKind()==NodeKind.INICIALIZACION && !((NodoInicializacion)definicion).getLocal()) || (definicion.nodeKind()==NodeKind.DECLARACION && !((NodoDeclaracion)definicion).getLocal());
        if (b) {
        	code+="i32.const 8 ;; Porque es variable global\n";
        	code+="i32.add\n";
        } else {
        	code+="get_local $localsStart\n";
        	code+="i32.add\n";
        }
        if (definicion.nodeKind()==NodeKind.ARGUMENTO && ((NodoArgumento)this.definicion).getAmp()) {
        	code += "i32.load\n";
        }
        return code;
    }

    public int getDelta(){
        return definicion.getDelta();
    }
}
