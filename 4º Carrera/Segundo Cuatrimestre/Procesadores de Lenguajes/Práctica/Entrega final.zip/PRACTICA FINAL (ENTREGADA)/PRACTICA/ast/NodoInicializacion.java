package ast;

import java.util.*;

public class NodoInicializacion extends Nodo {

	private NodoVariable iden;
	private Nodo expr;
    	private boolean local=true;
    	
    public NodoInicializacion(NodoTipo tipo, NodoVariable iden, Nodo expr, int fila, int columna) {
    	super(fila, columna);
    	this.tipo = tipo;
    	this.iden = iden;
		this.expr = expr;
    }
	
	public void setIden(NodoVariable iden) {
    	this.iden = iden;
	}
	
	public NodoVariable getIden() {
		return this.iden;
	}

	public void setExpr(Nodo expr) {
    	this.expr = expr;
	}
	
	public Nodo getExpr() {
		return this.expr;
	}
	  
	public void setGlobal(){
		local=false;
	}
	public boolean getLocal(){
	return this.local;
	}
	public NodeKind nodeKind(){return NodeKind.INICIALIZACION;	}

    public String toString(){return "INIZ("+tipo.toString()+","+iden.toString()+","+expr.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux = expr.bind(v);
		v.insertaId(iden.getNombre(),this);
		iden.bind(v);
		aux.addAll(this.tipo.bind(v));
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = expr.type();
		if (aux.isEmpty()&&!this.tipo.compare(expr.getTipo())) {
			if(expr.getTipo().nodeKind() == NodeKind.STRUCT && this.tipo.nodeKind() == NodeKind.STRUCT){
				expr.setError("A pesar de ser ambos de tipo STRUCT, no comparten los tipos de sus campos.");
				aux.add(expr);
			}
			else {
				this.setError("La declaración de la variable es de tipo "+tipo.toString()+" y la expresión de la asignación es de tipo "+expr.getTipo().toString()+".");
				aux.add(this);
			}
		}
		return aux;
	}
	public String codeI(){
		String code=";;Empieza la inicialización\n";
		if(expr.nodeKind()!=NodeKind.LLAMADA && (expr.getTipo().getType()!=Type.ARRAY && expr.getTipo().getType()!=Type.STRUCT)){
				code+=iden.codeD();
				code+=expr.codeE();
				code+="i32.store\n;;Termina la asignacion\n";
		}else if(expr.nodeKind()==NodeKind.LLAMADA) {
				code+=expr.codeE();
				for(int i = 0; i < ((NodoFuncion)((NodoLlamada)expr).getDeclaracion()).getTipo().size()/4; i++) {
					code+=iden.codeD();
					code+="i32.const "+Integer.toString((Integer)i*4)+"\n";
					code+="i32.add\n";
					code+="set_global $asig\n";
					code+="set_global $asig2\n";
					code+="get_global $asig\n";
					code+="get_global $asig2\n";
					code+="i32.store\n";
				}
		}else if (expr.nodeKind()==NodeKind.LISTA) {
			code+=asignar2(iden.codeD(), expr.getTipo(), expr);
			code+=";;Termina la asignacion\n";
		}else if(expr.nodeKind()==NodeKind.POSICIONARRAY || expr.nodeKind()==NodeKind.ACCESOCAMPO || expr.nodeKind()==NodeKind.VARIABLE){
			code+=asignar(iden.codeD(), expr.getTipo(), expr.codeD());
			code+=";;Termina la asignacion\n";
		}
		return code;
	}
	private String asignar2(String pm_guardar, NodoTipo tipoAsignar, Nodo expresion){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			return pm_guardar+expresion.codeE()+"i32.store\n";
		}else if(tipoAsignar.getType()==Type.ARRAY){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
					String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
					nueva_pm_guardar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
					nueva_pm_guardar+="i32.add\n";
				
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);//La nueva expresion que cargar es la poscicion i esima de lo cargad0
					code+=asignar2(nueva_pm_guardar,((NodoArray)tipoAsignar).getParam(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expr.nodeKind()==NodeKind.VARIABLE){
				return asignar(pm_guardar, tipoAsignar, expresion.codeD());
			}
			
		}else if(tipoAsignar.getType()==Type.STRUCT){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				int acum = 0;
				for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
					String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
					nueva_pm_guardar+="i32.const "+Integer.toString((Integer)acum)+"\n";
					nueva_pm_guardar+="i32.add\n";
					acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
				
					Nodo nueva_expresion=((NodoLista)expresion).getLista().get(i);//La nueva expresion que cargar es la poscicion i esima de lo cargad0
					code+=asignar2(nueva_pm_guardar,((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_expresion);
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expr.nodeKind()==NodeKind.VARIABLE){
				return asignar(pm_guardar, tipoAsignar, expresion.codeD());
			}
			return "";
		}
		return "";
	}
	private String asignar(String pm_guardar, NodoTipo tipoAsignar, String pm_cargar){
		if(tipoAsignar.getType()!=Type.ARRAY &&tipoAsignar.getType()!=Type.STRUCT){
			return pm_guardar+pm_cargar+"i32.load\n"+"i32.store\n";
		}else if(tipoAsignar.getType()==Type.ARRAY){
			String code="";
			for(int i=0; i<((NodoArray)tipoAsignar).getTam();i++){
				String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
				nueva_pm_guardar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_guardar+="i32.add\n";
				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)((NodoArray)tipoAsignar).getParam().size()*i)+"\n";
				nueva_pm_cargar+="i32.add\n";

				code+=asignar(nueva_pm_guardar,((NodoArray)tipoAsignar).getParam(),nueva_pm_cargar);
			}
			return code;
		}else if(tipoAsignar.getType()==Type.STRUCT){
			String code="";
			int acum = 0;
			for(int i=0; i<((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().size();i++){
				String nueva_pm_guardar=pm_guardar;//La nueva posición donde guardar es la actual mas i veces el tamaño de lo guardado
				nueva_pm_guardar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_guardar+="i32.add\n";

				String nueva_pm_cargar=pm_cargar;//La nueva posición de donde cargar es la actual mas i veces el tamaño de lo cargado
				nueva_pm_cargar+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm_cargar+="i32.add\n";

				acum += ((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo().size();

				code+=asignar(nueva_pm_guardar,((NodoStruct)tipoAsignar).getDeclaracion().getCampos().getLista().get(i).getTipo(),nueva_pm_cargar);
			}
			return code;
		}
		return "";
	}
	public int calcular_delta(int delta, NodoInstrucciones n){
		this.miBloque=n;
		this.delta=delta;
		return this.tipo.size();
	}
	
	public void maxMemory(Entero c, Entero max){
		c.setEntero(tipo.size()+c.getEntero());
		if(c.getEntero()>max.getEntero()){max.setEntero(c.getEntero());}
	}
}

