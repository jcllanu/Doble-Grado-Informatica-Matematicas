package ast;

import java.util.*;

public class NodoFuncion extends Nodo {
	
	private String nombre;
	private Lista args;
	private Nodo bloc;
	private int numero_args;
	int inicio_memoria_funcion;
	
	public NodoFuncion() {
		super();
		this.tipo = null;
		this.nombre = "";
		this.args = null;
		this.bloc = null;
		this.numero_args = 0;
	}
	
	public NodoFuncion(NodoTipo type, String nombre) {
		super();
		this.tipo = type;
		this.nombre = nombre;
		this.args = null;
		this.bloc = null;
		this.numero_args = 0;
	}
	
	public NodoFuncion(NodoTipo type, String nombre, Nodo bloc) {
		super();
		this.tipo = type;
		this.nombre = nombre;
		this.args = null;
		this.bloc = bloc;
		this.numero_args = 0;
	}
	
	public NodoFuncion(NodoTipo type, String nombre, Lista args, int numero_args) {
		super();
		this.tipo = type;
		this.nombre = nombre;
		this.args = args;
		this.bloc = null;
		this.numero_args = numero_args;
	}
	
	public NodoFuncion(String nombre, Lista args, int numero_args, Nodo bloc) {
		super();
		this.tipo = null;
		this.nombre = nombre;
		this.args = args;
		this.bloc = bloc;
		this.numero_args = 0;
	}
	
	public NodoFuncion(NodoTipo type, String nombre, Lista args, int numero_args, Nodo bloc) {
		super();
		this.tipo = type;
		this.nombre = nombre;
		this.args = args;
		this.bloc = bloc;
		this.numero_args = 0;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Lista getArgs() {
		return this.args;
	}

	public void setArgs(Lista args) {
		this.args = args;
	}

	public Nodo getBloc() {
		return this.bloc;
	}

	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public int getNumero_args() {
		return this.numero_args;
	}

	public void setNumero_args(int numero_args) {
		this.numero_args = numero_args;
	}
	public NodeKind nodeKind() { return NodeKind.FUNCION; }

    public String toString(){
    	if (tipo != null) { return "FUNC("+tipo.toString()+","+nombre+","+args.toString()+","+bloc.toString()+")";}
    	else { return "FUNC(void,"+nombre+","+args.toString()+","+bloc.toString()+")";}
	}
	
	public ArrayList<Nodo> bind(Vinculador v){
		v.setFuncionActual(this);
		v.abreBloque();
		ArrayList<Nodo> aux = new ArrayList<Nodo>();
		if (this.tipo != null) {
			aux.addAll(this.tipo.bind(v));
		}
		aux.addAll(args.bind(v));
		aux.addAll(bloc.bind(v));
		v.cierraBloque();
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		return bloc.type();
	}
	
	public String generateCode(){
		args.calcula_hueco_param(this);
		bloc.calcula_hueco_param(this);
		((NodoInstrucciones)bloc).setInicioMemoriaBloque(inicio_memoria_funcion);
		String code = "";
		Entero max=new Entero(0);
		Entero c=new Entero(0);
		bloc.maxMemory(c,max);
		if (this.nombre.equals("main")) {
			code += "(func $main_real\n(local $temp i32)\n(local $localsStart i32)\ni32.const "+Integer.toString((Integer)(max.getEntero()+8))+"  ;; let this be the stack size needed (params+locals+2)*4\ncall $reserveStack  ;; returns old MP (dynamic link)\nset_local $temp\nget_global $MP\nget_local $temp\ni32.store\nget_global $MP\nget_global $SP\ni32.store offset=4\nget_global $MP\ni32.const 8\ni32.add\nset_local $localsStart\n";
			code += bloc.generateCode();
			code += "call $freeStack\n";
			code+=")\n";
		}
		else {
		
			code += "(func $"+this.nombre+"\n";
            code += "(local $temp i32)\n(local $localsStart i32)\ni32.const "+Integer.toString((Integer)(max.getEntero()+this.hueco_param()+8))+"  ;; let this be the stack size needed (params+locals+2)*4\ncall $reserveStack  ;; returns old MP (dynamic link)\nset_local $temp\nget_global $MP\nget_local $temp\ni32.store\nget_global $MP\nget_global $SP\ni32.store offset=4\nget_global $MP\ni32.const 8\ni32.add\nset_local $localsStart\n";
			code += bloc.generateCode();
			code += "call $freeStack\n";							
			code += ")\n";
		}
		return code;
	}
	
	public void setInicioMemoriaFuncion(int n){
		inicio_memoria_funcion=n;
	}
	
	public int hueco_param() {
		int tam = 0;
		for(int i = 0; i < args.getLista().size(); i++) {
			if(((NodoArgumento)args.getLista().get(i)).getAmp()){
				tam += 4;
			}else{
				tam += args.getLista().get(i).getTipo().size();
			}
			
		}
		return tam;
	}
	public int getMax(){
		if(tipo==null){return 0;}
		return tipo.size()/4;
	}
}
