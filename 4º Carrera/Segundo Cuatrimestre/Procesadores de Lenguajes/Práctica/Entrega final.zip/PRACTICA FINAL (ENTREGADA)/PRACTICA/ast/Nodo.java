package ast;

public abstract class Nodo implements ASTNode {

	protected NodoTipo tipo = null;
	protected int fila;
	protected int columna;
    protected String error="";
    protected int delta=0;
    protected NodoInstrucciones miBloque;
    protected NodoFuncion miFuncion;
    
    public Nodo() {
    	super();
    }
    
    public Nodo(int fila, int columna) {
    	super();
    	this.fila = fila;
    	this.columna = columna;
    }
    
    public Nodo(NodoTipo tipo) {
    	super();
    	this.tipo = tipo;
    }
    
    public Nodo(NodoTipo tipo, int fila, int columna) {
    	super();
    	this.tipo = tipo;
    	this.fila = fila;
    	this.columna = columna;
    }
    
    public NodoTipo getTipo() {
    	return this.tipo;
    }
    
    public void setTipo(NodoTipo tipo) {
    	this.tipo = tipo;
    }
    
     public int getFila() {
    	return this.fila;
    }
    
    public void setFila(int fila) {
    	this.fila = fila;
    }
    
     public int getColumna() {
    	return this.columna;
    }
    
    public void setColumna(int columna) {
    	this.columna = columna;
    }

    public String getError() {
    	return this.error;
    }
    
    public void setError(String error) {
    	this.error = error;
    }
    public int getDelta() {
    	return this.delta;
    }
    public NodoInstrucciones getMiBloque(){
		return miBloque;
	}
    public String codeE(){return "";};
    public String codeD(){return "";};
    public String codeI(){return "";};
    public String generateCode(){return "";};
    
    public void calcula_hueco_param(NodoFuncion f) {
    	miFuncion = f;
    }
    
    public int calcular_delta(int delta,NodoInstrucciones n){
        miBloque=n;
        return 0;
    }
    
    public NodoFuncion getFuncion() {
	return this.miFuncion;
    }
    public void maxMemory(Entero c, Entero max){}
}
