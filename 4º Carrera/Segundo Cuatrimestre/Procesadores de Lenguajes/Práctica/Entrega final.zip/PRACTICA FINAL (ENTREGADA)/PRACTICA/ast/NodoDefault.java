package ast;

import java.util.*;

public class NodoDefault extends Nodo {

	private Nodo bloc;
    
    public NodoDefault() {
    	super();
    	
    	this.bloc = null;
    }
    
    public NodoDefault(Nodo bloc) {
    	super();
    	
    	this.bloc = bloc;
    }
    
	
	public Nodo getBloc() {
		return this.bloc;
	}
	
	
	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public NodeKind nodeKind(){return NodeKind.DEFAULT;}
    public String toString(){return "DEFAULT("+bloc.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		v.abreBloque();
		ArrayList<Nodo> aux= bloc.bind(v);
		v.cierraBloque();
		return aux;
	}
	
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		bloc.calcula_hueco_param(f);
	}
	
	public ArrayList<Nodo> type() {
		return bloc.type();
	}
	public String generateCode(){
		((NodoInstrucciones)bloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		return bloc.generateCode();
	}
	public void maxMemory(Entero c, Entero max){
		Entero c1=new Entero(0);
		Entero max1=new Entero(0);
		bloc.maxMemory(c1,max1);
		if(c.getEntero()+max1.getEntero()>max.getEntero()){
			max.setEntero(c.getEntero()+max1.getEntero());
		}
	}
}
