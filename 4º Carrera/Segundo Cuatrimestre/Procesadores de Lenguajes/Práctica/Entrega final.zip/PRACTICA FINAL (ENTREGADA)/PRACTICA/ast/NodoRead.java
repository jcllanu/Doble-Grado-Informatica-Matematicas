package ast;

import java.util.*;

public class NodoRead extends Nodo {

    private Nodo iden;

    public NodoRead(Nodo iden, int fila, int columna) {
    	super(fila, columna);
    	this.iden = iden;
    }

    public void setIden(Nodo iden) {
    	this.iden = iden;
	}
	
	public Nodo getIden() {
		return this.iden;
	}
	
	public NodeKind nodeKind(){return NodeKind.READ;}
    public String toString(){return "READ("+iden.toString()+")";}
	public ArrayList<Nodo> bind(Vinculador v){
		return iden.bind(v);
	}
	public ArrayList<Nodo> type() {
		return iden.type();
	}
	/*public String codeI(){
		String code=iden.codeD()+"call $read\ni32.store\n";
		return code;
	}*/

	public String codeI(){
		return leer(iden.codeD(),iden.getTipo());
	}

	public String leer(String pm, NodoTipo tipo){
		if(tipo.getType()==Type.INT || tipo.getType()==Type.BOOL){
			return pm+"call $read\ni32.store\n";
		}else if(tipo.getType()==Type.ARRAY){
			String code="";
			for(int i=0; i<((NodoArray)tipo).getTam();i++){
				String nueva_pm=pm;
				nueva_pm+="i32.const "+Integer.toString((Integer)((NodoArray)tipo).getParam().size()*i)+"\n";
				nueva_pm+="i32.add\n";
				code+=leer(nueva_pm,((NodoArray)tipo).getParam());
			}
			return code;
			
		}else if(tipo.getType()==Type.STRUCT){
			String code="";
			int acum = 0;
			for(int i=0; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
				String nueva_pm=pm;
				nueva_pm+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm+="i32.add\n";
				acum += ((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
				code+=leer(nueva_pm,((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
			}
			return code;
		}
		return "";
	}
}
