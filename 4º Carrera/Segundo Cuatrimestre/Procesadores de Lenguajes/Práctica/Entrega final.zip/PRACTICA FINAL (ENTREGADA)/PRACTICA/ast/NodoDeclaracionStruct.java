package ast;

import java.util.*;

public class NodoDeclaracionStruct extends Nodo {
	
	private String nombre;
	private Lista campos;
	private NodoInstrucciones bloqueAsociado;
	public NodoDeclaracionStruct(String nombre, Lista campos) {
		super();
		this.nombre = nombre;
		this.campos = campos;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Lista getCampos() {
		return this.campos;
	}

	public void setCampos(Lista campos) {
		this.campos = campos;
	}

	public NodeKind nodeKind() { return NodeKind.DECLARACIONSTRUCT; }

    public String toString(){
    	return "DECLARACION_STRUCT("+nombre+","+campos.toString()+")";
	}
	
	public ArrayList<Nodo> bind(Vinculador v){
		v.abreBloque();	
		ArrayList<Nodo> aux = campos.bind(v);
		v.cierraBloque();
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		return campos.type();
	}
	public String generateCode(){
		String code="";
		return code;
	}
	public int calcular_delta(int delta, NodoInstrucciones n){
		this.delta=0;
		bloqueAsociado=new NodoInstrucciones(delta);
		for(Nodo m: campos.getLista()){
			this.delta+=m.calcular_delta(this.delta,bloqueAsociado);
		}
		return this.delta;
	}
}
