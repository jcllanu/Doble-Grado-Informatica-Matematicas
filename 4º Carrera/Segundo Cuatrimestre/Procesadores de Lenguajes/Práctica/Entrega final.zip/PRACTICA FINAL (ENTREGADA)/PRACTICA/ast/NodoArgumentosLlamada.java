package ast;

import java.util.*;

public class NodoArgumentosLlamada extends Lista {

    ArrayList<Nodo> tipos = null;
	ArrayList<Boolean> esVariable = null;
	
    public NodoArgumentosLlamada() {
    	super();
    	tipos = new ArrayList<Nodo>();
		esVariable = new ArrayList<Boolean>();
    }
    
    public NodoArgumentosLlamada(Nodo ins) {
    	super(ins);
    	tipos = new ArrayList<Nodo>();
		esVariable = new ArrayList<Boolean>();
    }
    
    public NodeKind nodeKind(){return NodeKind.ARGUMENTOSLLAMADA;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    return "ARGUMENTOSLLAMADA("+l+")";
    }
    
    public ArrayList<Nodo> getTipos() {
    	return this.tipos;
    }
    public ArrayList<Boolean> getEsVariable() {
    	return this.esVariable;
    }
    public ArrayList<Nodo> type() {
    	ArrayList<Nodo> aux = new ArrayList<Nodo>();
    	for(int i = 0; i < lista.size(); i++) {
			ArrayList<Nodo> aux2 =lista.get(i).type();
    		aux.addAll(aux2);
			if(aux2.isEmpty()){
    			tipos.add(lista.get(i).getTipo());
				esVariable.add(lista.get(i).nodeKind()==NodeKind.VARIABLE||lista.get(i).nodeKind()==NodeKind.POSICIONARRAY||lista.get(i).nodeKind()==NodeKind.ACCESOCAMPO);
    		}
		}
    	return aux;
    }
	public String generateCode(){
		String code="";
		return code;
	}
}
