package ast;

import java.util.*;

public class NodoConstanteBool extends Nodo {

    private boolean val;

    public NodoConstanteBool(boolean val, int fila, int columna) {
    	super(fila, columna);
        this.val = val;
        this.tipo = new NodoBool();
    }

    public boolean getVal() {return val;}

    public void setVal(boolean val) {this.val=val;}

    public String toString() {
        if(val) { return "true"; }
        else {return "false"; }
    }
    public ArrayList<Nodo> bind(Vinculador v){
		return new ArrayList<Nodo>();
	}
	public ArrayList<Nodo> type() {
		return new ArrayList<Nodo>();
	}
	
	public NodeKind nodeKind(){return NodeKind.CONSTANTE;	}
	public String codeE(){
		String code="";
		if(val){
		 	code="i32.const 1\n";
		}else{
			code="i32.const 0\n";
		}
		return code;
	}
	
}
