package ast;
import java.util.*;
public class Vinculador {

	ArrayList<HashMap<String,Nodo>> pila;
	Nodo funcionactual=null;

	public void inicializa(){
		pila=new ArrayList<HashMap<String,Nodo>> ();
	}
	public void abreBloque(){
		pila.add(new HashMap<String,Nodo>());
	}
	public void cierraBloque(){
		pila.remove(pila.size()-1);
	}
	public void insertaId(String id, Nodo puntero){
		pila.get(pila.size()-1).put(id,puntero);
	}
	public Nodo buscaId(String id){
		for(int i=pila.size()-1; i>=0;i--){
			Nodo aux=pila.get(i).get(id);
			if(aux!=null){
				return aux;
			}
		}
		return null;
	}

	public void setFuncionActual(Nodo n){
		this.funcionactual=n;
	}
	
	public Nodo getFuncionActual(){
		return this.funcionactual;
	}
	
}   

   
