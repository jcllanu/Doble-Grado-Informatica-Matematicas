package ast;

import java.util.*;

public class Creations extends Nodo {

	private Nodo structs;
	private Nodo vars;
    
    public Creations(Nodo structs, Nodo vars) {
    	super();
    	this.structs = structs;
    	this.vars = vars;
    }
    
    public void setVars(Nodo vars) {
    	this.vars = vars;
	}
	
	public Nodo getVars() {
		return this.vars;
	}
	
	public void setStructs(Nodo structs) {
    	this.structs = structs;
	}
	
	public Nodo getStructs() {
		return this.structs;
	}
	
	public NodeKind nodeKind() { return NodeKind.CREATIONS; }

    public String toString() { return "creations("+structs.toString()+","+vars.toString()+")"; }
	
	public ArrayList<Nodo> bind(Vinculador v) {
		ArrayList<Nodo> aux  = structs.bind(v);
		ArrayList<Nodo> aux2 = vars.bind(v);
		aux.addAll(aux2);
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux  = structs.type();
		ArrayList<Nodo> aux2 = vars.type();
		aux.addAll(aux2); 
		return aux;
	}
	
	public String generateCode(){
		return vars.generateCode();
	}

	public int calcular_delta(int delta, NodoInstrucciones n){
		this.delta=structs.calcular_delta(0,n);
		this.delta=vars.calcular_delta(this.delta,n);
		return this.delta;
	}
}
