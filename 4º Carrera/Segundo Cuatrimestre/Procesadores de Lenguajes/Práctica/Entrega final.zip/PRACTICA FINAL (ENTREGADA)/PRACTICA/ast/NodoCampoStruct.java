package ast;

import java.util.*;

public class NodoCampoStruct extends Nodo {

    private Nodo pm;
    private NodoVariable campo;

    public NodoCampoStruct(Nodo pm, NodoVariable campo, int fila, int columna) {
    	super(fila, columna);
        this.pm = pm;
        this.campo = campo;
    }

    public String toString(){return "(.)("+pm.toString()+","+campo.toString()+")";}
    
    public NodeKind nodeKind(){return NodeKind.ACCESOCAMPO;}

    public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux=pm.bind(v);
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = pm.type();
		if(aux.isEmpty()){
			if(pm.getTipo().getType()!=Type.STRUCT){
				pm.setError("El operador (.) solo es aplicable a instancias de tipo STRUCT. Se ha tipado como "+pm.getTipo().toString()+".");
				aux.add(pm);
			}
		}
		if(aux.isEmpty()) {
			if (!((NodoStruct)pm.getTipo()).getDeclaracion().getCampos().hayCampo(campo.getNombre())) {
				campo.setError("No hay ningún campo "+campo.getNombre()+" en "+pm.getTipo().toString()+".");
				aux.add(this.campo);
			}
			else {
				this.tipo = ((NodoStruct)pm.getTipo()).getDeclaracion().getCampos().tipoCampo(campo.getNombre());
			}
		} 
		return aux;
	}
	public String codeE(){
        return this.codeD()+"\ni32.load\n";
    }
	public String codeD(){
		String code = pm.codeD();
		code+="i32.const "+((NodoStruct)pm.getTipo()).getDeclaracion().getCampos().getDeltaCampo(campo.getNombre())+"\n";
		code+="i32.add\n";
		return code;
	}
}
