package ast;

import java.util.*;

public class NodoVarCreations extends Lista {

    public NodoVarCreations() {
    	super();
    }
    
    public NodoVarCreations(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){return NodeKind.VARCREATIONS;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    	return "VARCREATIONS("+l+")";
    }
	public String generateCode(){
		String code="";
		for(Nodo n: lista){
			if(n.nodeKind()==NodeKind.INICIALIZACION){
				((NodoInicializacion)n).setGlobal();
			}else if(n.nodeKind()==NodeKind.DECLARACION){
				((NodoDeclaracion)n).setGlobal();
			}
			code+=n.codeI();
			
		}
		return code;
	}
	public int calcular_delta(int delta, NodoInstrucciones n){
		this.delta=0;
		for(Nodo m: lista){
			this.delta+=m.calcular_delta(this.delta,n);
		}
		return this.delta;
	}
}
