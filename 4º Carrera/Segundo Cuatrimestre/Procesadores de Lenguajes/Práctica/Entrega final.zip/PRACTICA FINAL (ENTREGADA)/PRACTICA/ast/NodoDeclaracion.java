package ast;

import java.util.*;

public class NodoDeclaracion extends Nodo {

	private NodoVariable iden;   
	 private boolean local=true;
    public NodoDeclaracion(NodoTipo tipo, NodoVariable iden) {
    	super();
    	this.tipo = tipo;
    	this.iden = iden;
    }
	
	public void setIden(NodoVariable iden) {
    	this.iden = iden;
	}
	
	public NodoVariable getIden() {
		return this.iden;
	}
	public NodeKind nodeKind(){return NodeKind.DECLARACION;	}
	public void setGlobal(){
		local=false;
	}
	public boolean getLocal(){
	return this.local;
	}
    public String toString(){return "DECL("+tipo.toString()+","+iden.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		v.insertaId(iden.getNombre(),this);
		return this.tipo.bind(v);
	}
	
	public ArrayList<Nodo> type() {
		return new ArrayList<Nodo>();
	}
	public String generateCode(){
		String code="";
		return code;
	}
	public int calcular_delta(int delta, NodoInstrucciones n){
		this.miBloque=n;
		this.delta=delta;
		return this.tipo.size();
	}
	public void maxMemory(Entero c, Entero max){
		c.setEntero(tipo.size()+c.getEntero());
		if(c.getEntero()>max.getEntero()){max.setEntero(c.getEntero());}
	}
}
