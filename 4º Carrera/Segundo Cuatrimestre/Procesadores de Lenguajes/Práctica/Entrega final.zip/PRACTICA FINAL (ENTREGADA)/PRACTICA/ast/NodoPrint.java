package ast;

import java.util.*;

public class NodoPrint extends Nodo {

    private Nodo expr;

    public NodoPrint(Nodo expr, int fila, int columna) {
    	super(fila, columna);
    	this.expr = expr;
    }

    public void setExpr(Nodo expr) {
    	this.expr = expr;
	}
	
	public Nodo getExpr() {
		return this.expr;
	}
	
	public NodeKind nodeKind(){return NodeKind.PRINT;}
    public String toString(){return "PRINT("+expr.toString()+")";}
	public ArrayList<Nodo> bind(Vinculador v){
		return expr.bind(v);
	}
	public ArrayList<Nodo> type() {
		return expr.type();
	}

	public String codeI(){
		return ";;Empieza el print\n"+imprimir(expr,expr.getTipo())+";;Termina el print\n";
	}

	public String imprimir(Nodo expresion, NodoTipo tipo){
		if(tipo.getType()==Type.INT || tipo.getType()==Type.BOOL){
			return expresion.codeE()+"call $print\n";
		}else if(tipo.getType()==Type.ARRAY){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoArray)tipo).getTam();i++){
					code+=imprimir(((NodoLista)expresion).getLista().get(i),((NodoArray)tipo).getParam());
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return imprimir2(expresion.codeD(), tipo);
			}
			
		}else if(tipo.getType()==Type.STRUCT){
			if(expresion.nodeKind()==NodeKind.LISTA){
				String code="";
				for(int i=0; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
					code+=imprimir(((NodoLista)expresion).getLista().get(i),((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
				}
				return code;
			}
			else if(expresion.nodeKind()==NodeKind.POSICIONARRAY||expresion.nodeKind()==NodeKind.ACCESOCAMPO|| expresion.nodeKind()==NodeKind.VARIABLE){
				return imprimir2(expresion.codeD(), tipo);
			}
		}
		return "";
	}

	public String imprimir2(String pm, NodoTipo tipo){
		if(tipo.getType()==Type.INT || tipo.getType()==Type.BOOL){
			return pm+"i32.load\n"+"call $print\n";
		}else if(tipo.getType()==Type.ARRAY){
			String code="";
			for(int i=0; i<((NodoArray)tipo).getTam();i++){
				String nueva_pm=pm;
				nueva_pm+="i32.const "+Integer.toString((Integer)((NodoArray)tipo).getParam().size()*i)+"\n";
				nueva_pm+="i32.add\n";
				code+=imprimir2(nueva_pm,((NodoArray)tipo).getParam());
			}
			return code;
			
		}else if(tipo.getType()==Type.STRUCT){
			String code="";
			int acum = 0;
			for(int i=0; i<((NodoStruct)tipo).getDeclaracion().getCampos().getLista().size();i++){
				String nueva_pm=pm;
				nueva_pm+="i32.const "+Integer.toString((Integer)acum)+"\n";
				nueva_pm+="i32.add\n";
				acum += ((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo().size();
				code+=imprimir2(nueva_pm,((NodoStruct)tipo).getDeclaracion().getCampos().getLista().get(i).getTipo());
			}
			return code;
		}
		return "";
	}
}
