package ast;

import java.util.*;

public class NodoArray extends NodoTipo {

	private NodoTipo param;
	private int tam;
    
    public NodoArray(NodoTipo param, int tam) {     // Constructora para arrays
    	super(Type.ARRAY);
    	this.param = param;
		this.tam = tam;
    }

   
	public void setParam(NodoTipo param) {
    	this.param = param;
	}
	
	public NodoTipo getParam() {
		return this.param;
	}

	public void setTam(int tam) {
    	this.tam = tam;
	}
	
	public int getTam() {
		return this.tam;
	}

    public String toString(){return "ARRAY("+param.toString()+","+tam+")";}
    
    public ArrayList<Nodo> bind(Vinculador v) {
    	return param.bind(v);
    }
    
    public ArrayList<Nodo> type() {
    	return param.type();
    }
    
    public int size() {
    	return tam * param.size();
    }
    
	public String generateCode(){
		String code="";
		return code;
	}    
}

