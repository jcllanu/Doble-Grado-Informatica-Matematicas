package ast;

import java.util.*;

public class NodoPosicionArray extends Nodo {

    private Nodo pm;
    private Nodo expr;

    public NodoPosicionArray(Nodo pm, Nodo expr, int fila, int columna) {
    	super(fila, columna);
        this.pm = pm;
        this.expr = expr;
    }

    public String toString(){return "[]("+pm.toString()+","+expr.toString()+")";}
    
    public NodeKind nodeKind(){return NodeKind.POSICIONARRAY;}

    public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux=pm.bind(v);
		aux.addAll(expr.bind(v));
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = pm.type();
		if(aux.isEmpty()){
			if(pm.getTipo().getType()!=Type.ARRAY){
				pm.setError("El operador [] solo es aplicable a instancias de tipo ARRAY. Se ha tipado como "+pm.getTipo().toString()+".");
				aux.add(pm);
			}else{
				this.tipo=((NodoArray)pm.getTipo()).getParam();
			}
		}
		ArrayList<Nodo> aux2=expr.type();
		aux.addAll(aux2);
		if(aux.isEmpty() && expr.getTipo().getType() != Type.INT) {
			expr.setError("El tipo de la expresión de acceso al ARRAY debe ser INT. Se ha tipado como "+expr.getTipo().toString()+".");
			aux.add(this.expr);
		}
		return aux;
	}
	public String codeE(){
        return this.codeD()+"i32.load\n";
    }
	
	public String codeD(){
    	String code = pm.codeD();
		code+="i32.const "+Integer.toString((Integer)this.tipo.size())+"\n";
		code+=expr.codeE();
		code+="i32.mul\ni32.add\n";
		return code;
    }
}
