package ast;

import java.util.*;

public abstract class Lista extends Nodo {

	protected ArrayList<Nodo> lista;	  
	protected Nodo expr;				  // Atributo para la expresión inicial de los SWITCH
	
	public Lista() {
		super();
		this.expr = null;
		this.lista = new ArrayList<Nodo>();
	}
	
	public Lista(int fila, int columna) {
		super(fila, columna);
		this.expr = null;
		this.lista = new ArrayList<Nodo>();
	}
	
	public Lista(Nodo ins) {
		super();
		this.expr = null;
		this.lista = new ArrayList<Nodo>();
    	this.lista.add(0, ins);
	}
	
	public Lista(Nodo ins, int fila, int columna) {
		super(fila, columna);
		this.expr = null;
		this.lista = new ArrayList<Nodo>();
		this.lista.add(0, ins);
	}
	
	public Lista(ArrayList<Nodo> lista, int fila, int columna) {
		super(fila, columna);
		this.lista = lista;
	}
	
	public ArrayList<Nodo> getLista() {
		return this.lista;
	}
	
	public Nodo getExpr() {
		return this.expr;
	}
	
	public void setExpr(Nodo expr) {
		this.expr = expr;
	}

	public void add(Nodo ins){
    	this.lista.add(0, ins);		// Añade un Nodo a la lista por el principio.
    }
    
    public boolean hayCampo(String campo) {
    	boolean hay = false;
    	for (int i = 0; i < lista.size(); i++) {
    		if (lista.get(i).nodeKind() == NodeKind.INICIALIZACION) {
    			if (campo.equals(((NodoInicializacion)lista.get(i)).getIden().getNombre())) { hay = true; }
    		}
    		else {
    			if (campo.equals(((NodoDeclaracion)lista.get(i)).getIden().getNombre())) { hay = true; }
    		}
    	}
    	return hay;
    }
    
    public NodoTipo tipoCampo(String campo) {
    	NodoTipo sol = null;
    	for (int i = 0; i < lista.size(); i++) {
    		if (lista.get(i).nodeKind() == NodeKind.INICIALIZACION) {
    			if (campo.equals(((NodoInicializacion)lista.get(i)).getIden().getNombre())) { sol = lista.get(i).getTipo(); }
    		}
    		else {
    			if (campo.equals(((NodoDeclaracion)lista.get(i)).getIden().getNombre())) { sol = lista.get(i).getTipo(); }
    		}
    	}
    	return sol;
    }

	public String getDeltaCampo(String campo) {
		String sol = null;
    	for (int i = 0; i < lista.size(); i++) {
    		if (lista.get(i).nodeKind() == NodeKind.INICIALIZACION) {
    			if (campo.equals(((NodoInicializacion)lista.get(i)).getIden().getNombre())) { sol = Integer.toString((Integer)lista.get(i).getDelta()); }
    		}
    		else {
    			if (campo.equals(((NodoDeclaracion)lista.get(i)).getIden().getNombre())) { sol = Integer.toString((Integer)lista.get(i).getDelta()); }
    		}
    	}
    	return sol;
    }
    
    public boolean compruebaTipos(ArrayList<Nodo> c) {
    	boolean ok = true;
    	for(int i = 0; i < this.lista.size(); i++) {
    		if (!this.lista.get(i).getTipo().compare(c.get(i).getTipo())){
    			ok = false;
    		}
    	}
    	return ok;
    }
	
	public ArrayList<Nodo> bind(Vinculador v) {
		ArrayList<Nodo> aux = new ArrayList<Nodo>();
		for (int i = 0; i < lista.size(); i++) {
    		aux.addAll(lista.get(i).bind(v));
    	}
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = new ArrayList<Nodo>();
		for (int i = 0; i < lista.size(); i++){
    		aux.addAll(lista.get(i).type());
    		}
		return aux;
	}
	public String generateCode(){
		String code="";
		return code;
	}
	
}
