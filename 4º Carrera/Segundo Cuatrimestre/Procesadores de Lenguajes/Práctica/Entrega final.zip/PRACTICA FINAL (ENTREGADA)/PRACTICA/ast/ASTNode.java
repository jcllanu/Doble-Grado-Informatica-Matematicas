package ast;

import java.util.*;

interface ASTNode {

	// Devuelve la lista de nodos con errores de tipado, o la lista vacía si todos están bien tipados.
	
    public ArrayList<Nodo> type();
    
    // Devuelve la lista de nodos con errores de vinculación, o la lista vacía si todos están bien vinculados.
    
    public ArrayList<Nodo> bind(Vinculador v);
    
    public String generateCode();

    public String codeE();
    public String codeD();
    public String codeI();

    public NodeKind nodeKind();
    
    public String toString();

    public void calcula_hueco_param(NodoFuncion f);
    public int calcular_delta(int delta, NodoInstrucciones n);
    public void maxMemory(Entero c, Entero max); 

    
}
