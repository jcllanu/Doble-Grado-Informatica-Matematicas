package ast;

import java.util.*;

public class NodoFunciones extends Lista {
    private int espacio_globales;
    public NodoFunciones() {
    	super();
    }
    
    public NodoFunciones(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){return NodeKind.FUNCIONES;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    		for (int i = 0; i < lista.size() - 1; i++){
    			l=l+lista.get(i).toString()+",";
    		}
    		l=l+lista.get(lista.size()-1).toString();
    	}
    	return "FUNCIONES("+l+")";
    }
    
    public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux = new ArrayList<Nodo>();
		//Primero metemos los nombres de todas las funciones
		for (int i = 0; i < lista.size(); i++){
			NodoFuncion n =(NodoFuncion)lista.get(i);
			v.insertaId(n.getNombre(),n);
		}
		//Después vinculamos cada función
		for (int i = 0; i < lista.size(); i++){
    		aux.addAll(lista.get(i).bind(v));
    	}
		return aux;
	}
	public String generateCode(){
		String code="";
		for(Nodo n: lista){
			((NodoFuncion)n).setInicioMemoriaFuncion(0);
			code+=n.generateCode();
		}
		return code;
	}
	public void setEspacioGlobales(int n){
		espacio_globales=n;
	}
	public int getMax(){
		int max=0;
		for(Nodo n: lista){
			int aux=((NodoFuncion)n).getMax();
			if(aux>max){max=aux;}
		}
		return max;
	}
}
