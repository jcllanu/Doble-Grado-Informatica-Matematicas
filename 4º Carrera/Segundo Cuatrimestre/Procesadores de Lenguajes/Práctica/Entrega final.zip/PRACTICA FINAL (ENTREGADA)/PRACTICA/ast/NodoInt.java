package ast;

public class NodoInt extends NodoTipo {

	public NodoInt() {
    	super(Type.INT);
    }

    public String toString(){return "INT";}
    
    public int size() {
    	return 4;
    }
    
	public String generateCode(){
		String code="";
		return code;
	}
}

