package ast;

import java.util.*;

public class NodoLista extends Lista { 

	String tipoLista = null;    //  Array o Struct      

    public NodoLista() {
    	super();
    }
    
    public NodoLista(int fila, int columna) {
    	super(fila, columna);
    }
   
    public NodoLista(Nodo ins) {
    	super(ins);
    }
    
    public NodoLista(Nodo ins, int fila, int columna) {
    	super(ins, fila, columna);
    }
    
    public NodoLista(ArrayList<Nodo> lista, int fila, int columna) {
    	super(lista, fila, columna);
    }
    
    public void setTipoLista(String tipo) {
    	this.tipoLista = tipo;
    }
    
    public String getTipoLista() {
    	return this.tipoLista;
    }
    
    public NodeKind nodeKind(){return NodeKind.LISTA;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    	if (this.tipoLista.equals("Array")) {return "LISTA("+l+")";}
    	else { return "STRUCT_VAL("+l+")";}
    }
    
    public ArrayList<Nodo> type() {
    	ArrayList<Nodo> aux = new ArrayList<Nodo>();
		for (int i = 0; i < lista.size(); i++) {
    			aux.addAll(lista.get(i).type());
    	}
		if(aux.isEmpty()) {
		
			if (this.tipoLista.equals("Array")) {
				for (int i = 1; i < lista.size(); i++) {
					if(!lista.get(0).getTipo().compare(lista.get(i).getTipo())){
						this.setError("Lista de elementos con tipos distintos: "+lista.get(0).getTipo().toString()+" y "+lista.get(i).getTipo().toString()+".");
						aux.add(this);
					}
				}
				if(aux.isEmpty()){
					if(lista.size()>0){
						this.tipo=new NodoArray(lista.get(0).getTipo(),lista.size());
					}else{
						this.tipo=new NodoArray(new NodoInt(),0);
					}
				}
			}
			else {
				ArrayList<Nodo> l = new ArrayList<Nodo>();
				for (int i = 0; i < this.lista.size(); i++) {
					Nodo act = this.lista.get(i);
					l.add(new NodoInicializacion(act.getTipo(), new NodoVariable("",act.getFila(), act.getColumna()), act, act.getFila(), act.getColumna())); 
				}
				if (l.size() > 0) {
					NodoDeclaracionStruct n = new NodoDeclaracionStruct("undefined", new NodoLista(l, l.get(0).getFila(), l.get(0).getColumna()));
					this.tipo = new NodoStruct("undefined", n); 
				}
				else {
					NodoDeclaracionStruct n = new NodoDeclaracionStruct("undefined", new NodoLista(l, -1, -1));
					this.tipo = new NodoStruct("undefined", n); 
				}
			}
		}
		return aux;
    }
    
    
}
