package ast;

import java.util.*;

public class NodoArgumento extends Nodo {

	private boolean amp;
	private NodoVariable iden;
    
    public NodoArgumento(NodoTipo tipo, NodoVariable iden, boolean amp) {
    	super(tipo);
    	this.iden = iden;
    	this.amp = amp;
    }
	
	public void setAmp(boolean amp) {
    	this.amp = amp;
	}
	
	public boolean getAmp() {
		return this.amp;
	}
	
	public void setIden(NodoVariable iden) {
    	this.iden = iden;
	}
	
	public NodoVariable getIden() {
		return this.iden;
	}
	public NodeKind nodeKind() { return NodeKind.ARGUMENTO; }
	
    public String toString() {
		if (amp) {
			return "ARGUM("+tipo.toString()+", REF, "+iden.toString()+")";
		} else {
			return "ARGUM("+tipo.toString()+","+iden.toString()+")";
		}
	}

	public ArrayList<Nodo> bind(Vinculador v) {
		v.insertaId(iden.getNombre(),this);
		return this.tipo.bind(v);
	}
	
	public ArrayList<Nodo> type(){
		return new ArrayList<Nodo>();
	}
	public String generateCode(){
		String code="";
		return code;
	}	
}
