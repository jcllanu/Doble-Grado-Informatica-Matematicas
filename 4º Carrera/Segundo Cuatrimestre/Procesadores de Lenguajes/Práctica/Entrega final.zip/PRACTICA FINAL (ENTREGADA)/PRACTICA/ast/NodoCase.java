package ast;

import java.util.*;

public class NodoCase extends Nodo {

	private Nodo expr;
	private Nodo bloc;
    
    public NodoCase() {
    	super();
    	this.expr = null;
    	this.bloc = null;
    }
    
    public NodoCase(Nodo expr, Nodo bloc, int fila, int columna) {
    	super(fila, columna);
    	this.expr = expr;
    	this.bloc = bloc;
    }
    
	public Nodo getExpr() {
		return this.expr;
	}
	
	public Nodo getBloc() {
		return this.bloc;
	}
	
	public void setExpr(Nodo expr) {
		this.expr = expr;
	}
	
	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public NodeKind nodeKind(){return NodeKind.CASE;}
    public String toString(){return "CASE("+expr.toString()+","+bloc.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux = expr.bind(v);
		v.abreBloque();
		aux.addAll(bloc.bind(v));
		v.cierraBloque();
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = expr.type();
		aux.addAll(bloc.type());
		return aux;
	}
	public String generateCode(){
		((NodoInstrucciones)bloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		return bloc.generateCode();
	}
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		expr.calcula_hueco_param(f);
		bloc.calcula_hueco_param(f);
	}
	public void maxMemory(Entero c, Entero max){
		Entero c1=new Entero(0);
		Entero max1=new Entero(0);
		bloc.maxMemory(c1,max1);
		if(c.getEntero()+max1.getEntero()>max.getEntero()){
			max.setEntero(c.getEntero()+max1.getEntero());
		}
	}
}
