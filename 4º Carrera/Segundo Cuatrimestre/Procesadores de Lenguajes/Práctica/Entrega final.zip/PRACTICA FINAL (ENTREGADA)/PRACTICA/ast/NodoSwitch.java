package ast;

import java.util.*;

public class NodoSwitch extends Lista {

    public NodoSwitch() {
    	super();
    }
    
    public NodoSwitch(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){return NodeKind.SWITCH;}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    return "SWITCH("+expr.toString()+","+l+")";
    }
    
    public ArrayList<Nodo> bind(Vinculador v) {
    	ArrayList<Nodo> aux = new ArrayList<Nodo>();
    	aux.addAll(expr.bind(v));
		for (int i = 0; i < lista.size(); i++) {
    			aux.addAll(lista.get(i).bind(v));
    	}
		return aux;
    }
    
    public ArrayList<Nodo> type() {
    	ArrayList<Nodo> aux = expr.type();
		boolean b=aux.isEmpty();
    	for(int i = 0; i < lista.size(); i++) {
    		aux.addAll(lista.get(i).type());
    		if (i != lista.size() - 1) {
    			if (b && !expr.getTipo().compare(((NodoCase)lista.get(i)).getExpr().getTipo())) {
					((NodoCase)lista.get(i)).getExpr().setError("Switch sobre expresión de tipo "+expr.getTipo().toString()+". Expresión de tipo "+((NodoCase)lista.get(i)).getExpr().getTipo().toString()+" no esperada en un case.");
    				aux.add(((NodoCase)lista.get(i)).getExpr());
    			}
    		}
    	}
    	return aux;
    }
	public int calcular_delta(int delta, NodoInstrucciones n){
		for(Nodo m: lista){
			m.calcular_delta(delta,n);
		}
		return 0;
	}
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		expr.calcula_hueco_param(f);
		for(Nodo m: lista){
			m.calcula_hueco_param(f);
		}
	}
	
	public String codeI(){
		int endspendientes=0;
		String code=";;Empieza el switch\n";
		for(int i = 0; i < this.lista.size(); i++) {
			if(lista.get(i).nodeKind()==NodeKind.CASE){
				NodoCase n = (NodoCase) lista.get(i);
				//Creamos un operador binario artifical de igualdad para generar el código de la evaluacion de la comparacion
				NodoOperacionBinaria aux =new NodoOperacionBinaria(expr, n.getExpr(), OperandoB.IGUAL, 0, 0);
				code+=aux.codeE();
				code+="if\n";
				code+=n.generateCode();
				code+="else\n";
				endspendientes++;
			}else{//DEFAULT
				code+=lista.get(i).generateCode();
			}
    	}
		for(int i=0; i<endspendientes;i++){
			code+="end\n";
		}
		code+=";;Termina el switch\n";
		return code;
	}
	public void maxMemory(Entero c, Entero max){
		for(Nodo m: lista){
			m.maxMemory(c,max);
		}
	}
}
