package ast;

import java.util.*;

public class NodoArgumentos extends Lista {

    public NodoArgumentos() {
    	super();
    }
    
    public NodoArgumentos(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){ return NodeKind.ARGUMENTOS;	}

    public String toString() {
    	String l = "";
    	if (lista.size() > 0) {
    		for (int i = 0; i < lista.size() - 1; i++) {
    			l=l+lista.get(i).toString()+",";
    		}
    		l=l+lista.get(lista.size()-1).toString();
    	}
    	return "ARGUMENTOS("+l+")";
    }
	public String generateCode(){
		String code="";
		return code;
	}
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		for(Nodo m: lista){
			m.calcula_hueco_param(f);
		}
	}
}
