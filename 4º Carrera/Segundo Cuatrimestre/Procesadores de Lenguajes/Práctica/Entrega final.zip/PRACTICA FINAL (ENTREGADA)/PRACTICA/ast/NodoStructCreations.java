package ast;

import java.util.*;

public class NodoStructCreations extends Lista {

    public NodoStructCreations() {
    	super();
    }
    
    public NodoStructCreations(Nodo ins) {
    	super(ins);
    }
    
    public NodeKind nodeKind(){return NodeKind.STRUCTCREATIONS;	}

    public String toString(){
    	String l="";
    	if (lista.size() > 0) {
    	for (int i = 0; i < lista.size() - 1; i++){
    		l=l+lista.get(i).toString()+",";
    	}
    	l=l+lista.get(lista.size()-1).toString();
    	}
    	return "STRUCTCREATIONS("+l+")";
    }
    
    public ArrayList<Nodo> bind(Vinculador v) {
    	ArrayList<Nodo> aux = new ArrayList<Nodo>();
		// Primero metemos los nombres de todas los structs declarados
		for (int i = 0; i < lista.size(); i++){
			NodoDeclaracionStruct n =(NodoDeclaracionStruct)lista.get(i);
			v.insertaId(n.getNombre(),n);
		}
		// Después vinculamos cada struct
		for (int i = 0; i < lista.size(); i++){
    		aux.addAll(lista.get(i).bind(v));
    	}
		return aux;
    }
    public String generateCode(){
		String code="";
		return code;
	}
	public int calcular_delta(int delta, NodoInstrucciones n){
		this.delta=0;
		for(Nodo m: lista){
			this.delta+=m.calcular_delta(this.delta,n);
		}
		return this.delta;
	}
}
