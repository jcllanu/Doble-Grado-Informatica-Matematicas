package ast;

public class NodoBool extends NodoTipo {

    public NodoBool() {
    	super(Type.BOOL);
    	
    }
    
    public int size() {
    	return 4;
    }
    
    public String toString(){return "BOOL";}
    
    	public String generateCode(){
		String code="";
		return code;
	}
}

