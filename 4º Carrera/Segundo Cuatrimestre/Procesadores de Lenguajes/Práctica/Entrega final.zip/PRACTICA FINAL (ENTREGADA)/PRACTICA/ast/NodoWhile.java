package ast;

import java.util.*;

public class NodoWhile extends Nodo {

	private Nodo cond;
	private Nodo bloc;
    
    public NodoWhile() {
    	super();
    	this.cond = null;
    	this.bloc = null;
    }
    
    public NodoWhile(Nodo cond, Nodo bloc, int fila, int columna) {
    	super(fila, columna);
    	this.cond = cond;
    	this.bloc = bloc;
    }
    
	public Nodo getCond() {
		return this.cond;
	}
	
	public Nodo getBloc() {
		return this.bloc;
	}
	
	public void setCond(Nodo cond) {
		this.cond = cond;
	}
	
	public void setBloc(Nodo bloc) {
		this.bloc = bloc;
	}

	public NodeKind nodeKind(){return NodeKind.WHILE;}
    public String toString(){return "WHILE("+cond.toString()+","+bloc.toString()+")";}

	public ArrayList<Nodo> bind(Vinculador v){
		ArrayList<Nodo> aux= cond.bind(v);
		v.abreBloque();
		aux.addAll(bloc.bind(v));
		v.cierraBloque();
		return aux;
	}
	
	public ArrayList<Nodo> type() {
		ArrayList<Nodo> aux = cond.type();
		if(aux.isEmpty() && cond.getTipo().getType() != Type.BOOL) {
			cond.setError("La condición de un while debe ser de tipo BOOL. No se esperaba una expresión con tipo "+cond.getTipo()+".");
			aux.add(cond);

		}
		aux.addAll(bloc.type());
		return aux;
	}
	public String codeI(){
		((NodoInstrucciones)bloc).setInicioMemoriaBloque(miBloque.getInicioMemoriaBloque()+miBloque.getDelta());
		String code=";;Empieza el while\nblock\nloop\n";
		code+=cond.codeE();
		code+="i32.eqz\nbr_if 1\n";
		code+=bloc.generateCode();
		code+="br 0\nend\nend\n;;Termina el while\n";
		return code;
	}
	
	public void calcula_hueco_param(NodoFuncion f) {
		this.miFuncion = f;
		bloc.calcula_hueco_param(f);
	}
	
	public void maxMemory(Entero c, Entero max){
		Entero c1=new Entero(0);
		Entero max1=new Entero(0);
		bloc.maxMemory(c1,max1);
		if(c.getEntero()+max1.getEntero()>max.getEntero()){
			max.setEntero(c.getEntero()+max1.getEntero());
		}
	}
}
