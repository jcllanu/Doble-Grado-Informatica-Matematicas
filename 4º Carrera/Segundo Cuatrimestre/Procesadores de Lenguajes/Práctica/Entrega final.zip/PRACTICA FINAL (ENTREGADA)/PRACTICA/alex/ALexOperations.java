package alex;

import constructorast.ClaseLexica;

public class ALexOperations {
  private AnalizadorLexicoExp alex;
  public ALexOperations(AnalizadorLexicoExp alex) {
   this.alex = alex;   
  }
  
  
  public UnidadLexica unidadEnt() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ENT,
                                         alex.lexema()); 
  } 

  public UnidadLexica unidadIdentificador() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.IDEN,
                                         alex.lexema()); 
  } 
  
  
  
  public UnidadLexica unidadRead() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.READ); 
  } 
  
  public UnidadLexica unidadPrint() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PRINT); 
  } 
  
  public UnidadLexica unidadIf() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.IF); 
  } 
  
  public UnidadLexica unidadElse() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ELSE); 
  } 
  
  public UnidadLexica unidadElif() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ELIF); 
  } 
  
  public UnidadLexica unidadSwitch() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.SWITCH); 
  } 
  
  public UnidadLexica unidadCase() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.CASE); 
  } 
  
  public UnidadLexica unidadDefault() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.DEFAULT); 
  } 
  
  public UnidadLexica unidadWhile() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.WHILE); 
  } 

  public UnidadLexica unidadReturn() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.RETURN); 
  } 
  
  public UnidadLexica unidadVoid() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.VOID); 
  } 

  public UnidadLexica unidadBool() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.BOOL); 
  } 
  
  public UnidadLexica unidadInt() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.INT); 
  } 
  
  public UnidadLexica unidadTrue() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.TRUE); 
  } 
  
  public UnidadLexica unidadFalse() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.FALSE); 
  } 
  
  public UnidadLexica unidadArray() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ARRAY); 
  } 
  
  public UnidadLexica unidadStruct() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.STRUCT); 
  } 
  
  public UnidadLexica unidadDef() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.DEF); 
  } 
  
  public UnidadLexica unidadIgualdad() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.IGUAL); 
  } 
  
  public UnidadLexica unidadDesigualdad() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.DESIGUAL); 
  } 
  
  public UnidadLexica unidadAnd() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.AND); 
  } 
  
  public UnidadLexica unidadOr() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.OR); 
  } 
  
  public UnidadLexica unidadMenorIgual() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MENORIGUAL); 
  } 
  
  public UnidadLexica unidadMayorIgual() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MAYORIGUAL); 
  } 
  
  public UnidadLexica unidadNot() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.NOT); 
  } 
  
  public UnidadLexica unidadMenor() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MENOR); 
  } 
  
  public UnidadLexica unidadMayor() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MAYOR); 
  } 
  
  public UnidadLexica unidadCorcheteIzq() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.CAP); 
  } 
  
  public UnidadLexica unidadCorcheteDer() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.CC); 
  } 
  
  public UnidadLexica unidadComa() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.COMA); 
  } 
  
  public UnidadLexica unidadPunto() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PUNTO); 
  } 
  
  public UnidadLexica unidadAsignacion() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.ASIG); 
  } 
  
  public UnidadLexica unidadLlaveAp() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.LLAVEAP); 
  } 
  
  public UnidadLexica unidadLlaveCer() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.LLAVECIERRE); 
  } 
  
  public UnidadLexica unidadParentesisAp() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PAP); 
  } 
  
  public UnidadLexica unidadParentesisCerr() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PCIERRE); 
  } 
  
  public UnidadLexica unidadDireccion() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.AMP); 
  } 
  
  public UnidadLexica unidadAsterisco() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.POR); 
  } 
  
  public UnidadLexica unidadSuma() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MAS); 
  } 
  
  public UnidadLexica unidadResta() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MENOS); 
  } 
  
  public UnidadLexica unidadDivision() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.DIV); 
  } 
  
  public UnidadLexica unidadMod() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.MOD); 
  } 
  
  public UnidadLexica unidadPot() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.POT); 
  } 
  
  public UnidadLexica unidadPtoComa() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.PTOCOMA); 
  } 
  
  public UnidadLexica unidadEof() {
     return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.EOF); 
  }
  
}
