package ast;

public enum KindE {
  SUMA,MUL,NUM   
}
