package ast;

public class EBin extends E {
   private E opnd1;
   private E opnd2;
   private String op;
   
   public EBin(String op, E opnd1, E opnd2) {
     this.opnd1 = opnd1;
     this.opnd2 = opnd2;
     this.op=op;
   }
   public E opnd1() {return opnd1;}
   public E opnd2() {return opnd2;}  
   public String op() {return op;}
   
   public KindE kind() {
   	if (op.equals("mul")){
   		return KindE.MUL;
   	}else{
   		return KindE.SUMA;
   	}
   }
   public String toString() {
	if (op.equals("mul")){
		return "mul("+opnd1().toString()+","+opnd2().toString()+")";
	}else{
		return "sum("+opnd1().toString()+","+opnd2().toString()+")";
	}
   }	
}
