package alex;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;

public class Main {
   public static void main(String[] args) throws FileNotFoundException, IOException {
     Reader input = new InputStreamReader(new FileInputStream(args[0]));
     AnalizadorLexicoTiny al = new AnalizadorLexicoTiny(input);
     UnidadLexica unidad;
     List<String> palabras=new ArrayList<String>();
     List<String> patrones=new ArrayList<String>();
     do {
       unidad = al.yylex();
       System.out.println(unidad);
       if(unidad.sym==2){
       		palabras.add(unidad.lexema());
       }else if(unidad.sym==3){
       		patrones.add(unidad.lexema());
       }
     }
     while (unidad.clase() != ClaseLexica.EOF);
     
     System.out.println("\nPALABRAS:");
     for(int i=0; i<palabras.size();i++){
     	System.out.println(palabras.get(i));
     }
     System.out.println("\nPATRONES:");
     for(int i=0; i<patrones.size();i++){
     	int n=0;
     	for(int j=0; j<palabras.size();j++){
     		if(espatron(patrones.get(i),palabras.get(j))){
     			n++;
     		}
     	}
     	System.out.println(patrones.get(i)+": "+n);
     }
     
    }
    public static Boolean espatron(String patron, String palabra){
    	if(palabra.length()<patron.length()){
    		return false;
    	}
    	
    	int posast=patron.indexOf("*");
    	if(!palabra.substring(0,posast).equals(patron.substring(0,posast))){
    		return false;
    	}
    	
    	int l=patron.length()-posast-1;
    	if(!patron.substring(posast+1,patron.length()).equals(palabra.substring(palabra.length()-l,palabra.length()))){
    		return false;
    	}
    	return true;
    }       
} 
