package alex;

public class ClaseLexica {
  public static final int EOF = 0;
  public static final int PALABRA = 2;
  public static final int PATRON = 3;
  public static final int OTRO = 4;
}
