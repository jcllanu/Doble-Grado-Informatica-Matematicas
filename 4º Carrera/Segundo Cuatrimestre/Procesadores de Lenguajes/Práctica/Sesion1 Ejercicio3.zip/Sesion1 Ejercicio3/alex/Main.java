package alex;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;

public class Main {
   public static void main(String[] args) throws FileNotFoundException, IOException {
     Reader input = new InputStreamReader(new FileInputStream(args[0]));
     AnalizadorLexicoTiny al = new AnalizadorLexicoTiny(input);
     UnidadLexica unidad;
     List<String> palabra = new ArrayList<String>();
     List<String> patron = new ArrayList<String>();
     do {
       unidad = al.yylex();
       if (unidad.clase() == 2)
          palabra.add(unidad.lexema());
       if (unidad.clase() == 3)
       	  patron.add(unidad.lexema());
       System.out.println(unidad);
     }
     while (unidad.clase() != ClaseLexica.EOF);
     System.out.println("PALABRAS:");
     for(String p : palabra)
        System.out.println(p);
     System.out.println("PATRONES:");
     for(String p : patron) {
     	int num = 0;
     	for(String a : palabra) { if (coincide(a,p)) num++; }
        System.out.println(p + ": " + num);
     }
  }
  static boolean coincide(String a, String p) {
     int i = 0, j = a.length() - 1, k = p.length() - 1;
     boolean ok = true;
     while((p.charAt(i) != '*') && (i < a.length())) { if (a.charAt(i) != p.charAt(i)) ok = false; i++;}
     while((p.charAt(k) != '*') && (j >= i)) { if (a.charAt(j) != p.charAt(k)) ok = false; j--; k--;}
     if (p.charAt(k) != '*') {ok = false;}
     return ok;
  }
} 
