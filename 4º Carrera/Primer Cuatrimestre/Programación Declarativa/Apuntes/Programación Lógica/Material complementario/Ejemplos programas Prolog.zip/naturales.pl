nat(c).
nat(s(X)) :- nat(X).

sum(X,c,X) :- nat(X).
sum(X,s(Y),s(Z)) :- sum(X,Y,Z).

prod(X,c,c) :- nat(X).
prod(X,s(Y),Z) :- prod(X,Y,Z1), sum(X,Z1,Z).

pot(s(X),c,s(c)) :- nat(X).
pot(s(X),s(N),Y) :- pot(s(X),N,Z), prod(s(X),Z,Y).

fact(c,s(c)).
fact(s(X),Y) :- nat(X), fact(X,Z), prod(s(X),Z,Y).


fib(c,s(c)).
fib(s(c),s(c)).
fib(s(s(X)),Y) :- fib(s(X),Z1), fib(X,Z2), sum(Z1,Z2,Y).

prodf(X,Y,Z) :- prod(X,Y,c,Z).
prod(c,Y,Ac,Ac).
prod(s(X),Y,Ac,Z) :- sum(Ac,Y,NAc), prod(X,Y,NAc,Z).

potf(s(X),Y,Z) :- pot(s(X),Y,s(c),Z).
pot(s(X),c,Ac,Ac).
pot(s(X),s(N),Ac,Z) :- prod(s(X),Ac,NAc), pot(s(X),N,NAc,Z).

factf(X,Y) :- fact(X,s(c),Y).
fact(c,Ac,Ac).
fact(s(X),Ac,Y) :- prod(s(X),Ac,NAc), fact(X,NAc,Y).

fibf(X,Y) :- fib(X,c,s(c),Y).
fib(c,Ac1,Ac2,Ac2).
fib(s(X),Ac1,Ac2,Y) :- sum(Ac1,Ac2,Ac3), fib(X,Ac2,Ac3,Y).



pol_fib(c,X,s(c)) :- nat(X).
pol_fib(s(N),X,M) :- pol_fib(N,X,M1), fib(s(N),M2), pot(X,s(N),M3),
prod(M2,M3,M4), sum(M1,M4,M).


pol_fibf(c,X,s(c)) :- nat(X).
pol_fibf(s(N),X,M) :- pol_fib(s(N),X,s(c),s(c),c,s(c),M).
pol_fib(c,X,Act,Acupot,Acu1,Acu2,Act). pol_fib(s(N),X,Act,Acupot,Acu1,Acu2,P) :- sum(Acu1,Acu2,Acu3),
prod(Acupot,X,Acupot1), prod(Acu3,Acupot1,Acu4), sum(Act,Acu4,NAct), pol_fib(N,X,NAct,Acupot1,Acu2,Acu3,P).

pol_fib(c,X,s(c)) :- nat(X).
pol_fib(s(N),X,M) :- pol_fib(N,X,M1), fib(s(N),M2), pot(X,s(N),M3),
prod(M2,M3,M4), sum(M1,M4,M).

