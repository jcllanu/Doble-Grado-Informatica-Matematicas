 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
 #include <unistd.h>

 int main(int argc, char* argv[]){
    int fd = open("/dev/leds",O_RDWR);
    int n=0;
    while(1){
        if(n%2==0){
            write(fd,"1",1);
        }else{
            write(fd,"2",1);
        }
        sleep(1);
        n++;
    }
 }
