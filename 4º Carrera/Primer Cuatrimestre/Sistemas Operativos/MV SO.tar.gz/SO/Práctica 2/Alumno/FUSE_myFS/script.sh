#!/bin/bash

MPOINT="./mount-point"

#a
rm -R -f temporal
mkdir temporal

#"Copying fuseLib.c"
cp ./src/fuseLib.c ./mount-point/
cp ./src/fuseLib.c ./temporal

#"Copying myFS.h"
cp ./src/myFS.h ./mount-point/
cp ./src/myFS.h ./temporal


#b
./my-fsck-static-64 virtual-disk

echo "(Tienen que ser iguales)"
diff ./mount-point/fuseLib.c ./src/fuseLib.c -q -s
diff ./mount-point/myFS.h ./src/myFS.h -q -s
echo " "
truncate ./temporal/fuseLib.c -o -s -1
truncate ./mount-point/fuseLib.c -o -s -1

#c
./my-fsck-static-64 virtual-disk
echo "Se ve que fuseLib.c tiene 4096 Bytes menos <=> 1 bloque menos"
echo " "
echo "(Tienen que ser distintos)"
diff ./mount-point/fuseLib.c ./src/fuseLib.c -s -q
echo " "
#d
#"Creating file 3"
echo 'This is file 3' > ./file3.txt
cp ./file3.txt ./mount-point/

#e
./my-fsck-static-64 virtual-disk
echo " "
echo "(Tienen que ser iguales)"
diff ./file3.txt ./mount-point/file3.txt -q -s
echo " "
#f
truncate ./temporal/myFS.h -o -s +1
truncate ./mount-point/myFS.h -o -s +1

#g
./my-fsck-static-64 virtual-disk

echo "Se ve que myFS.h tiene 4096 Bytes más <=> 1 bloque más"
echo " "
echo "(Tienen que ser distintos)"
diff ./mount-point/myFS.h ./src/myFS.h -s -q

