#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>



int main() {
	pid_t pid;
	int a=0;
	int status;
	
	pid=fork();
	if(pid==0){
		a++;
	}else if(pid>0){
		wait(&status);
		a=a+2;
	}else{
		fprintf(stderr,"Cant fork\n");
		exit(1);
	}
	
	printf("My PID is %d, a=%d\n",getpid(),a);
	exit(0);
}
