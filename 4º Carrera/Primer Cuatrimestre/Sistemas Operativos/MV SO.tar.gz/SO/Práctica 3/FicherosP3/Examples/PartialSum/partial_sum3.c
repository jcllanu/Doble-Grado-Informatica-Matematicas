#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
int total_sum = 0;
sem_t semaforo;

void * partial_sum(void * arg) {
  int j = 0;
  int ni=((int*)arg)[0];
  int nf=((int*)arg)[1];
  for (j = ni; j <= nf; j++){
    sem_wait(&semaforo);
    //printf("Hilo [%d,%d]. Antes de entrar: %d\n",ni,nf,total_sum);
    total_sum = total_sum + j;
    //printf("Hilo [%d,%d]. Después de sumar %d: %d\n",ni,nf,j,total_sum);
    sem_post(&semaforo);
  }
  //printf("Hilo [%d,%d] terminado\n",ni,nf);
  pthread_exit(0);
}
void * partial_sum_bis(void * arg) {
  int j = 0;
  int ni=((int*)arg)[0];
  int nf=((int*)arg)[1];
  int sum_local=0;
  for (j = ni; j <= nf; j++){
    sum_local = sum_local + j;
  }
  sem_wait(&semaforo);
  //printf("Hilo [%d,%d]. Antes de entrar: %d\n",ni,nf,total_sum);
  total_sum = total_sum + sum_local;
  //printf("Hilo [%d,%d]. Después de sumar %d: %d\n",ni,nf,sum_local,total_sum);
  sem_post(&semaforo);
  //printf("Hilo [%d,%d] terminado\n",ni,nf);
  pthread_exit(0);
}

int main(int argc, char* argv[]) {

    if (argc!=3) {
		fprintf(stderr,"Usage: <num_threads> <to_n>\n");
		exit(1);
    }

    int num_threads = atoi(argv[1]);
    int to_n = atoi(argv[2]);
    int num_per_thread=to_n/num_threads;

    pthread_t* array_threads=malloc(num_threads*sizeof(pthread_t));
    int **array=malloc(num_threads*sizeof(int *));

    sem_init(&semaforo,0,1);
    
    for (int i =0; i<num_threads; i++){
      array[i]=malloc(2*sizeof(int));
      array[i][0]=1+i*num_per_thread;
      if(i==num_threads-1)
        array[i][1]=to_n;
      else
        array[i][1]=(i+1)*num_per_thread;
    }

    for(int i=0; i<num_threads;i++){
      //printf("Hilo [%d,%d] lanzado\n",array[i][0],array[i][1]);
      pthread_create(&array_threads[i], NULL, partial_sum_bis, (void*)array[i]);
    }
    for(int i=0; i<num_threads;i++){
      pthread_join(array_threads[i],NULL);
    }

    //FREES
    for (int i =0; i<num_threads; i++){
      free(array[i]);
    }
    free(array_threads);
    free(array);

    int suma=0;
    for (int i=1; i<=to_n; i++){
        suma+=i;
    }
    printf("total_sum=%d and it should be %d\n", total_sum,suma);

    return 0;
}
