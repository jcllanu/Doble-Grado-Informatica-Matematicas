#include <stdio.h> 
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>

#define NR_PHILOSOPHERS 5
pthread_t philosophers[NR_PHILOSOPHERS]; // hilos de cada uno de los filósofos
pthread_mutex_t forks[NR_PHILOSOPHERS]; // mutex asociado a la variable forks_in_use, cuyos accesos componen la sección crítica
pthread_cond_t b_philosophers[NR_PHILOSOPHERS]; // Variables de condición para bloquera a los filósofos
int forks_in_use[NR_PHILOSOPHERS];//0 libre y 1 en uso

//TODOS COGEN PRIMERO EL TENEDOR DE LA DERECHA, SALVO EL ÚLTIMO QUE COGE PRIMERO EL TENEDOR DE LA IZQUIERDA
void init()
{
    int i;
    for(i=0; i<NR_PHILOSOPHERS; i++)
        pthread_mutex_init(&forks[i],NULL);
}

void think(int i) {
    printf("Philosopher %d thinking... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d stopped thinking!!! \n" , i);

}

void eat(int i) {
    printf("Philosopher %d eating... \n" , i);
    sleep(random() % 5);
    printf("Philosopher %d is not eating anymore!!! \n" , i);

}

void toSleep(int i) {
    printf("Philosopher %d sleeping... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d is awake!!! \n" , i);
    
}

void* philosopher(void* i)
{
    int nPhilosopher = (int)i;
    int fork_right = nPhilosopher;
    int fork_left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    int philosopher_right = (nPhilosopher + 1 == NR_PHILOSOPHERS)? 0: nPhilosopher + 1;
    int philosopher_left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    while(1)
    {
        
        think(nPhilosopher);
        
        /// TRY TO GRAB BOTH FORKS (right and left)

        if(nPhilosopher!=NR_PHILOSOPHERS-1){//Todos los filósofos menos el último intentan coger el tendor de la derecha

            pthread_mutex_lock(&forks[fork_right]);
            while(forks_in_use[fork_right]==1){
                //printf("Philosopher %d se bloquea \n" , nPhilosopher);
                pthread_cond_wait(&b_philosophers[nPhilosopher],&forks[fork_right]);
                //printf("Philosopher %d le desbloquean \n" , nPhilosopher);
            }
            //printf("Philosopher %d coge el tenedor %d \n" , nPhilosopher,fork_right);
            forks_in_use[fork_right]=1;
            pthread_cond_broadcast(&b_philosophers[philosopher_right]);
            pthread_mutex_unlock(&forks[fork_right]);

            //Y cuando ya lo tienen intentan coger el tenedor de la izquierda
            pthread_mutex_lock(&forks[fork_left]);
            while(forks_in_use[fork_left]==1){
                //printf("Philosopher %d se bloquea \n" , nPhilosopher);
                pthread_cond_wait(&b_philosophers[nPhilosopher],&forks[fork_left]);
                //printf("Philosopher %d le desbloquean \n" , nPhilosopher);
            }
            forks_in_use[fork_left]=1;
            //printf("Philosopher %d coge el tenedor %d \n" , nPhilosopher,fork_left);
            pthread_cond_broadcast(&b_philosophers[philosopher_left]);
            pthread_mutex_unlock(&forks[fork_left]);

        }else{//El último filósofo intenta coger primero el tenedor de la izquierda

            pthread_mutex_lock(&forks[fork_left]);
            while(forks_in_use[fork_left]==1){
                //printf("Philosopher %d se bloquea \n" , nPhilosopher);
                pthread_cond_wait(&b_philosophers[nPhilosopher],&forks[fork_left]);
                //printf("Philosopher %d le desbloquean \n" , nPhilosopher);
            }
            forks_in_use[fork_left]=1;
            //printf("Philosopher %d coge el tenedor %d \n" , nPhilosopher,fork_left);
            pthread_cond_broadcast(&b_philosophers[philosopher_left]);
            pthread_mutex_unlock(&forks[fork_left]);

            //Y cuando ya lo tienen intentan coger el tenedor de la derecha
            pthread_mutex_lock(&forks[fork_right]);
            while(forks_in_use[fork_right]==1){
                //printf("Philosopher %d se bloquea \n" , nPhilosopher);
                pthread_cond_wait(&b_philosophers[nPhilosopher],&forks[fork_right]);
                //printf("Philosopher %d le desbloquean \n" , nPhilosopher);
            }
            //printf("Philosopher %d coge el tenedor %d \n" , nPhilosopher,fork_right);
            forks_in_use[fork_right]=1;
            pthread_cond_broadcast(&b_philosophers[philosopher_right]);
            pthread_mutex_unlock(&forks[fork_right]);
        }

        eat(nPhilosopher); 

        // PUT FORKS BACK ON THE TABLE

        //Deja el tenedor de la izquierda
        pthread_mutex_lock(&forks[fork_left]);
        forks_in_use[fork_left]=0;
        //printf("Philosopher %d suelta el tenedor %d \n" , nPhilosopher,fork_left);
        pthread_cond_broadcast(&b_philosophers[philosopher_left]);
        pthread_mutex_unlock(&forks[fork_left]);

        //Deja el tenedor de la derecha
        pthread_mutex_lock(&forks[fork_right]);
        //printf("Philosopher %d suelta el tenedor %d \n" , nPhilosopher,fork_right);
        forks_in_use[fork_right]=0;
        pthread_cond_broadcast(&b_philosophers[philosopher_right]);
        pthread_mutex_unlock(&forks[fork_right]);

        toSleep(nPhilosopher);   
   }

}

int main()
{
    init();//inicializa los mutex
    unsigned long i;
    for(i=0; i<NR_PHILOSOPHERS; i++){
        pthread_create(&philosophers[i], NULL, philosopher, (void*)i); //Crear un hilo por cada filósofo
        pthread_cond_init(&b_philosophers[i],NULL); //Inicializar las variables condicionales
        forks_in_use[i]=0; //Inicializamos el array de tenedores en uso (todos están libres al comienzo)
    }

    for(i=0; i<NR_PHILOSOPHERS; i++)
        pthread_join(philosophers[i],NULL);

    
    return 0;
} 
