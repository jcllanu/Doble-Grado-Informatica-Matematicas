#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int my_system(const char* command){
	pid_t child_pid;
	int stat;
	child_pid = fork ();
	if (child_pid == 0) {
		// HIJO
		stat=execl("/bin/sh","sh","-c",command,(char *) NULL);
	} else if(child_pid > 0){
		// PADRE
		
	}else {
		fprintf(stderr, "ERROR haciendo fork");
		exit(-1);
	}
	if (wait(&stat) == -1) {

	}
	return stat;
}

int main(int argc, char* argv[])
{
	if (argc!=2){
		fprintf(stderr, "Usage: %s <command>\n", argv[0]);
		exit(1);
	}

	//return system(argv[1]);
	return my_system(argv[1]);
}

