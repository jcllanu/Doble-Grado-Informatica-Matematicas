#include <stdio.h> 
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>

#define NR_PHILOSOPHERS 5
pthread_t philosophers[NR_PHILOSOPHERS]; // hilos de cada uno de los filósofos
pthread_mutex_t forks[NR_PHILOSOPHERS]; // mutex asociado a la variable forks_in_use, cuyos accesos componen la sección crítica
pthread_cond_t b_philosophers[NR_PHILOSOPHERS]; // Variables de conción para bloquera a los filósofos
int forks_in_use[NR_PHILOSOPHERS];//0 libre y 1 en uso
pthread_mutex_t mutex_aux;
void init()
{
    int i;
    for(i=0; i<NR_PHILOSOPHERS; i++)
        pthread_mutex_init(&forks[i],NULL);
    pthread_mutex_init(&mutex_aux,NULL);
}

void think(int i) {
    printf("Philosopher %d thinking... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d stopped thinking!!! \n" , i);

}

void eat(int i) {
    printf("Philosopher %d eating... \n" , i);
    sleep(random() % 5);
    printf("Philosopher %d is not eating anymore!!! \n" , i);

}

void toSleep(int i) {
    printf("Philosopher %d sleeping... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d is awake!!! \n" , i);
    
}

void* philosopher(void* i)
{
    int nPhilosopher = (int)i;
    int fork_right = nPhilosopher;
    int fork_left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    int philosopher_right = (nPhilosopher + 1 == NR_PHILOSOPHERS)? 0: nPhilosopher + 1;
    int philosopher_left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    while(1)
    {
        think(nPhilosopher);
        
        /// TRY TO GRAB BOTH FORKS (right and left)
        //Usamos un mutex auxiliar para garantizar que cogemos los dos mutex asociados a los tenedores a la vez y 
        //no se da la situación de que todos los hilos cojan el mutex de su tenedor de la izquierda lo que produciría un interbloqueo
        pthread_mutex_lock(&mutex_aux);

        pthread_mutex_lock(&forks[fork_left]);
        pthread_mutex_lock(&forks[fork_right]);

        pthread_mutex_unlock(&mutex_aux);

        while(forks_in_use[fork_left] ==1 || forks_in_use[fork_right]==1){//Comprobamos si podemos coger los dos tenedores a la vez
            //printf("Hilo %d bloqueado\n",nPhilosopher);
            //Liberamos los mutex de los tenedores 
            pthread_mutex_unlock(&forks[fork_right]);
            pthread_mutex_unlock(&forks[fork_left]);
            //Esperamos con el mutex_aux
            pthread_mutex_lock(&mutex_aux);
            pthread_cond_wait(&b_philosophers[nPhilosopher],&mutex_aux);
            //printf("Hilo %d desbloqueado\n",nPhilosopher);
            //Cuando terminamos de esperar tenemos el mutex_aux y podemos coger los mutex de los tenedores
            pthread_mutex_lock(&forks[fork_left]);
            pthread_mutex_lock(&forks[fork_right]);
            //
            pthread_mutex_unlock(&mutex_aux);
        }
        //Los dos tenedores están libres
        forks_in_use[fork_left]=1;
        forks_in_use[fork_right]=1;
        
        pthread_cond_broadcast(&b_philosophers[philosopher_left]);
        pthread_cond_broadcast(&b_philosophers[philosopher_right]);

        pthread_mutex_unlock(&forks[fork_left]);
        pthread_mutex_unlock(&forks[fork_right]);

        eat(nPhilosopher); 

        pthread_mutex_lock(&mutex_aux);

        pthread_mutex_lock(&forks[fork_left]);
        pthread_mutex_lock(&forks[fork_right]);

        pthread_mutex_unlock(&mutex_aux);

        forks_in_use[fork_left]=0;
        forks_in_use[fork_right]=0;

        pthread_cond_broadcast(&b_philosophers[philosopher_left]);
        pthread_cond_broadcast(&b_philosophers[philosopher_right]);

        // PUT FORKS BACK ON THE TABLE
        pthread_mutex_unlock(&forks[fork_left]);
        pthread_mutex_unlock(&forks[fork_right]);

        toSleep(nPhilosopher);
   }

}

int main()
{
    init();//inicializa los mutex
    unsigned long i;
    for(i=0; i<NR_PHILOSOPHERS; i++){
        pthread_create(&philosophers[i], NULL, philosopher, (void*)i); //Crear un hilo por cada filósofo
        pthread_cond_init(&b_philosophers[i],NULL); //Inicializar las variables condicionales
        forks_in_use[i]=0; //Inicializamos el array de tenedores en uso (todos están libres al comienzo)
    }

    for(i=0; i<NR_PHILOSOPHERS; i++)
        pthread_join(philosophers[i],NULL);

    
    return 0;
} 
