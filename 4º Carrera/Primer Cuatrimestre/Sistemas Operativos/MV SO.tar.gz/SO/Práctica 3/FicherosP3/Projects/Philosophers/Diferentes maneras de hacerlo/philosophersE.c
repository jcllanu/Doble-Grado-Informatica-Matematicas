#include <stdio.h> 
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

#define NR_PHILOSOPHERS 5

// Filósofos
pthread_t philosophers[NR_PHILOSOPHERS];
// Variables condicionales de cada filósofo
pthread_cond_t b_philosophers[NR_PHILOSOPHERS];
// Mutex de la mesa
pthread_mutex_t mutex;
// Estado de los filósofos 
int estado[NR_PHILOSOPHERS];        
// Estados posibles de los filósofos:
// 0 Está pensando
// 1 Ha parado de pensar y está esperando para comer
// 2 Está comiendo

void init() {
    pthread_mutex_init(&mutex,NULL);
}

void think(int i) {
    printf("Philosopher %d thinking... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d stopped thinking!!! \n" , i);
}

void eat(int i) {
    printf("Philosopher %d eating... \n" , i);
    sleep(random() % 5);
    printf("Philosopher %d is not eating anymore!!! \n" , i);
}

void toSleep(int i) {
    printf("Philosopher %d sleeping... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d is awake!!! \n" , i);
}

void* philosopher(void* i) {

    int nPhilosopher = (int)i;
    int right = (nPhilosopher + 1 == NR_PHILOSOPHERS) ? 0 : (nPhilosopher + 1);
    int left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    int right2 = (right + 1 == NR_PHILOSOPHERS) ? 0 : (right + 1);
    int left2 = (left - 1 == -1) ? NR_PHILOSOPHERS - 1 : (left - 1);
    
    while(1) {
    
        // PIENSA
        
        think(nPhilosopher);
        
        // El filósofo nPhilosopher ha parado de pensar y quiere comer (Estado 1)
        
        pthread_mutex_lock(&mutex);
        
        estado[nPhilosopher] = 1;
        
        // Si los filósofos de los lados no están comiendo y nPhilosopher quiere comer, lo dice
        
        if ((estado[left] != 2) && (estado[nPhilosopher] == 1) && (estado[right] != 2)) {
        	estado[nPhilosopher] = 2;
        	pthread_cond_signal(&b_philosophers[nPhilosopher]);
        }
        
        // Espera a que los filósofos de los lados le avisen de que puede comer

        while(estado[nPhilosopher] != 2)
            pthread_cond_wait(&b_philosophers[nPhilosopher],&mutex);
        
        pthread_mutex_unlock(&mutex);
        
        // COME (Estado 2)

        eat(nPhilosopher);
        
        // El filósofo nPhilosopher ha terminado de comer (Estado 0)

        pthread_mutex_lock(&mutex);
        
        estado[nPhilosopher] = 0;
        
        // Si alguno de los filósofos de los lados quiere y puede comer, se lo avisa
        
        if ((estado[left2] != 2) && (estado[left] == 1) && (estado[nPhilosopher] != 2)) {
        	estado[left] = 2;
        	pthread_cond_signal(&b_philosophers[left]);
        }
        
        if ((estado[nPhilosopher] != 2) && (estado[right] == 1) && (estado[right2] != 2)) {
        	estado[right] = 2;
        	pthread_cond_signal(&b_philosophers[right]);
        }
        
        pthread_mutex_unlock(&mutex);
        
        // DUERME
        
        toSleep(nPhilosopher);
        
   }

}

int main() {

    init();
    
    unsigned long i;
    for(i=0; i<NR_PHILOSOPHERS; i++){
        pthread_create(&philosophers[i], NULL, philosopher, (void*)i);
        pthread_cond_init(&b_philosophers[i],NULL);
        estado[i]=0;
    }

    for(i=0; i<NR_PHILOSOPHERS; i++)
        pthread_join(philosophers[i],NULL);

    return 0;
   
} 
