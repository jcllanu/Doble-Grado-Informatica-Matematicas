#include <stdio.h> 
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>

#define NR_PHILOSOPHERS 5
pthread_t philosophers[NR_PHILOSOPHERS]; // hilos de cada uno de los filósofos
pthread_cond_t b_philosophers; // Variable de condición para bloquera a los filósofos
int forks_in_use[NR_PHILOSOPHERS];//0 libre y 1 en uso
pthread_mutex_t mesa;

//INTENTAMOS COGER LOS DOS TENEDORES CADA VEZ QUE TENGAMOS HAMBRE. SOLO UN FILÓSOFO TIENE ACCESO SIMULTANEO A LA MESA

void init()
{
    pthread_mutex_init(&mesa,NULL);
}

void think(int i) {
    printf("Philosopher %d thinking... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d stopped thinking!!! \n" , i);

}

void eat(int i) {
    printf("Philosopher %d eating... \n" , i);
    sleep(random() % 5);
    printf("Philosopher %d is not eating anymore!!! \n" , i);

}

void toSleep(int i) {
    printf("Philosopher %d sleeping... \n" , i);
    sleep(random() % 10);
    printf("Philosopher %d is awake!!! \n" , i);
    
}

void* philosopher(void* i)
{
    int nPhilosopher = (int)i;
    int fork_right = nPhilosopher;
    int fork_left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    //int philosopher_right = (nPhilosopher + 1 == NR_PHILOSOPHERS)? 0: nPhilosopher + 1;
    //int philosopher_left = (nPhilosopher - 1 == -1) ? NR_PHILOSOPHERS - 1 : (nPhilosopher - 1);
    while(1)
    {
        
        think(nPhilosopher);
        
        /// TRY TO GRAB BOTH FORKS (right and left)
        pthread_mutex_lock(&mesa);
        while(forks_in_use[fork_left] ==1 || forks_in_use[fork_right]==1){
            pthread_cond_wait(&b_philosophers,&mesa); 
        }
        forks_in_use[fork_left]=1;
        forks_in_use[fork_right]=1;
        
        pthread_cond_broadcast(&b_philosophers);
        pthread_mutex_unlock(&mesa);

        eat(nPhilosopher); 

        // PUT FORKS BACK ON THE TABLE
        pthread_mutex_lock(&mesa);

        
        forks_in_use[fork_left]=0;
        forks_in_use[fork_right]=0;

        pthread_cond_broadcast(&b_philosophers);
        pthread_mutex_unlock(&mesa);

        toSleep(nPhilosopher);       
   }

}

int main()
{
    init();//inicializa los mutex
    unsigned long i;
    pthread_cond_init(&b_philosophers,NULL); //Inicializar la variable de condición
    for(i=0; i<NR_PHILOSOPHERS; i++){
        pthread_create(&philosophers[i], NULL, philosopher, (void*)i); //Crear un hilo por cada filósofo
        forks_in_use[i]=0; //Inicializamos el array de tenedores en uso (todos están libres al comienzo)
    }

    for(i=0; i<NR_PHILOSOPHERS; i++)
        pthread_join(philosophers[i],NULL);

    
    return 0;
} 
