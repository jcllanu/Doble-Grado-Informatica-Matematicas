#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

//OPERACIONES SOBRE FICHEROS:
        
        //int creat(char*name,mode_t mode); Equivalente a open con flags O_CREAT|O_WRONLY|O_TRUNC

        //int open(char*name, int flags, mode_t mode); Abre un fichero con los permisos de mode y devuelve un descriptor (-1 si hay error).
        //flags: O_RDONLY (Solo lectura), O_WRONLY(Solo escritura), O_RDWR(Lectura y escritura) ,O_APPEND (Antes de cada write desplaza el fichero al final),
        // O_CREAT(Si no existe lo crea), O_TRUNC (Si el fichero se abrepara escritura y ya existía lo trunca a longitud 0)
        //Tiene que aparecer uno de los tres primeros. Son O'es no ceros.

        //int read(int fd, void*buf, size_t count); Dado un descriptor de fichero y un buffer buf (en el heap), donde se copiará el contenido del fichero, lee 'count'
        //bytes del fichero en buff. Devuelve el número de bytes realmente leídos y -1 en caso de error. Si el fichero admite desplazamiento mueve el puntero de posición

        //ssize_t write(int fd, const void* buf, size_t count); Dado un descriptor de fichero fd y y un buffer buf escribe los count primeros bytes de buf en el fichero.
        //Se escriben a partir del offsetr del fichero y el puntero de posición aumenta en el número de bytes escritos. Devuelve el número de bytes escritos o -1 en error

        //int close(int fd); Cierra el fichero asociado al descriptor de fichero fd. Devuelve 0 en éxito y -1 en fallo

        //off_t lseek(int fd, off_t offset, int whence); Sitúa el puntero de escritura: Si whence==SEEK_SET, en offset bytes, si whence==SEEK_CUR,
        // en la posición actual + offset bytes, si whence==SEEK_END, en la longitud del fichero + offset bytes

        //int unlink(*const char pathname); Elimina la entrada del directorio y decrementa número de enlaces.
        //Si el contador interno de enlaces pasa a ser 0 se libera el espacio. Devuelve 0 en éxito, -1 fallo

        //int stat(const char* pathname, struct stat* statbuf);
        //int fstat(int fd, struct stat* statbuf); A esta le pasas el descriptor del fichero abierto pero hace lo mismo
        //int lstat(const char* pathname, struct stat* statbuf);
        // Almacena en statbuf atributos del fichero pathname. stat y lstat son idénticas salvo
        //cuando pathname es un enlace simbólico, que lstat devuelve información sobre el enlace en sí y stat sobre el fichero apuntado 

        //int link(const char* oldpath, const char* newpath); Enlace rígido o físico o duro
        //int symlink(const char* target, constchar* linkpath)
        //oldpath y target no deben ser directorios y si newpath/linkpath existen no se sobreescriben
        //Devuelven 0 en éxito y 1 en error

        //int rename(const*oldpath, const char* newpath); Renombra el fichero cambiándolo de directorio si es necesario

//OPERACIONES SOBRE DIRECTORIOS
        //int mkdir(const char* pathname, mode_t mode); Crea un directorio de nombre pathname y con permisos mode. Devuelve 0 en éxito y -1 en fallo

        //int rmdir(const char* pathname); Elimina el directorio si este está vacío. Si no devuelve -1

        //DIR *opendir(const char* name); Devuelve un puntero a DIR que es una especie de puntero a una tabla y que se usa en readdir() y rewinddir()

        //struct dirent *readdir(DIR*dirp); Devuelve la entrada actual de la tabla (una de las entradas del directorio) y avanza el puntero. Cuando
        //llega al final de la tabla devuelve NULL

        //void rewinddir(DIR* dirp); Situa el puntero al principio de la tabla

        //int closedir(DIR* dirp); Destruye la asociación entre dirp y la tabla

        //struct dirent contiene el número de inodo, el nombre de fichero y el tipo de fichero, es decir, es una entrada del directorio

        //int chdir(const char* pathname); Modifica el directorio de trabajo actual

        //char* getcwd(char* buf, size_t size); Copia en el buffer buf de tamaño size el nombre del directorio de trabajo actual

        //EJEMPLOS DE DIRECTORIOS EN /SO/Práctica 2/Alumno/Examples/3_Distribution

//OPERACIONES SOBRE PORCESOS E HILOS  
        //pid_t fork(); Devuelve -1 en caso de fallo y en caso de éxito retorna dos veces, la uno como 0 (hijo), y la otra con el PID del hijo(>0) (padre)
        //Hereda ficheros ya abiertos (se copian los descriptores). Se copia el mapa de memoria entero, no se comparte nada

        //pid_t wait(int *status); Espera a que termine el hijo. Devuelve en status el código de retorno del hijo y como valor de retorno el pid del hijo o 
        //-1 en caso de error

        //void exit(int status); Se finaliza la ejecución del proceso, se cierran los descriptores de ficheros abiertos y se liberan recursos. 
        //status es el código de retorno para el proceso padre

        //execl(const char *path, const char* arg,...); Termina con NULL
        //execlp(const char *file, const char *arg,...);Termina con NULL
        //execvp(const char *file, const char argv[]);
        //file/path es la ruta del ejecutable y lo demás son los argumentos
        //Devuelve -1 en caso de error y no vuelve si hay éxito. Todo lo que está debajo de un exec es código muerto. Los ficheros abiertos siguen abiertos

        //EJEMPLOS EN /SO/Práctica 3/FicherosP3/Examples/Fork y /SO/Práctica 3/FicherosP3/Projects/MySystem

        //AL COMPILAR LOS PTHREADS HAY QUE PONER -pthread EN EL Makefile

        //int pthread_create(pthread_t *tid, const pthread_attr_t *attr, void *(*func) (void*), void *arg);

        //int pthread_exit(void** status);//El hilo termina su ejecución

        //int pthread_join(pthread_t *tid, void **status);//Espera a la terminación del hilo

        //EJEMPLOS EN /SO/Práctica 3/FicherosP3/Examples/PartialSum + filósofos + autobus

//CONCURRENCIA
        //MUTEX
            //int pthread_mutex_init(pthread_mutex_t *mutex, const pthread_mutexattr_t *mutexattr);
            //int pthread_mutex_lock(pthread_mutex_t *mutex);
            //int pthread_mutex_unlock(pthread_mutex_t *mutex);
            //int pthread_mutex_destroy(pthread_mutex_t *mutex);
        //SEMÁFOROS
            //int sem_init(sem_t*sem init shared, unsigned int val); shared vale 0 para hilos y 1 para procesos y en este caso sem debe estar en una región compartida
            //int sem_destroy(sem_t *sem);
            //int sem_wait(sem_t *sem);
            //int sem_post(sem_t *sem); 
            //int sem_getvalue(sem_t *sem,int *sval); Devuelve el contador del semáforo en sval. ¿ILEGAL?
        //VARIABLES CONDICIONALES
            //int pthread_cond_init(pthread_cond_t *cond, pthread_condattr_t* cond_attr);
            //int pthread_cond_signal(pthread_cond_t *cond);
            //int pthread_cond_broadcast(pthread_cond_t *cond);
            //int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex);
            //int pthread_cond_destroy(pthread_cond_t *cond);
        //Ejemplo en filósofos y autobus
//OTRAS FUNCIONES
        //int atoi(const char* palabra); Convierte string a int
        //size_t strlen(const char* s); Longitud de la cadena sin contar el '\0'
        //void *malloc(size_t size); Reserva size bytes de memoria en el heap y devuelve el puntero
        //void free(void *ptr); libera el espacio apuntado por ptr
        //fread,fwrite,fopen.. Intro C 6.3
        //mmap y munmap (man 2 mmap)

pthread_cond_t barrera;
pthread_mutex_t mutex;
pthread_cond_t b_equipo[8];
int numpreparados=0;
int turno[8]={0,0,0,0,0,0,0,0};
int llegada_a_meta=1;



void swim(int id){
    
    sleep(rand()%4);
    
}

void begin_race(int id){
    int miturno=id%4;
    int miequipo=id/4;
    pthread_mutex_lock(&mutex);
    numpreparados++;
    printf("Nadador %d preparado\n",id);
    if(numpreparados==32){
        pthread_cond_broadcast(&barrera);
    }else{
        pthread_cond_wait(&barrera,&mutex);
    }
    while(miturno!=turno[miequipo]){
        pthread_cond_wait(&b_equipo[miequipo],&mutex);
    }
    printf("Nadador %d empieza a nadar\n",id);
    pthread_mutex_unlock(&mutex);
}
void notify_arrival(int id){
    int miturno=id%4;
    int miequipo=id/4;
    pthread_mutex_lock(&mutex);
    printf("Nadador %d termina de nadar\n",id);
    if(miturno!=3){
        pthread_cond_broadcast(&b_equipo[miequipo]);
        turno[miequipo]++;
    }else{
        printf("El equipo %d ha terminado en la posición %d\n",miequipo,llegada_a_meta);
        llegada_a_meta++;
    }
    pthread_mutex_unlock(&mutex);
}

void * codigonadador(void * arg) {
    int id_nadador=((int*)arg);
    begin_race(id_nadador);
    swim(id_nadador);
    notify_arrival(id_nadador);
    pthread_exit(0);
}

int main(void) {
    pthread_t hnadador[32];
    int id_nadador[32];

    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&barrera,NULL);
    for(int i=0; i<8;i++){
        pthread_cond_init(&b_equipo[i],NULL);
    }

    for(int i=0; i<32;i++){
        id_nadador[i]=i;
        pthread_create(&hnadador[i], NULL, codigonadador, (void*)id_nadador[i]);
    }

    for(int i=0; i<32;i++){
        pthread_join(hnadador[i], NULL);
    }


    for(int i=0; i<8;i++){
        pthread_cond_destroy(&b_equipo[i]);
    }
    pthread_cond_destroy(&barrera);
    pthread_mutex_destroy(&mutex);
}
