#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>


#define N 10

int surtidores[2]={0,0};//0 libre y 1 ocupado;
int turno = 1;
int le_toca_a=1;
int surtidores_libres=2;

pthread_mutex_t mutex;
pthread_cond_t b_cliente;

void pumpFuel(int pump, int i){
    printf("El cliente %d está repostando en el surtidor %d\n",i,pump+1);
    sleep(rand()%3+1); 
}

int getUnusedPump(int i){
    int dev;
    pthread_mutex_lock(&mutex);
    int miturno = turno;
    printf("El cliente %d tiene el turno %d\n",i,miturno);
    turno++;
    while(le_toca_a!=miturno||surtidores_libres==0){
        pthread_cond_wait(&b_cliente,&mutex);
    }
    //Es mi turno y hay al menos un surtidor libre
    le_toca_a++;
    if(surtidores[0]==0){//El primero esta libre
        surtidores_libres--;
        surtidores[0]=1;
        dev=0;
    }else{
        surtidores_libres--;
        surtidores[1]=1;
        dev=1;
    }
    pthread_mutex_unlock(&mutex);
    return dev;
}
void releasePump(int pump){
    pthread_mutex_lock(&mutex);
    surtidores_libres++;
    surtidores[pump]=0;
    pthread_cond_broadcast(&b_cliente);
    pthread_mutex_unlock(&mutex);
}

void * codigoclientes(void * arg) {
    int i=((int*)arg);
    while(1){
        int pump;
        pump=getUnusedPump(i);
        pumpFuel(pump,i);
        releasePump(pump);
    }
    pthread_exit(0);
}

int main(void) {
    pthread_t clientes[N];
    int nombreclientes[N];
    
    srand(time(0));
    
    //Inicializar concurrencia
    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&b_cliente,NULL);

    //Inicializar hilos
    for(int i=0; i<N;i++){
        nombreclientes[i]=i+1;
        pthread_create(&clientes[i], NULL, codigoclientes, (void*) nombreclientes[i]);
    }


    //Join de los hilos
    for(int i=0; i<N;i++){
        pthread_join(clientes[i], NULL);
    }
    //Destruir concurrencia
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&b_cliente);
}
