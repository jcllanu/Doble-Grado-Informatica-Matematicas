#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

pthread_mutex_t puente;
pthread_cond_t b_derecha, b_izquierda;

#define N 5

int modouso=2;//2 bidireccional, 1 derecha, 0 izquierda
int circulandoDer=0;
int circulandoIzq=0;
int esperandoDer=0;
int esperandoIzq=0;
char* usemode[3]={"Izquierda","Derecha","Bidireccional"};
int actualizarModoUso(){
    int dev;
    if((circulandoDer==0&&circulandoIzq==0)||(circulandoDer>0&&circulandoIzq>0)||(circulandoDer==0&&circulandoIzq<=2)||(circulandoDer<=2&&circulandoIzq==0)){
        dev = 2;//Si no hay nadie circulando o hay circulando en ambos sentidos o solo hay en un sentido pero en número <=2 el sentido es bidireccional (2)
    }else if(circulandoDer>2 && circulandoIzq==0){
        dev = 1;//Si hay solo circulando en sentido derecha y son más que dos se pone el sentido a derecha(1)
    }else if(circulandoDer==0 && circulandoIzq>2){
        dev = 0;//Si hay solo circulando en sentido izquierda y son más que dos se pone el sentido a izquierda(0)
    }else{
        printf("ERROR\n");
        exit(1);
    }
    if(dev!=modouso){
        printf("El modo de uso cambia de %s a %s.\n",usemode[modouso],usemode[dev]);
    }
    
    return dev;
}
void acceder_al_puente(int sentido, int i){
    pthread_mutex_lock(&puente);
    if(sentido==0){//Izquierda
        esperandoIzq++;
        while(modouso==1||(modouso==0&&esperandoDer>0)){//Mientras el modo de uso sea hacia la derecha (1) o 
        //el modo de uso sea hacia la izquierda(0) pero haya esperando en el lado derecho 
            printf("El ciclista %d está bloqueado\n",i);
            pthread_cond_wait(&b_izquierda,&puente);
        }
        esperandoIzq--;
        circulandoIzq++;
        printf("El ciclista %d empieza a circular hacia la izquierda\n",i);
        //Actualizar modouso
        modouso=actualizarModoUso();
        //Avisar a los del otro lado que el modo de uso ha cambiado
        pthread_cond_broadcast(&b_derecha);
        //Avisamos a los de nuestro lado por si acaso (creo qu no haría falta)
        pthread_cond_broadcast(&b_izquierda);
    }else{//Derecha
        esperandoDer++;
        while(modouso==0||(modouso==1&&esperandoIzq>0)){//Mientras el modo de uso sea hacia la izquierda (0) o 
        //el modo de uso sea hacia la derecha(1) pero haya esperando en el lado izquierdo 
            printf("El ciclista %d está bloqueado\n",i);
            pthread_cond_wait(&b_derecha,&puente);
        }
        esperandoDer--;
        circulandoDer++;
        printf("El ciclista %d empieza a circular hacia la derecha\n",i);
        //Actualizar modouso
        modouso=actualizarModoUso();
        //Avisar a los del otro lado que el modo de uso ha cambiado
        pthread_cond_broadcast(&b_izquierda);
        //Avisamos a los de nuestro lado por si acaso (creo qu no haría falta)
        pthread_cond_broadcast(&b_derecha);
    }
    
    pthread_mutex_unlock(&puente);
    
}
void circular_por_el_puente(int i){
    sleep(rand()%2+1);
}
void salir_del_puente(int sentido, int i){
    pthread_mutex_lock(&puente);
    printf("El ciclista %d sale del puente\n",i);
    if(sentido==0){//Izquierda
        circulandoIzq--;
        modouso=actualizarModoUso();

    }else{//Derecha
        circulandoDer--;
        modouso=actualizarModoUso();
    }
    //Avisamos a todos de que el mdo de uso ha cambiado
    pthread_cond_broadcast(&b_izquierda);
    pthread_cond_broadcast(&b_derecha);

    pthread_mutex_unlock(&puente);
}
void * codigociclista(void * arg) {
    int i=((int*)arg)[0];
    int sentido=((int*)arg)[1];
    if(i==1){
        sentido=0;
    }else{
        sentido=1;
    }
    while(1){
        acceder_al_puente(sentido,i);
        circular_por_el_puente(i);
        salir_del_puente(sentido,i);
        sleep(3);
    }
    pthread_exit(0);
}

int main(void) {
    pthread_t ciclistas[N];
    int nombreciclistas[N][2];

    srand(time(0));

    pthread_mutex_init(&puente,NULL);
    pthread_cond_init(&b_derecha,NULL);
    pthread_cond_init(&b_izquierda,NULL);

    for(int i=0; i<N; i++){
        nombreciclistas[i][0]=i+1,
        nombreciclistas[i][1]=(rand()%2);
        pthread_create(&ciclistas[i], NULL, codigociclista, (void*)nombreciclistas[i]);
    }
    
    for(int i=0; i<N;i++){
      pthread_join(ciclistas[i],NULL);
    }

    pthread_mutex_destroy(&puente);
    pthread_cond_destroy(&b_derecha);
    pthread_cond_destroy(&b_izquierda);

}
