#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

#define S 10
#define M 10
int caldero=0;
pthread_mutex_t mutex_caldero;
pthread_cond_t b_cocinero,b_salvajes;

void eat(void){
    sleep(rand()%3+1);
}
void putServingsInPot(int a){
    caldero+=a;
    printf("Cocinero repone. En el caldero hay %d raciones\n",caldero);
    
}
void getServingsFromPot(int i){
    caldero--;
    printf("Salvaje %d se sirve. En el caldero quedan %d raciones.\n",i,caldero);
}

void * codigococinero(void * arg) {
    while(1){
        pthread_mutex_lock(&mutex_caldero);
        while(caldero!=0){
		    pthread_cond_wait(&b_cocinero,&mutex_caldero);//Libera el mutex
        }
        putServingsInPot(M);
        pthread_cond_broadcast(&b_salvajes);
        pthread_mutex_unlock(&mutex_caldero);
    }
    pthread_exit(0);
}

void * codigosalvajes(void * arg) {
    int i=((int*)arg);
    while(1){
        pthread_mutex_lock(&mutex_caldero);
        while(caldero==0){
		    pthread_cond_wait(&b_salvajes,&mutex_caldero);//Libera el mutex
        }
        getServingsFromPot(i);
        if(caldero==0){
             pthread_cond_signal(&b_cocinero);
        }
        pthread_mutex_unlock(&mutex_caldero);
        eat();
    }
    pthread_exit(0);
}

int main(void) {
    pthread_t cocinero;
    pthread_t salvajes[S];
    int nombresalvaje[S];

    srand(time(0));
    
    //Inicializar concurrencia
    pthread_mutex_init(&mutex_caldero,NULL);
    pthread_cond_init(&b_salvajes,NULL);
    pthread_cond_init(&b_cocinero,NULL);
    //Inicializar hilos
    pthread_create(&cocinero, NULL, codigococinero, (void*)NULL);
    for(int i=0; i<S;i++){
        nombresalvaje[i]=i+1;
        pthread_create(&salvajes[i], NULL, codigosalvajes, (void*) nombresalvaje[i]);
    }


    //Join de los hilos
    pthread_join(cocinero, NULL);
    for(int i=0; i<S;i++){
        pthread_join(salvajes[i], NULL);
    }
    //Destruir concurrencia
    pthread_mutex_destroy(&mutex_caldero);
    pthread_cond_destroy(&b_cocinero);
    pthread_cond_destroy(&b_salvajes);
}
