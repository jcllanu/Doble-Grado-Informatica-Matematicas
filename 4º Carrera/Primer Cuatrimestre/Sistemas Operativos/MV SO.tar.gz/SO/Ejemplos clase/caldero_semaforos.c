#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

#define S 10
#define M 10
int caldero=0;

sem_t semaforo_cocinero;
sem_t semaforo_salvajes;
sem_t mutex_caldero;


void eat(void){
    sleep((rand()%3)/100000);
}
void putServingsInPot(int a){
    caldero+=a;
    if(caldero==20){
        printf("Cocinero repone. En el caldero hay %d raciones\n",caldero);
        int i=1/0;
    }
    printf("Cocinero repone. En el caldero hay %d raciones\n",caldero);
    
}
void getServingsFromPot(int i){
    caldero--;
    printf("Salvaje %d se sirve. En el caldero quedan %d raciones.\n",i,caldero);
}

void * codigococinero(void * arg) {
    while(1){
        sem_wait(&semaforo_cocinero);
        sem_wait(&mutex_caldero);
        putServingsInPot(M);
        sem_post(&mutex_caldero);
        for(int i=0; i<M; i++){
            sem_post(&semaforo_salvajes);
        }
    }
    pthread_exit(0);
}

void * codigosalvajes(void * arg) {
    int i=((int*)arg);
    while(1){
        
        sem_wait(&semaforo_salvajes);
        sem_wait(&mutex_caldero);
        getServingsFromPot(i);
        if(caldero==0){
            sem_post(&semaforo_cocinero);
        }
        sem_post(&mutex_caldero);
        eat();
    }
    pthread_exit(0);
}

int main(void) {
    pthread_t cocinero;
    pthread_t salvajes[S];
    int nombresalvaje[S];
    srand(time(0));
    //Inicializar concurrencia
    sem_init(&mutex_caldero,0,1);
    sem_init(&semaforo_cocinero,0,1);//Inicialmente el caldero está vacío así que el cocinero puede y debe cocinar
    sem_init(&semaforo_salvajes,0,0);//y los salvajes no pueden servirse
    //Inicializar hilos
    pthread_create(&cocinero, NULL, codigococinero, (void*)NULL);
    for(int i=0; i<S;i++){
        nombresalvaje[i]=i+1;
        pthread_create(&salvajes[i], NULL, codigosalvajes, (void*) nombresalvaje[i]);
    }


    //Join de los hilos
    pthread_join(cocinero, NULL);
    for(int i=0; i<S;i++){
        pthread_join(salvajes[i], NULL);
    }
    //Destruir concurrencia

    sem_destroy(&semaforo_cocinero);
    sem_destroy(&semaforo_salvajes);
    sem_destroy(&mutex_caldero);
}
