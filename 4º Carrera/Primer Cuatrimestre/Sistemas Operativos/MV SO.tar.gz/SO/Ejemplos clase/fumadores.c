#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

pthread_cond_t b_agente;
pthread_cond_t b_procesos[3];//Tabaco,papel,cigarro
pthread_mutex_t mutex;
int mesa[3]={0,0,0};//Tabaco,papel,cigarro (0 no hay 1 hay)
int numIngr=0;

void * agente(void * arg) {
    while(1){
        //sleep(rand()%3+1);
        pthread_mutex_lock(&mutex);
        while(numIngr>=2){
		    pthread_cond_wait(&b_agente,&mutex);//Libera el mutex
            
        }
        
        //El número de ingredientes es menor que dos
        int noPongo=rand()%3;
        printf("Agente: Mesa vacía, pongo 2 ingredientes(todos menos %d)\n",noPongo);
        for (int i=0; i<3;i++){
            if(i==noPongo){
                mesa[i]=0;
            }else{
                mesa[i]=1;
            }
        }
        numIngr=2;
        //Aviso a los procesos 
        for (int i=0; i<3;i++){
            pthread_cond_signal(&b_procesos[i]);
        }
        pthread_mutex_unlock(&mutex);
	}
    pthread_exit(0);
}

void * proces(void * arg) {
    
    int i=((int*)arg);
    printf("Soy el hilo %d\n",i);
    while(1){
        sleep(rand()%3+1);
        pthread_mutex_lock(&mutex);
        while(numIngr<2||mesa[i]==1){//Si hay menos de dos ingredientes o el ingrdiente que yo tengo está puesto
		    pthread_cond_wait(&b_procesos[i],&mutex);//Libera el mutex
        }
        //Pongo un ingrediente más (el que falta) y consumo los 3
        printf("Proceso %d: Falta solo mi ingrediente(el %d). Lo pongo y me hago un cigarro. No queda ningún ingrediente.\n",i,i);
        numIngr=0;
        for (int i=0; i<3;i++){
            mesa[i]=0;
        }
        //Aviso al agente 
        pthread_cond_signal(&b_agente);
        pthread_mutex_unlock(&mutex);
	}
    pthread_exit(0);
    
}

int main(void) {
    
    pthread_t hilo;
    pthread_t procesos[3];//Tabaco,papel,cigarro

    srand(time(0));
    
    //Inicializacion concurrencia
    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&b_agente,NULL);
    for(int i=0;i<3;i++){
        pthread_cond_init(&b_procesos[i],NULL);
    }
    
   
    //Lanzar hilos
    pthread_create(&hilo, NULL, agente, (void*)NULL);
    sleep(1);
    int aux[3]={0,1,2};
    for(int i=0;i<3;i++){
        pthread_create(&procesos[i], NULL, proces, (void*)aux[i]);
    }
    
    //Esperar a los hilos
    pthread_join(hilo, NULL);
    for(int i=0;i<3;i++){
        pthread_join(procesos[i], NULL);
    }
    //Destruir concurrencia
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&b_agente);
    for(int i=0;i<3;i++){
        pthread_cond_destroy(&b_procesos[i]);
    }
}

