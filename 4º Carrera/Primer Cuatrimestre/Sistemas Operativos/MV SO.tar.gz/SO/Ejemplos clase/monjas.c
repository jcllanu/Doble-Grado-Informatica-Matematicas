#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <dirent.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

#define N 10

int turno_entrada = 1;
int turno_salida = 1;
int sentadas=0;

pthread_mutex_t mutex;
pthread_cond_t b_monjas;

void quehaceres(int i){
    printf("La monja %d está haciendo cosas de monjas.\n",i);
    sleep(rand()%3+1); 
}
void comer(int i){
    pthread_mutex_lock(&mutex);
    while(sentadas<N){
        pthread_cond_wait(&b_monjas,&mutex);
    }
    pthread_mutex_unlock(&mutex);
    printf("La monja %d está comiendo.\n",i);
    sleep(rand()%3+1); 
    printf("La monja %d termina de comer.\n",i);
}

int entrar_comedor_y_sentarse(int i){
    int miturno;

    pthread_mutex_lock(&mutex);
    miturno = turno_entrada;
    turno_entrada++;
    sentadas++;
    if(sentadas==N){//La última monja que se sienta avisa a las demás
        pthread_cond_broadcast(&b_monjas);
    }
    pthread_mutex_unlock(&mutex);

    printf("La monja %d tiene el turno %d.\n",i,miturno);
    return miturno;
}
void salir_comedor(int mi_turno_salida, int i) {
    pthread_mutex_lock(&mutex);
    while(turno_salida!=mi_turno_salida){
        pthread_cond_wait(&b_monjas,&mutex);
    }
    printf("La monja %d sale del comedor.\n",i);
    turno_salida++;
    sentadas--;
    pthread_cond_broadcast(&b_monjas);
    pthread_mutex_unlock(&mutex);
}

void * codigomonjas(void * arg) {
    int i=((int*)arg);
    while(1){
        quehaceres(i);
        int mi_turno_salida;
        mi_turno_salida=entrar_comedor_y_sentarse(i);
        comer(i);
        salir_comedor(mi_turno_salida, i);
    }
    pthread_exit(0);
}

int main(void) {
    pthread_t monjas[N];
    int nombremonjas[N];

    srand(time(0));
    
    //Inicializar concurrencia
    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&b_monjas,NULL);

    //Inicializar hilos
    for(int i=0; i<N;i++){
        nombremonjas[i]=i+1;
        pthread_create(&monjas[i], NULL, codigomonjas, (void*) nombremonjas[i]);
    }


    //Join de los hilos
    for(int i=0; i<N;i++){
        pthread_join(monjas[i], NULL);
    }
    //Destruir concurrencia
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&b_monjas);
}
