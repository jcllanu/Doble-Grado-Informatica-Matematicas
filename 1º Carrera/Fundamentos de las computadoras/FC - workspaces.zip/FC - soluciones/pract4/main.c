/*-----------------------------------------------------------------
**
**  Fichero:
**    main.c  10/6/2014
**
**    Fundamentos de Computadores
**    Dpto. de Arquitectura de Computadores y Autom�tica
**    Facultad de Inform�tica. Universidad Complutense de Madrid
**
**  Prop�sito:
**    Ordena por orden alfab�tico y por prioridad un array de
**    pacientes
**
**  Notas de dise�o:
**
**---------------------------------------------------------------*/

#include <string.h>
#define MAX_PACIENTES 16
#define MAX_NOMBRE 12

struct BCP {
	unsigned int prioridad;
	char nombre[MAX_NOMBRE];
};

struct BCP Pacientes[MAX_PACIENTES] = {
		{127,"juan"},
		{127,"pepe"},
		{112,"maria"},
        {0,""},
		{100,"sara"},
		{132,"antonio"},
		{136,"silvia"},
		{255,"ana"},
		{10,"federico"},
		{0,""}};

#define CRIT_PRIO 0x00
#define CRIT_ALFA 0x01

int ListaPrioridad[MAX_PACIENTES];
int ListaAlfabetica[MAX_PACIENTES];

int Insertar(struct BCP* P, int prio, char* nombre )
{
	int pid;
	for( pid = 0 ; pid < MAX_PACIENTES ; pid++ )
		if( P[pid].prioridad == 0 ) {
			P[pid].prioridad = prio;
			strncpy( P[pid].nombre, nombre, MAX_NOMBRE );
			return pid;
		}

	return -1;
}

int BuscarNombre(struct BCP* P, char* nombre ){
	int pid;
	for( pid = 0 ; pid < MAX_PACIENTES ; pid++ )
		if( ( P[pid].prioridad != 0 ) &&
			( strncmp( P[pid].nombre, nombre, MAX_NOMBRE ) == 0 ) )
			return pid;

	return 0;
}

int PosMinPrioridad(int* Lista, struct BCP* P, int ini, int num ){
	int i,pid, pos, prio;

	pos  = ini;
	pid  = Lista[ini];
	prio = P[ pid ].prioridad;

	for( i = ini+1; i < num; i++) {
		pid = Lista[i];
		if( P[pid].prioridad < prio ){
		   pos = i;	
		   prio = P[pid].prioridad;
		}
	}

	return pos;
}

int PosMinAlfabetico(int* Lista, struct BCP* P, int ini, int num )
{
	int i,pid, pos;
	char *nombre;

	pos    = ini;
	pid    = Lista[ini];
	nombre = P[ pid ].nombre;

	for( i = ini+1; i < num; i++) {
		pid = Lista[i];
		if( strncmp( P[pid].nombre, nombre, MAX_NOMBRE ) < 0 ){
		   pos    = i;	
		   nombre = P[pid].nombre;
		}
	}

	return pos;
}


void Intercambiar(int* Lista, int i, int j);
/*{
	int tmp;

	tmp      = Lista[j];
	Lista[j] = Lista[i];
	Lista[i] = tmp;
}
*/

//Se da en C y se pide implementar en ensamblador
int OrdenaPacientes(int* Lista, struct BCP*  P, unsigned char criterio)
{
	int pid,num,i,j;

	if( (criterio != CRIT_PRIO) && (criterio != CRIT_ALFA) )
		return -1; //error

	// Copiamos los indices de los BCPs ocupados
	// a la lista
	for( pid = 0, num = 0; pid < MAX_PACIENTES ; pid++ )
		if( P[pid].prioridad != 0 ) {
			Lista[num] = pid;
			num++;
		}

	// Ordenamos la lista
	switch( criterio ){
		case CRIT_PRIO:
			for( i = 0; i < num ; i++ ) {
				j = PosMinPrioridad(Lista, P,i,num);	
				Intercambiar(Lista, i, j );
			}
			break;
		case CRIT_ALFA:
			for( i = 0; i < num ; i++ ) {
				j = PosMinAlfabetico(Lista, P,i,num);	
				Intercambiar(Lista, i, j );
			}
			break;
	}

	return num;
}

int main(void)
{
	int num;

	num = Insertar( Pacientes, 2, "simon" );
	if( num == -1 )
		return -1;

	num = OrdenaPacientes( ListaPrioridad, Pacientes, CRIT_PRIO );
	if( num == -1 )
		return -1;

	num = OrdenaPacientes( ListaAlfabetica, Pacientes, CRIT_ALFA );
	if( num == -1 )
		return -1;

	return 0;
}
