//NOMBRE Y APELLIDOS

// Comentario general sobre la solucion,
// explicando como se resuelve el problema

// Definicion del espacio de soluciones y del arbol de exploracion


#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct tDatos { // Datos de entrada
	int numPersonas, numPlayas, minLimpias;
	vector<int> basuraPlaya; // Basura a recoger en cada playa
	vector<vector<int>> recogePersona; // Basura que puede recoger cada persona en cada playa
};


// IMPLEMENTACION DEL ALGORITMO DE VUELTA ATRAS
// Explicaciones detalladas sobre la implementacion 
// Indicacion de los marcadores utilizados

// PODAS DE OPTIMALIDAD
// 1.
// 2.


void resuelveCaso()
{
	// LECTURA DE LOS DATOS DE ENTRADA 
	tDatos d;
	cin >> d.numPersonas >> d.numPlayas >> d.minLimpias;
	
	for (int i = 0; i < d.numPlayas; ++i) {
		int aux;
        cin >> aux;
        d.basuraPlaya.push_back(aux);
	}

	for (int i = 0; i < d.numPersonas; ++i) {
		vector<int> aux(d.numPlayas);
		for (int &j : aux) cin >> j;
		d.recogePersona.push_back(aux);
	}

	//CALCULO Y ESCRITURA DEL RESULTADO

    // Inicializa para hacer la llamada
	int mejorBasura; // Cantidad maxima de basura que se puede recoger
    bool exito; // Se hara cierto si es posible limpiar completamente al menos minLimpias playas
	int limpias; // Cantidad de playas completamente limpias
    //...
    
	// Llama aqui a tu funcion
    
	if (exito)
	{
		cout << mejorBasura << " " << limpias << "\n";
    }
	else
	{
		cout << "IMPOSIBLE\n";
	}
}


int main() {
	// Para la entrada por fichero
	#ifndef DOMJUDGE
	ifstream in("sample3.in");
	auto cinbuf = cin.rdbuf(in.rdbuf());
	#endif

	int numCasos;
	cin >> numCasos;
	for (int i = 0; i < numCasos; ++i) resuelveCaso();

	#ifndef DOMJUDGE
	cin.rdbuf(cinbuf);
	system("pause");
	#endif
	
	return 0;
}
