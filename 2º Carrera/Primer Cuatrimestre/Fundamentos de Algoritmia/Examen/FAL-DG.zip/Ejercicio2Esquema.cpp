// NOMBRE Y APELLIDOS 

// Comentario general sobre la solucion,
// explicando como se resuelve el problema


#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//Implementa la funcion recursiva
//Analisis del coste de esta funcion


//Esta funcion determina si v es equidiagonal
//y devuelve el producto de la diagonal principal
bool resolver(vector<vector<int>> const& v, int& d)
{
  //Invoca aqui a tu funcion recursiva
}



void resuelveCaso() {
	int dim = 0; 
	cin >> dim;
	vector<vector<int>> v(dim,vector<int>(dim));
	for (int i = 0; i < dim; i++)
	for (int j = 0; j < dim; j++)
	{
		cin >> v[i][j];
	}
	int d;
	if (resolver(v,d))
		cout << "SI " << d << "\n";
	else 
		cout << "NO\n";
}

int main() {
	// Para la entrada por fichero
	#ifndef DOMJUDGE
    ifstream in("sample2.in");
	auto cinbuf = cin.rdbuf(in.rdbuf());
	#endif

	int numCasos;
	cin >> numCasos;
	for (int i = 0; i < numCasos; ++i) 
		resuelveCaso();

	#ifndef DOMJUDGE 
	cin.rdbuf(cinbuf);
	system("PAUSE");
	#endif

	return 0;
}

