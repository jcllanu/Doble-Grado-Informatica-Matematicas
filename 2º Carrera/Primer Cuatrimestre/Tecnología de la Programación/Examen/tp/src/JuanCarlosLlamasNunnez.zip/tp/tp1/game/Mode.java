package tp.tp1.game;

public enum Mode {
	OFF, WARM_UP,ON;
	
}
