package tp.tp1.game;

public enum Move {
	LEFT, RIGHT, DOWN;
}
