
// NOMBRE Y APELLIDOS 

// COMENTARIO SOBRE LA SOLUCIÓN
// NO OLVIDES PONER EL COSTE JUSTIFICADO DE CADA OPERACIÓN JUNTO A ELLA

#ifndef URGENCIAS
#define URGENCIAS

#include <iostream>          
#include <string>
#include <stdexcept>
#include <algorithm>
using namespace std;

class urgencias {
   
public:
   
};


#endif
