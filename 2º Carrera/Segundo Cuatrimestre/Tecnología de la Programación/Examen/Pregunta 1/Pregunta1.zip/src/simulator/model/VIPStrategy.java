package simulator.model;

import java.util.ArrayList;
import java.util.List;

public class VIPStrategy implements DequeuingStrategy{
	//CLASE NUEVA
	
	int limit;
	String viptag;
	public VIPStrategy(int limit, String viptag) {
		this.limit=limit;
		this.viptag=viptag;
	}
	@Override
	public List<Vehicle> dequeuing(List<Vehicle> l) {
		List<Vehicle> salen=new ArrayList<Vehicle>();
		int contador=0;
		//Metemos los VIPS
		for(Vehicle v: l) {
			if(contador<limit) {
				if(v.getId().endsWith(viptag)) {
					salen.add(v);
					contador++;
				}
			}else {
				return salen;
			}
		}
		//Metemos los NO VIPS
		for(Vehicle v: l) {
			if(contador<limit) {
				if(!v.getId().endsWith("_vip")) {
					salen.add(v);
					contador++;
				}
			}else {
				return salen;
			}
		}
		return salen;
	}

}
