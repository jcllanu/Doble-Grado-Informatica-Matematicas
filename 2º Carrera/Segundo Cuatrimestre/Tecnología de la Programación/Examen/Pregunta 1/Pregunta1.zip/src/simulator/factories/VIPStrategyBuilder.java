package simulator.factories;

import org.json.JSONObject;

import simulator.model.DequeuingStrategy;
import simulator.model.VIPStrategy;

public class VIPStrategyBuilder extends Builder<DequeuingStrategy>{
	//CLASE NUEVA
	public VIPStrategyBuilder() {
		super("vip_dqs");
	}
	
	protected DequeuingStrategy createTheInstance(JSONObject data) {
		if(data.has("viptag")){
			if(data.has("limit"))
				return new VIPStrategy(data.getInt("limit"),data.getString("viptag"));
			else
				return new VIPStrategy(1,data.getString("viptag"));
		}else{
			throw new IllegalArgumentException("Invalid value for createTheInstance: " + data);
		}
		
		
		
	}
}
