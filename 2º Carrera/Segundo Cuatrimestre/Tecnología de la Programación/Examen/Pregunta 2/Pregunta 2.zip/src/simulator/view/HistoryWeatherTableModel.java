package simulator.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.Road;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;
import simulator.model.Weather;

public class HistoryWeatherTableModel extends AbstractTableModel implements TrafficSimObserver {
	private Controller _ctrl;
	private Map<Integer, HashMap<Weather, ArrayList<Road>>> roads;
	int time;
	private Weather weather;
	private String[] nombreColumnas = { "Time", "Roads"};
	
	
	public HistoryWeatherTableModel(Controller _ctrl) {
		this._ctrl=_ctrl;
		roads=new HashMap<Integer,HashMap<Weather,ArrayList<Road>>>();
		initGUI();
	}
	private void initGUI() {
		weather=weather.SUNNY;
		_ctrl.addObserver(this);
	}
	
	//M�TODOS DE LA TABLA
	@Override
	public int getRowCount() {
		if(roads==null) {
			return 0;
		}else {
			return roads.size();
		}
	}

	@Override
	public int getColumnCount() {
		return nombreColumnas.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Object s = null;
		if(columnIndex == 0) {
			s=rowIndex+1;
		}else if(columnIndex == 1) {
			ArrayList<Road> lista= roads.get(rowIndex+1).get(weather);
			s="[";
			for(int i=0; i<lista.size(); i++) {
				s+=lista.get(i).getId();
				if(i!=lista.size()-1) {
					s+=", ";
				}
			}
			s+="]";
		}
		return s;
	}
	
	@Override
	public boolean isCellEditable(int row, int column) {
		return false;
	}
	@Override
	public String getColumnName(int col) {
		return nombreColumnas[col];
	}
	
	//M�TODOS OBSERVER
	@Override
	public void onAdvanceStart(RoadMap map, List<Event> events, int time) {
		
	}

	@Override
	public void onAdvanceEnd(RoadMap map, List<Event> events, int time) {
		this.time=time;
		HashMap<Weather, ArrayList<Road>> mapa=new HashMap<Weather, ArrayList<Road>>();
		mapa.put(Weather.SUNNY,new ArrayList<Road>());
		mapa.put(Weather.CLOUDY,new ArrayList<Road>());
		mapa.put(Weather.STORM,new ArrayList<Road>());
		mapa.put(Weather.WINDY,new ArrayList<Road>());
		mapa.put(Weather.RAINY,new ArrayList<Road>());
		for(Road r: map.getRoads()) {
			 ArrayList<Road> l=mapa.get(r.getWeather());
			 l.add(r);
			 mapa.put(r.getWeather(),l);
		}
		roads.put(time, mapa);
		
	}

	@Override
	public void onEventAdded(RoadMap map, List<Event> events, Event e, int time) {
		
	}

	@Override
	public void onReset(RoadMap map, List<Event> events, int time) {
		
		
	}

	@Override
	public void onRegister(RoadMap map, List<Event> events, int time) {
		
		
	}

	@Override
	public void onError(String err) {	
	}
	
	public void setWeather(Weather w) {
		weather=w;
		fireTableDataChanged();
	}

}
