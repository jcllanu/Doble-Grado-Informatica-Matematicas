package simulator.view;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

import simulator.control.Controller;
import simulator.model.RoadMap;
import simulator.model.Vehicle;
import simulator.model.Weather;

public class WeatherHistoryDialog extends JDialog{

	private int _status; 
	private JComboBox<Weather> weather;
	private Weather[] weatherModelo= {Weather.SUNNY, Weather.CLOUDY, Weather.RAINY, Weather.WINDY, Weather.STORM};
	private Controller _ctrl;

	public WeatherHistoryDialog(Frame controlPanel, Controller controller) {
		super(controlPanel, true);		
		_ctrl=controller;
		initGUI();
	}

	private void initGUI() {
		_status = 0;

		setTitle("Roads Weather Histoy");
		
		
		JPanel panelPrincipal = new JPanel();
		panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
		setContentPane(panelPrincipal);

		//MENSAJE DE AYUDA
		JLabel mensajeAyuda1 = new JLabel("Select a weather and press UPDATE to show the roads that");
		JLabel mensajeAyuda2 = new JLabel("have this weather in each tick.");
		
		mensajeAyuda1.setAlignmentX(CENTER_ALIGNMENT);
		mensajeAyuda2.setAlignmentX(CENTER_ALIGNMENT);
		
		panelPrincipal.add(mensajeAyuda1);
		panelPrincipal.add(mensajeAyuda2);
		panelPrincipal.add(Box.createRigidArea(new Dimension(0, 20)));

		//PANEL SELECCION TIEMPO
		JPanel panelOpciones = new JPanel();
		panelOpciones.setAlignmentX(CENTER_ALIGNMENT);
		panelPrincipal.add(panelOpciones);

		panelPrincipal.add(Box.createRigidArea(new Dimension(0, 20)));

		//PANEL BOTONES UPDATE Y CLOSE
		JPanel panelBotones = new JPanel();
		panelBotones.setAlignmentX(CENTER_ALIGNMENT);
		panelPrincipal.add(panelBotones);

		//SELECCION TIEMPO
		
		weather=new JComboBox<>(weatherModelo);
		
		
		panelOpciones.setLayout(new GridLayout(1,2,10,10));
		
		panelOpciones.add(new JLabel("Weather: ",SwingConstants.CENTER));
		panelOpciones.add(weather);
		
		
		//BOTON CLOSE
		JButton close = new JButton("Close");
		close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				_status = 0; 
				WeatherHistoryDialog.this.setVisible(false);
			}
		});
		panelBotones.add(close);

		
		HistoryWeatherTableModel modelo=new HistoryWeatherTableModel(_ctrl);
		
		//BOTON UPDATE
		JButton update = new JButton("Update");
		update.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				modelo.setWeather((Weather) weather.getSelectedItem());
			}
		});
		panelBotones.add(update);

		
		
		JPanel panelTable=new JPanel();
		panelTable.add(new JTable(modelo));
		
		JScrollPane deslizable=new JScrollPane(panelTable);
		panelPrincipal.add(deslizable);
		setPreferredSize(new Dimension(500, 500));
		pack();
		setResizable(false);
		setVisible(false);
	}

	public int open(RoadMap map) {
		setLocation(getParent().getLocation().x + 250, getParent().getLocation().y + 250);
		setVisible(true); 				
		return _status;
	}

}

