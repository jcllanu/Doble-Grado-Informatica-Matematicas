package jcolor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ColorChooser extends JDialog {

	private JColorChooser jcolorChooser; //esta clase es de Java
	private Color color; // se cargará con el color seleccionado por el usuario

	public ColorChooser(JFrame parent, String title, Color initColor) {
		super(parent, true);
		setTitle(title);
		setLocation(getParent().getLocation().x + 100, getParent().getLocation().y + 100);
		getContentPane().setLayout(new BorderLayout());
		jcolorChooser = new JColorChooser(initColor == null ? Color.WHITE
				: initColor);
		getContentPane().add(jcolorChooser, BorderLayout.CENTER);

		// el objeto de la clase JColorChooser trae la paleta de colores y
		// la vista previa del color por defecto.
		// Si queremos botón de aceptar o cancelar se lo tenemos que añadir
		// nosotros

		// creamos un panel para poner los botones OK y CANCEL
		JPanel buttonPanel = new JPanel();
		JButton buttonOK = new JButton("OK");
		buttonOK.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				color = jcolorChooser.getColor();
				dispose();
			}
		});
		buttonPanel.add(buttonOK);

		JButton buttonCancel = new JButton("Cancel");
		buttonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				color = null; //no hay color seleccionado
				dispose();
			}
		});
		buttonPanel.add(buttonCancel);

		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
	}
	
	//a este método lo llamo desde el main
	public Color getColor() {
		return color; // devolverá el color seleccionado por el usuario
	}

}