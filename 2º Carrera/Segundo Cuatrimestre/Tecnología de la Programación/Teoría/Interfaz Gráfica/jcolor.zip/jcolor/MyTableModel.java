package jcolor;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

class MyTableModel extends AbstractTableModel {

	private String[] colNames;
	private List<String> names; //de este arrayList saca la información la tabla
								

	public MyTableModel() {
		this.colNames = new String[] { "Number", "Name" };
		names = new ArrayList<>();
		names.add("John F. Smith");
		names.add("George S. Winston");
	}

	@Override
	public String getColumnName(int col) {
		return colNames[col];
	}

	@Override
	public int getColumnCount() {
		return colNames.length;
	}

	@Override
	public int getRowCount() {
		return names != null ? names.size() : 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {

		if (columnIndex == 0) {
			//pues en la primera columna enumero
			return rowIndex;
		} else { //en la segunda columna:
			return names.get(rowIndex);
		}
	}

	//aquí es donde el modelo recibe los datos
	//añadimos un nombre más al arrayList
	public void addName(String name) {
		names.add(name);
		fireTableDataChanged();
	}

};