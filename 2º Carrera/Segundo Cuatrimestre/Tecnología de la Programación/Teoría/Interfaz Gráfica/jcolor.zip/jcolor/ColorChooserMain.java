package jcolor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;

public class ColorChooserMain extends JFrame {

	private JTextField name;
	private MyTableModel tModel;

	private Map<Integer, Color> colors; // a cada num de fila -> Color
										// para pintar cada línea de su color
	private ColorChooser colorChooser; // esto es el cuadro de diálogo

	public ColorChooserMain() {
		super("Ejemplo: Pintar un JTable con la paleta de colores ");
		initGUI();
	}

	private void initGUI() {

		JPanel mainPanel = new JPanel(new BorderLayout());
		colors = new HashMap<>();

		colorChooser = new ColorChooser(this, "Choose Line Color", Color.YELLOW);
		// yellow sería el color seleccionado por defecto en la paleta de colores

		tModel = new MyTableModel();

		JTable table = new JTable(tModel) {

			// Este método ni lo llamo ni lo instancio.
			// Le llegan la fila y la columna donde se hizo el clic
			// Cuando se haga un repaint() en el JTable se pintará así:
			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
				Component comp = super.prepareRenderer(renderer, row, col);

				if (col == 1) // para que solo pinte la segunda columna
					comp.setBackground(colors.get(row));
				// he accedido al mapa para que pinte cada línea de su color
				else // la primera clumna no queremos pintarla
					comp.setBackground(Color.WHITE);
				comp.setForeground(Color.BLACK); //color del texto
				return comp;
			}
		};

		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {

			}

			@Override
			public void mouseEntered(MouseEvent e) {

			}

			@Override
			public void mouseClicked(MouseEvent evt) {
				// Obtengo la fila y columna que ha recogido el clic del ratón
				int row = table.rowAtPoint(evt.getPoint());
				int col = table.columnAtPoint(evt.getPoint());
				if (row >= 0 && col >= 0) {
					changeColor(row); // pinto por filas
				}
			}

		});

		mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
		JPanel ctrlPabel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		mainPanel.add(ctrlPabel, BorderLayout.PAGE_START);

		// name text box and corresponding button
		ctrlPabel.add(new JLabel("Name"));
		name = new JTextField(15);
		ctrlPabel.add(name);
		JButton addName = new JButton("Add");
		addName.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = name.getText().trim();
				if (!s.equals("")) {
					tModel.addName(name.getText()); // operación del modelo
				}
				name.setText("");
			}
		});
		ctrlPabel.add(addName);

		mainPanel.add(new JLabel("Click on a row, in the table above, to chaneg its background color"),
				BorderLayout.PAGE_END);

		mainPanel.setOpaque(true);
		this.setContentPane(mainPanel);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 400);
		this.setVisible(true);
	}

	private void changeColor(int row) {
		// Hago visible el cuadro de diálogo
		colorChooser.setVisible(true);
		if (colorChooser.getColor() != null) { // si hay color seleccionado pintaré
			colors.put(row, colorChooser.getColor()); // guardo en el mapa el color
			repaint(); // si lo quitáis no va a pintar la fila
		}

	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new ColorChooserMain();
			}
		});
	}
}
