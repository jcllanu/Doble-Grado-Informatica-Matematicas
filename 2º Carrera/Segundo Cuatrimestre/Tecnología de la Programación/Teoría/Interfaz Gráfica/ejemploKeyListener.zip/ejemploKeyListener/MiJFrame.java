package ejemploKeyListener;
//autor Vicky. Mostrando interacción con Ratón y Teclado

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MiJFrame extends JFrame {
	MiComponente miComponente;
	JLabel label;

	public MiJFrame() {
		super("Mi primera Ventana");
		initGUI();
	}

	private void initGUI() {

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		setContentPane(mainPanel);

		JPanel p = new JPanel();
		p.setAlignmentX(CENTER_ALIGNMENT);
		label = new JLabel("MOSTRANDO INTERACCIÓN CON EL TECLADO Y EL RATÓN");
		p.add(label);
		p.setBackground(Color.yellow);
		p.setOpaque(true);
		mainPanel.add(p);

		miComponente = new MiComponente();
		mainPanel.add(miComponente);
		miComponente.setPreferredSize(new Dimension(400, 400));

		this.setSize(400, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new MiJFrame();
			}
		});
	}
}
