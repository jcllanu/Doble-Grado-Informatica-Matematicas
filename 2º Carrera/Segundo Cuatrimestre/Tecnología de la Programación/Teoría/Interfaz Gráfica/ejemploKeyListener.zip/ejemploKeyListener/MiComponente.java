package ejemploKeyListener;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.border.TitledBorder;

public class MiComponente extends JComponent {
	private boolean puntos = false;
	Random rand = new Random(0);

	public MiComponente() {

		this.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(Color.red, 2), "Mi componente",
				TitledBorder.LEFT, TitledBorder.TOP));

		addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				System.out.println("Has presionado una tecla");
			}

			@Override
			public void keyReleased(KeyEvent e) {
				System.out.println("Has soltado una tecla");
			}

			@Override
			public void keyPressed(KeyEvent e) {
				switch (e.getKeyChar()) {
				case '-':
					System.out.println("Por fin has pulsado la tecla : -");
					break;
				case '+':
					System.out.println("Por fin has pulsado la tecla : +");
					break;

				default:

				}

			}
		});

		addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
				System.out.println("Hasta otro día!!!!!!!!!!!!!!!");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				System.out.println("Bienvenidos al componente!!!!!!!");
				// observar que si no pongo esto no recojo las teclas
				//para poder recoger las teclas el componente tiene que 
				//tener el foco
				requestFocus();
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				puntos = !puntos;
				repaint();

			}
		});

	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D gr = (Graphics2D) g;

		if (puntos) {
			//pintamos 50 puntos azules en posiciones aleatorias
			gr.setColor(Color.BLUE);
			for (int i = 0; i < 50; i++) {
				int x = rand.nextInt(400);
				int y = rand.nextInt(400);
				gr.drawOval(x, y, 10, 10);
				gr.fillOval(x, y, 10, 10);
			}
			//pintamos 50 puntos verdes en posiciones aleatorias
			gr.setColor(Color.GREEN);
			for (int i = 0; i < 50; i++) {
				int x = rand.nextInt(400);
				int y = rand.nextInt(400);
				gr.drawOval(x, y, 10, 10);
				gr.fillOval(x, y, 10, 10);
			}

		} else {
			gr.setColor(Color.RED);
			gr.drawString("Presiona y suelta el botón del ratón", 75, 200);
		}
	}
}