import java.util.ArrayList;

public class Modelo {
	// En observadores llevaremos las vistas registradas como observadores del
	// modelo
	ArrayList<ObservadorModelo> observadores;
	
	//el atributo res es el dato del modelo,
	//en vuestra práctica el modelo es TrafficSimulator 
	//y los datos del modelo son _roadMap, _events, _time
	double res;

	public Modelo() {
		observadores = new ArrayList<ObservadorModelo>();
	}

	//el modelo modifica sus datos
	public void calcular(double valor) {
		res = valor * valor;
		notifyUpdate(res);// notifica a las vistas los cambios
	}

	private void notifyUpdate(Double dato) {
		for (ObservadorModelo ob : observadores) {
			ob.actualizar(dato);
		}
	}

	// añade la vista al arrayList observadores
	public void addObservador(ObservadorModelo ob) {
		observadores.add(ob);
	}
	//Este método lo ponemos, pero en este ejemplo no se usa
	public void removeObservador(ObservadorModelo ob) {
		observadores.remove(ob);
	}
}
