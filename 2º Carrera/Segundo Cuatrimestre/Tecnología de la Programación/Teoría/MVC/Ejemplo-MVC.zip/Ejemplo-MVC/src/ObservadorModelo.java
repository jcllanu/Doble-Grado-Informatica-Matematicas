
public interface ObservadorModelo {
	//todas las vistas que quieran ser observadoras 
	//del modelo deben implementar esta interfaz y dar cuerpo a
	//este método
	public void actualizar(double dato);
}
