import java.awt.event.ActionEvent;

import javax.swing.SwingUtilities;

// Ejemplo mínimo de MVC.

// Estudiarlo de la siguiente manera:

// Ver primero que en el new Vista(control) ya queda añadida al arrayList de 
// observadores del modelo

// Después ejecutarlo e interactuar con la vista y observar lo que ocurre al 
// hacer clic en el botón, ver el método 
// public void actionPerformed(ActionEvent e) {...}

//Observar como el modelo después de modificar sus datos (en este caso el 
//atributo res) se lo notifica a las vistas registradas (en este caso solo una)

public class Main {

	public static void main(String[] args) {
		Modelo modelo = new Modelo();
		Controlador control = new Controlador(modelo);

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Vista(control);
				//observar el constructor de la vista, y fijaros que en este
				//new Vista(control) ya queda añadida al arrayList de 
				//observadores del modelo
			}
		});

	}

}
