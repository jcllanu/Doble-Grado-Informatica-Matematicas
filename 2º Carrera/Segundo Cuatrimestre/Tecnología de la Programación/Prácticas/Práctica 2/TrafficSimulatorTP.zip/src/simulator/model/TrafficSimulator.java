package simulator.model;


import java.util.ArrayList;
import java.util.List;


import org.json.JSONObject;

import simulator.misc.SortedArrayList;

public class TrafficSimulator implements Observable<TrafficSimObserver> {
	
	private RoadMap mapaCarreteras;
	private List<Event> listaEventos;
	private List<TrafficSimObserver> observadores;
	private int time;
	
	public TrafficSimulator() {
		time=0;
		mapaCarreteras=new RoadMap();
		listaEventos=new SortedArrayList<Event>();
		observadores=new ArrayList<TrafficSimObserver>();
	}
	
	public void reset() {
		mapaCarreteras.reset();
		listaEventos.clear();
		time=0;
		
		//Notificaciones a los observadores
		for(TrafficSimObserver observador: observadores) {
			observador.onReset(mapaCarreteras, listaEventos, time);
		}
	}
	
	public void addEvent(Event e) {
		if(e._time<time) {
			//Notificaciones a los observadores
			String err="El tiempo del nuevo evento es menor al tiempo actual de ejecuci�n";
			for(TrafficSimObserver observador: observadores) {
				observador.onError(err);	
			}
			throw new IllegalArgumentException(err);
		}else {
			listaEventos.add(e);
			//Notificaciones a los observadores
			for(TrafficSimObserver observador: observadores) {
				observador.onEventAdded(mapaCarreteras, listaEventos, e, time);
			}
		}
	}
	
	public void advance() {
		time++;
		
		//Notificaciones a los observadores
		for(TrafficSimObserver observador: observadores) {
			observador.onAdvanceStart(mapaCarreteras, listaEventos, time);
		}
		
		try{
			while(!listaEventos.isEmpty()&&listaEventos.get(0)._time==time) {
				listaEventos.get(0).execute(mapaCarreteras);
				listaEventos.remove(0);
			}
			for(Junction j: mapaCarreteras.getJunctions()){
				j.advance(time);
			}
			for(Road r: mapaCarreteras.getRoads()){
				r.advance(time);
			}
		}catch(Exception e) {
			
			//Notificaciones a los observadores
			for(TrafficSimObserver observador: observadores) {
				observador.onError(e.getMessage());	
			}
			throw new IllegalArgumentException(e.getMessage());
		}
		
		//Notificaciones a los observadores
		for(TrafficSimObserver observador: observadores) {
			observador.onAdvanceEnd(mapaCarreteras, listaEventos, time);
		}
	}
	
	public JSONObject report(){
		JSONObject j = new JSONObject();
		j.put("time", time);
		j.put("state", mapaCarreteras.report());
		
		return j;
		
	}

	@Override
	public void addObserver(TrafficSimObserver o) {
		observadores.add(o);
		o.onRegister(mapaCarreteras, listaEventos, time);
		
	}

	@Override
	public void removeObserver(TrafficSimObserver o) {
		observadores.remove(o);
	}
}
