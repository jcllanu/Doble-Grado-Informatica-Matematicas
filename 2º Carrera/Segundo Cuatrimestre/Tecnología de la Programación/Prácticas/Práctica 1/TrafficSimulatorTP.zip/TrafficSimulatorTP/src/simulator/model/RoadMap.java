package simulator.model;

public class RoadMap {
}
